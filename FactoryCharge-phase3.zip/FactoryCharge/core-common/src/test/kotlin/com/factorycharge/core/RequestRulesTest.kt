package com.factorycharge.core

import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.request.OfferView
import com.factorycharge.core.request.RequestCheck
import com.factorycharge.core.request.RequestRejection
import com.factorycharge.core.request.RequestRules
import com.factorycharge.core.util.BeneficiaryPhone
import com.factorycharge.core.util.DateText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RequestRulesTest {
    private fun offer(
        active: Boolean = true,
        price: Long? = 15_000,
        from: Long? = null,
        until: Long? = null,
        provider: NetworkProvider = NetworkProvider.VODAFONE,
        service: ServiceType = ServiceType.BALANCE_TOPUP,
    ) = OfferView("o1", provider, service, "شحن 100", 10_000, price, active, from, until)

    private fun check(
        offer: OfferView? = offer(),
        phone: String = "01012345678",
        note: String? = null,
        now: Long = 1_000,
        provider: NetworkProvider = NetworkProvider.VODAFONE,
        service: ServiceType = ServiceType.BALANCE_TOPUP,
    ) = RequestRules.check(offer, provider, service, phone, note, now)

    private fun reason(c: RequestCheck) = (c as RequestCheck.Rejected).reason

    @Test
    fun validRequestUsesOfferPriceAndNormalizedPhone() {
        val ok = check(phone = "+20 101 234 5678", note = "  مستعجل  ") as RequestCheck.Ok
        assertEquals(15_000L, ok.priceMinor)
        assertEquals("01012345678", ok.beneficiary)
        assertEquals("مستعجل", ok.note)
    }

    // ---- 4) رفض طلب بعرض غير فعال أو منتهٍ أو غير موجود
    @Test
    fun inactiveOrUnavailableOffersAreRejected() {
        assertEquals(RequestRejection.OFFER_NOT_FOUND, reason(check(offer = null)))
        assertEquals(RequestRejection.OFFER_INACTIVE, reason(check(offer = offer(active = false))))
        assertEquals(RequestRejection.OFFER_NOT_YET_VALID, reason(check(offer = offer(from = 5_000), now = 1_000)))
        assertEquals(RequestRejection.OFFER_EXPIRED, reason(check(offer = offer(until = 500), now = 1_000)))
        assertTrue(check(offer = offer(from = 1_000, until = 1_000), now = 1_000) is RequestCheck.Ok)
        assertEquals(RequestRejection.OFFER_MISMATCH, reason(check(provider = NetworkProvider.ORANGE)))
        assertEquals(RequestRejection.OFFER_MISMATCH, reason(check(service = ServiceType.DATA_PACKAGE)))
    }

    @Test
    fun zeroNegativeOrMissingPriceIsRejected() {
        assertEquals(RequestRejection.PRICE_UNAVAILABLE, reason(check(offer = offer(price = 0))))
        assertEquals(RequestRejection.PRICE_UNAVAILABLE, reason(check(offer = offer(price = -100))))
        assertEquals(RequestRejection.PRICE_UNAVAILABLE, reason(check(offer = offer(price = null))))
    }

    // ---- 5) رفض رقم مستفيد غير صالح
    @Test
    fun invalidBeneficiaryIsRejected() {
        listOf("", "123", "0101234567", "010123456789", "01312345678", "abc12345678", "02212345678").forEach {
            assertEquals(it, RequestRejection.INVALID_BENEFICIARY, reason(check(phone = it)))
        }
    }

    @Test
    fun beneficiaryNormalization() {
        assertEquals("01012345678", BeneficiaryPhone.normalize("01012345678"))
        assertEquals("01112345678", BeneficiaryPhone.normalize("0111 234 5678"))
        assertEquals("01212345678", BeneficiaryPhone.normalize("٠١٢١٢٣٤٥٦٧٨"))
        assertEquals("01512345678", BeneficiaryPhone.normalize("+201512345678"))
        assertEquals("01012345678", BeneficiaryPhone.normalize("0020 101-234-5678"))
        assertEquals("01012345678", BeneficiaryPhone.normalize("201012345678"))
        assertNull(BeneficiaryPhone.normalize("+21012345678"))
    }

    @Test
    fun longNoteIsRejected() {
        assertEquals(RequestRejection.NOTE_TOO_LONG, reason(check(note = "x".repeat(201))))
        assertTrue(check(note = "x".repeat(200)) is RequestCheck.Ok)
    }

    @Test
    fun dateTextParsing() {
        val start = DateText.parseDayStart("2026/11/05")
        val end = DateText.parseDayEnd("2026-11-05")
        assertNotNull(start)
        assertTrue(end!! - start!! in (23L * 3_600_000)..(25L * 3_600_000))
        assertEquals("2026/11/05", DateText.formatDay(start))
        assertEquals(start, DateText.parseDayStart("٢٠٢٦/١١/٠٥"))
        assertNull(DateText.parseDayStart("2026/13/01"))
        assertNull(DateText.parseDayStart("2026/02/30"))
        assertNull(DateText.parseDayStart("11/05/2026"))
        assertNull(DateText.parseDayStart(""))
    }
}
