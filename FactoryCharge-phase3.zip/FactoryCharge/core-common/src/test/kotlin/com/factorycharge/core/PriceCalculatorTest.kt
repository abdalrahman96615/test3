package com.factorycharge.core

import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.pricing.PriceCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PriceCalculatorTest {
    // ---- 6) حساب سعر الرصيد الصافي بالمعامل
    @Test
    fun netBalancePriceExampleFromSpec() {
        // رصيد 100 جنيه × 1.5 = 150 جنيه
        assertEquals(15_000L, PriceCalculator.netBalancePrice(10_000, 15_000))
    }

    @Test
    fun multiplierIsNotHardcoded() {
        assertEquals(12_000L, PriceCalculator.netBalancePrice(10_000, 12_000)) // 1.2
        assertEquals(20_000L, PriceCalculator.netBalancePrice(10_000, 20_000)) // 2.0
        assertEquals(10_000L, PriceCalculator.netBalancePrice(10_000, 10_000)) // 1.0
        assertEquals(10_500L, PriceCalculator.netBalancePrice(10_000, 10_500)) // 1.05
    }

    @Test
    fun roundsHalfUpToNearestPiastre() {
        // 33.33 × 1.5 = 49.995 => 50.00
        assertEquals(5_000L, PriceCalculator.netBalancePrice(3_333, 15_000))
        // 0.01 × 1.5 = 0.015 => 0.02 (نصف لأعلى)
        assertEquals(2L, PriceCalculator.netBalancePrice(1, 15_000))
        // 0.01 × 1.49 => 0.0149 => 0.01
        assertEquals(1L, PriceCalculator.netBalancePrice(1, 14_900))
    }

    @Test
    fun invalidInputsGiveNull() {
        assertNull(PriceCalculator.netBalancePrice(0, 15_000))
        assertNull(PriceCalculator.netBalancePrice(-1, 15_000))
        assertNull(PriceCalculator.netBalancePrice(10_000, 0))
        assertNull(PriceCalculator.netBalancePrice(10_000, -1))
        assertNull(PriceCalculator.netBalancePrice(10_000, PriceCalculator.MAX_MULTIPLIER_BP + 1))
        assertNull(PriceCalculator.netBalancePrice(Long.MAX_VALUE, 15_000)) // فيض
        assertNull(PriceCalculator.netBalancePrice(1, 1)) // يقرّب إلى صفر
    }

    @Test
    fun priceForDependsOnModeAndNeverInventsAMultiplier() {
        assertEquals(2_500L, PriceCalculator.priceFor(PricingMode.FIXED_PRICE, 2_200, 2_500, null))
        assertNull(PriceCalculator.priceFor(PricingMode.FIXED_PRICE, 2_200, null, 15_000))
        assertNull(PriceCalculator.priceFor(PricingMode.FIXED_PRICE, 2_200, 0, 15_000))
        assertEquals(15_000L, PriceCalculator.priceFor(PricingMode.NET_MULTIPLIER, 10_000, null, 15_000))
        assertNull(PriceCalculator.priceFor(PricingMode.NET_MULTIPLIER, 10_000, null, null)) // لا معامل = لا سعر
    }

    @Test
    fun multiplierParsingAndFormatting() {
        assertEquals(15_000L, PriceCalculator.parseMultiplier("1.5"))
        assertEquals(15_000L, PriceCalculator.parseMultiplier("١٫٥"))
        assertEquals(15_250L, PriceCalculator.parseMultiplier("1.525"))
        assertEquals(10_001L, PriceCalculator.parseMultiplier("1.0001"))
        assertNull(PriceCalculator.parseMultiplier("0"))
        assertNull(PriceCalculator.parseMultiplier("-1"))
        assertNull(PriceCalculator.parseMultiplier("1.00001"))
        assertNull(PriceCalculator.parseMultiplier("101"))
        assertNull(PriceCalculator.parseMultiplier("abc"))
        assertEquals("1.50", PriceCalculator.formatMultiplier(15_000))
        assertEquals("1.00", PriceCalculator.formatMultiplier(10_000))
        assertEquals("1.0001", PriceCalculator.formatMultiplier(10_001))
        assertEquals("10.00", PriceCalculator.formatMultiplier(100_000))
    }
}
