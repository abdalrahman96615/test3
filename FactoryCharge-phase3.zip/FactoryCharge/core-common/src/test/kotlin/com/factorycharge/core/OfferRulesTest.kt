package com.factorycharge.core

import com.factorycharge.core.catalog.OfferDraft
import com.factorycharge.core.catalog.OfferError
import com.factorycharge.core.catalog.OfferRules
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.ServiceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OfferRulesTest {
    private fun draft(
        provider: NetworkProvider = NetworkProvider.VODAFONE,
        service: ServiceType = ServiceType.DATA_PACKAGE,
        name: String = "باقة 10 جيجا",
        mode: PricingMode = PricingMode.FIXED_PRICE,
        face: Long = 0,
        price: Long? = 5_000,
        from: Long? = null,
        until: Long? = null,
        description: String? = null,
    ) = OfferDraft(provider, service, name, description, mode, face, price, from, until, 0)

    @Test
    fun validOffersPass() {
        assertNull(OfferRules.validate(draft()))
        assertNull(OfferRules.validate(draft(service = ServiceType.RECHARGE_CARD, face = 2_200, price = 2_500)))
        assertNull(OfferRules.validate(draft(service = ServiceType.BALANCE_TOPUP, mode = PricingMode.NET_MULTIPLIER, face = 10_000, price = null)))
        assertNull(OfferRules.validate(draft(from = 1_000, until = 2_000)))
    }

    @Test
    fun faceValueAndPriceAreSeparateFields() {
        // كارت فئة 22 بسعر بيع 25: الاسمي والبيع مختلفان ومقبولان معاً
        assertNull(OfferRules.validate(draft(service = ServiceType.RECHARGE_CARD, face = 2_200, price = 2_500)))
    }

    @Test
    fun invalidOffersAreRejected() {
        assertEquals(OfferError.INVALID_PROVIDER, OfferRules.validate(draft(provider = NetworkProvider.OTHER)))
        assertEquals(OfferError.INVALID_NAME, OfferRules.validate(draft(name = "   ")))
        assertEquals(OfferError.INVALID_NAME, OfferRules.validate(draft(name = "س".repeat(101))))
        assertEquals(OfferError.INVALID_PRICE, OfferRules.validate(draft(price = 0)))
        assertEquals(OfferError.INVALID_PRICE, OfferRules.validate(draft(price = null)))
        assertEquals(OfferError.INVALID_PRICE, OfferRules.validate(draft(price = -5)))
        assertEquals(OfferError.INVALID_FACE_VALUE, OfferRules.validate(draft(face = -1)))
        assertEquals(OfferError.INVALID_FACE_VALUE, OfferRules.validate(draft(service = ServiceType.RECHARGE_CARD, face = 0, price = 2_500)))
        assertEquals(OfferError.INVALID_FACE_VALUE, OfferRules.validate(draft(service = ServiceType.BALANCE_TOPUP, mode = PricingMode.NET_MULTIPLIER, face = 0, price = null)))
        assertEquals(OfferError.MULTIPLIER_ONLY_FOR_NET_BALANCE, OfferRules.validate(draft(service = ServiceType.DATA_PACKAGE, mode = PricingMode.NET_MULTIPLIER, face = 100, price = null)))
        assertEquals(OfferError.INVALID_PRICE, OfferRules.validate(draft(service = ServiceType.BALANCE_TOPUP, mode = PricingMode.NET_MULTIPLIER, face = 10_000, price = 15_000)))
        assertEquals(OfferError.INVALID_VALIDITY, OfferRules.validate(draft(from = 2_000, until = 2_000)))
        assertEquals(OfferError.INVALID_VALIDITY, OfferRules.validate(draft(from = 3_000, until = 2_000)))
        assertEquals(OfferError.DESCRIPTION_TOO_LONG, OfferRules.validate(draft(description = "x".repeat(301))))
    }
}
