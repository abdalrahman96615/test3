package com.factorycharge.core.util

object BeneficiaryPhone {
    private val EGYPT_MOBILE = Regex("^01[0125]\\d{8}$")

    /**
     * رقم المستفيد من الشحن: موبايل مصري من 11 رقماً (010/011/012/015). يقبل الأرقام العربية والمسافات
     * والشرطات، ومقدمة الدولة (+20 أو 0020 أو 20). يعيد الصيغة الموحدة 01XXXXXXXXX أو null.
     * لا نفرض تطابق بادئة الرقم مع الشبكة المختارة (قد يكون الرقم منقولاً بين الشبكات).
     */
    fun normalize(raw: String): String? {
        var d = Money.toAsciiDigits(raw.trim()).filterNot { it.isWhitespace() || it == '-' || it == '(' || it == ')' }
        d = when {
            d.startsWith("+20") -> "0" + d.removePrefix("+20")
            d.startsWith("0020") -> "0" + d.removePrefix("0020")
            d.length == 12 && d.startsWith("20") -> "0" + d.removePrefix("20")
            else -> d
        }
        return d.takeIf { EGYPT_MOBILE.matches(it) }
    }
}
