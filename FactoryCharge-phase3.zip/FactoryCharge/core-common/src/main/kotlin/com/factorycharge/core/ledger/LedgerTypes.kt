package com.factorycharge.core.ledger

import androidx.annotation.StringRes
import com.factorycharge.core.R

/**
 * نوع القيد (Posting) داخل الدفتر. كل قيد يغيّر الرصيد أو المديونية (واحداً منهما فقط).
 * المبلغ المخزَّن موجب دائماً، والاتجاه يحدده balanceDelta/debtDelta في القيد.
 */
enum class LedgerEntryType(@StringRes val labelRes: Int) {
    /** إضافة رصيد للمحفظة (الجزء الزائد من إيداع بعد تسوية المديونية). */
    WALLET_CREDIT(R.string.entry_wallet_credit),

    /** تسوية مديونية (تخفيض المديونية). */
    DEBT_SETTLEMENT(R.string.entry_debt_settlement),

    /** سحب نقدي (تسليم نقد للعميل من رصيد المحفظة). */
    CASH_WITHDRAWAL(R.string.entry_cash_withdrawal),

    /** استخدام جزء من رصيد المحفظة في عملية (سياسة partial). */
    WALLET_DEBIT(R.string.entry_wallet_debit),

    /** إنشاء مديونية (الفرق الذي تجاوز الرصيد في سياسة partial). */
    DEBT_CREATED(R.string.entry_debt_created),

    /** قيد عكسي يصحح قيداً سابقاً دون تعديله. */
    REVERSAL(R.string.entry_reversal),
}

/** نوع العملية التي تجمع قيداً أو أكثر تحت معرف عملية واحد. */
enum class OperationKind(@StringRes val labelRes: Int) {
    CASH_DEPOSIT(R.string.operation_cash_deposit),
    CASH_WITHDRAWAL(R.string.operation_cash_withdrawal),

    /** خصم من المحفظة مع الاستدانة عند الحاجة (للاستخدام المستقبلي؛ لا تنفيذ للشحن بعد). */
    CONSUMPTION(R.string.operation_consumption),
    REVERSAL(R.string.operation_reversal),
}

/** أسباب رفض العملية. لا يُسجَّل أي شيء في الدفتر عند الرفض. */
enum class OperationRejection(@StringRes val labelRes: Int) {
    INVALID_AMOUNT(R.string.reject_invalid_amount),
    AMOUNT_OVERFLOW(R.string.reject_amount_overflow),
    INSUFFICIENT_BALANCE(R.string.reject_insufficient_balance),
    CREDIT_LIMIT_EXCEEDED(R.string.reject_credit_limit_exceeded),
    REVERSAL_NEGATIVE_BALANCE(R.string.reject_reversal_negative_balance),
    REVERSAL_NEGATIVE_DEBT(R.string.reject_reversal_negative_debt),
    CUSTOMER_NOT_FOUND(R.string.reject_customer_not_found),
    CUSTOMER_INACTIVE(R.string.reject_customer_inactive),
    DUPLICATE_OPERATION(R.string.reject_duplicate_operation),
    INVALID_OPERATION_ID(R.string.reject_invalid_operation_id),
    ENTRY_NOT_FOUND(R.string.reject_entry_not_found),
    ENTRY_ALREADY_REVERSED(R.string.reject_entry_already_reversed),
    CANNOT_REVERSE_A_REVERSAL(R.string.reject_cannot_reverse_reversal),
    REQUEST_NOT_FOUND(R.string.reject_request_not_found),
    REQUEST_NOT_APPROVED(R.string.reject_request_not_approved),
}

/** أخطاء إدارة بيانات العميل (غير المالية). */
enum class CustomerError(@StringRes val labelRes: Int) {
    INVALID_NAME(R.string.customer_error_invalid_name),
    INVALID_PHONE(R.string.customer_error_invalid_phone),
    DUPLICATE_PHONE(R.string.customer_error_duplicate_phone),
    NOT_FOUND(R.string.customer_error_not_found),
    NEGATIVE_LIMIT(R.string.customer_error_negative_limit),
    LIMIT_BELOW_DEBT(R.string.customer_error_limit_below_debt),
}
