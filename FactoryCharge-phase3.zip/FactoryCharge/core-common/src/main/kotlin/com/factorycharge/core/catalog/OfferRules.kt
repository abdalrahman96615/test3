package com.factorycharge.core.catalog

import androidx.annotation.StringRes
import com.factorycharge.core.R
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.ServiceType

/** بيانات عرض كما يدخلها المسؤول (قبل التحقق). المبالغ بالقروش. */
data class OfferDraft(
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val name: String,
    val description: String?,
    val pricingMode: PricingMode,
    val faceValueMinor: Long,
    val fixedPriceMinor: Long?,
    val validFromMillis: Long?,
    val validUntilMillis: Long?,
    val sortOrder: Int,
)

enum class OfferError(@StringRes val labelRes: Int) {
    INVALID_PROVIDER(R.string.offer_error_provider),
    INVALID_NAME(R.string.offer_error_name),
    INVALID_FACE_VALUE(R.string.offer_error_face_value),
    INVALID_PRICE(R.string.offer_error_price),
    MULTIPLIER_ONLY_FOR_NET_BALANCE(R.string.offer_error_multiplier_mode),
    INVALID_VALIDITY(R.string.offer_error_validity),
    DESCRIPTION_TOO_LONG(R.string.offer_error_description),
    MULTIPLIER_NOT_SET(R.string.offer_error_multiplier_not_set),
    INVALID_MULTIPLIER(R.string.offer_error_multiplier_invalid),
    NOT_FOUND(R.string.offer_error_not_found),
}

object OfferRules {
    const val MAX_NAME = 100
    const val MAX_DESCRIPTION = 300

    fun cleanName(raw: String): String? =
        raw.trim().replace(Regex("\\s+"), " ").takeIf { it.isNotEmpty() && it.length <= MAX_NAME }

    /** يعيد null إن كان العرض صالحاً، وإلا أول خطأ. */
    fun validate(d: OfferDraft): OfferError? {
        if (d.provider !in NetworkProvider.selectable) return OfferError.INVALID_PROVIDER
        if (cleanName(d.name) == null) return OfferError.INVALID_NAME
        if ((d.description?.length ?: 0) > MAX_DESCRIPTION) return OfferError.DESCRIPTION_TOO_LONG
        if (d.faceValueMinor < 0) return OfferError.INVALID_FACE_VALUE
        if ((d.serviceType == ServiceType.BALANCE_TOPUP || d.serviceType == ServiceType.RECHARGE_CARD) && d.faceValueMinor <= 0) {
            return OfferError.INVALID_FACE_VALUE
        }
        when (d.pricingMode) {
            PricingMode.FIXED_PRICE -> if ((d.fixedPriceMinor ?: 0L) <= 0L) return OfferError.INVALID_PRICE
            PricingMode.NET_MULTIPLIER -> {
                if (d.serviceType != ServiceType.BALANCE_TOPUP) return OfferError.MULTIPLIER_ONLY_FOR_NET_BALANCE
                if (d.fixedPriceMinor != null) return OfferError.INVALID_PRICE
            }
        }
        val from = d.validFromMillis
        val until = d.validUntilMillis
        if (from != null && until != null && until <= from) return OfferError.INVALID_VALIDITY
        return null
    }
}
