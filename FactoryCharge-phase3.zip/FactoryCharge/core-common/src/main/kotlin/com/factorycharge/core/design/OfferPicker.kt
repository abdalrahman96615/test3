package com.factorycharge.core.design

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.factorycharge.core.R
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/** عرض جاهز للاختيار في الواجهة (السعر هنا للعرض فقط؛ المسؤول يعيد التحقق منه). */
data class OfferOption(
    val id: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val name: String,
    val description: String?,
    val faceValueMinor: Long,
    val priceMinor: Long,
)

/**
 * اختيار الشبكة ثم نوع الخدمة ثم العرض. حالة الشبكة والنوع محلية للشاشة؛ المختار الفعلي هو [selectedOfferId].
 * إن كان [selectedOfferId] معروفاً عند الفتح تُضبط الشبكة والنوع على عرضه.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfferPickerSection(
    offers: List<OfferOption>,
    selectedOfferId: String?,
    onOfferSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val providers = NetworkProvider.selectable.filter { p -> offers.any { it.provider == p } }
    val initial = offers.firstOrNull { it.id == selectedOfferId }
    var provider by remember { mutableStateOf(initial?.provider ?: providers.firstOrNull()) }
    var service by remember { mutableStateOf(initial?.serviceType) }

    val activeProvider = provider?.takeIf { it in providers } ?: providers.firstOrNull()
    val services = ServiceType.entries.filter { s -> offers.any { it.provider == activeProvider && it.serviceType == s } }
    val activeService = service?.takeIf { it in services } ?: services.firstOrNull()
    val visible = offers.filter { it.provider == activeProvider && it.serviceType == activeService }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.picker_network), style = MaterialTheme.typography.titleSmall)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            providers.forEach { p ->
                FilterChip(
                    selected = p == activeProvider,
                    onClick = { provider = p; service = null },
                    label = { Text(stringResource(p.labelRes)) },
                )
            }
        }
        Text(stringResource(R.string.picker_service), style = MaterialTheme.typography.titleSmall)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            services.forEach { s ->
                FilterChip(
                    selected = s == activeService,
                    onClick = { service = s },
                    label = { Text(stringResource(s.labelRes)) },
                )
            }
        }
        Text(stringResource(R.string.picker_offers), style = MaterialTheme.typography.titleSmall)
        if (visible.isEmpty()) {
            Text(
                stringResource(R.string.picker_no_offers),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        visible.forEach { offer ->
            val selected = offer.id == selectedOfferId
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                ),
                border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOfferSelected(offer.id) },
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(offer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    offer.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        if (offer.faceValueMinor > 0) {
                            Text(
                                stringResource(R.string.picker_face_value) + ": " + moneyLabel(offer.faceValueMinor),
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Text(
                            stringResource(R.string.picker_price) + ": " + moneyLabel(offer.priceMinor),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

/** شارة حالة الطلب بلون مناسب. */
@Composable
fun RequestStatusChip(status: RequestStatus, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val (container, content) = when (status) {
        RequestStatus.EXECUTED -> scheme.primaryContainer to scheme.onPrimaryContainer
        RequestStatus.REJECTED, RequestStatus.CANCELLED -> scheme.errorContainer to scheme.onErrorContainer
        RequestStatus.APPROVED -> scheme.tertiaryContainer to scheme.onTertiaryContainer
        else -> scheme.secondaryContainer to scheme.onSecondaryContainer
    }
    androidx.compose.material3.Surface(shape = RoundedCornerShape(50), color = container, contentColor = content, modifier = modifier) {
        Text(
            text = stringResource(status.labelRes),
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}
