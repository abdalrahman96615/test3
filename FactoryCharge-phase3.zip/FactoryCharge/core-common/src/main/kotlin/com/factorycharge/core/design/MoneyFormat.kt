package com.factorycharge.core.design

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.factorycharge.core.R
import com.factorycharge.core.util.Money

/** مبلغ بالقروش بصيغة مقروءة مع رمز العملة، مثل: 1,234.50 ج.م */
@Composable
fun moneyLabel(amountMinor: Long): String =
    stringResource(R.string.money_amount, Money.formatGrouped(amountMinor))
