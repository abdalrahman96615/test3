package com.factorycharge.core.request

import androidx.annotation.StringRes
import com.factorycharge.core.R
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.util.BeneficiaryPhone

/** صورة العرض كما تراها قواعد التحقق (من الكتالوج المحلي عند العميل أو الكتالوج المعتمد عند المسؤول). */
data class OfferView(
    val id: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val name: String,
    val faceValueMinor: Long,
    val priceMinor: Long?,
    val isActive: Boolean,
    val validFromMillis: Long?,
    val validUntilMillis: Long?,
)

enum class RequestRejection(@StringRes val labelRes: Int) {
    OFFER_NOT_FOUND(R.string.req_reject_offer_not_found),
    OFFER_INACTIVE(R.string.req_reject_offer_inactive),
    OFFER_NOT_YET_VALID(R.string.req_reject_offer_not_yet_valid),
    OFFER_EXPIRED(R.string.req_reject_offer_expired),
    OFFER_MISMATCH(R.string.req_reject_offer_mismatch),
    PRICE_UNAVAILABLE(R.string.req_reject_price_unavailable),
    INVALID_BENEFICIARY(R.string.req_reject_beneficiary),
    NOTE_TOO_LONG(R.string.req_reject_note_too_long),
    INVALID_REQUEST_ID(R.string.req_reject_invalid_id),
    DUPLICATE_REQUEST(R.string.req_reject_duplicate),
    CUSTOMER_NOT_FOUND(R.string.reject_customer_not_found),
    CUSTOMER_INACTIVE(R.string.reject_customer_inactive),
    REQUEST_NOT_FOUND(R.string.reject_request_not_found),
    INVALID_TRANSITION(R.string.req_reject_invalid_transition),
    REASON_REQUIRED(R.string.req_reject_reason_required),
    USE_EXECUTE_ACTION(R.string.req_reject_use_execute),
    NO_LOCAL_ACCOUNT(R.string.req_reject_no_account),
}

sealed interface RequestCheck {
    data class Ok(val offer: OfferView, val priceMinor: Long, val beneficiary: String, val note: String?) : RequestCheck
    data class Rejected(val reason: RequestRejection) : RequestCheck
}

/**
 * قواعد قبول طلب شحن، مشتركة بين التطبيقين: العميل يستخدمها محلياً (سعر الكتالوج المحلي غير موثوق)،
 * والمسؤول يعيد تشغيلها على كتالوجه المعتمد عند الاستلام. لا تلمس أي رصيد.
 */
object RequestRules {
    const val MAX_NOTE = 200

    fun check(
        offer: OfferView?,
        provider: NetworkProvider,
        serviceType: ServiceType,
        targetPhoneRaw: String,
        note: String?,
        nowMillis: Long,
    ): RequestCheck {
        fun reject(r: RequestRejection) = RequestCheck.Rejected(r)
        if (offer == null) return reject(RequestRejection.OFFER_NOT_FOUND)
        if (!offer.isActive) return reject(RequestRejection.OFFER_INACTIVE)
        val from = offer.validFromMillis
        val until = offer.validUntilMillis
        if (from != null && nowMillis < from) return reject(RequestRejection.OFFER_NOT_YET_VALID)
        if (until != null && nowMillis > until) return reject(RequestRejection.OFFER_EXPIRED)
        if (offer.provider != provider || offer.serviceType != serviceType) return reject(RequestRejection.OFFER_MISMATCH)
        val price = offer.priceMinor
        if (price == null || price <= 0 || offer.faceValueMinor < 0) return reject(RequestRejection.PRICE_UNAVAILABLE)
        val beneficiary = BeneficiaryPhone.normalize(targetPhoneRaw) ?: return reject(RequestRejection.INVALID_BENEFICIARY)
        val cleanNote = note?.trim()?.ifBlank { null }
        if ((cleanNote?.length ?: 0) > MAX_NOTE) return reject(RequestRejection.NOTE_TOO_LONG)
        return RequestCheck.Ok(offer, price, beneficiary, cleanNote)
    }
}
