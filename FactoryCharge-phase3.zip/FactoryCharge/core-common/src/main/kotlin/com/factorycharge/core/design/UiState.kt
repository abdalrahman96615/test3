package com.factorycharge.core.design

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val cause: Throwable? = null) : UiState<Nothing>
}
