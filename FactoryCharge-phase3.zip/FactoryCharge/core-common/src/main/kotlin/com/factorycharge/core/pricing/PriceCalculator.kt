package com.factorycharge.core.pricing

import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.util.Money
import java.math.BigDecimal

/**
 * حسابات التسعير بأعداد صحيحة فقط. المعامل يُخزَّن بنقاط أساس (Basis Points): 10000 = 1.0، و15000 = 1.5.
 * لا توجد قيمة معامل ثابتة هنا؛ تأتي دائماً من إعدادات يحددها المسؤول.
 */
object PriceCalculator {
    const val BASIS_POINTS: Long = 10_000L

    /** حد أقصى للمعامل (100×) لمنع إدخال خاطئ. */
    const val MAX_MULTIPLIER_BP: Long = 1_000_000L

    /**
     * سعر الرصيد الصافي = القيمة × المعامل، بالتقريب لأقرب قرش (نصف لأعلى).
     * يعيد null للمدخلات غير الصالحة أو الفيض أو الناتج غير الموجب.
     */
    fun netBalancePrice(faceValueMinor: Long, multiplierBp: Long): Long? {
        if (faceValueMinor <= 0 || multiplierBp <= 0 || multiplierBp > MAX_MULTIPLIER_BP) return null
        val product = try {
            Math.multiplyExact(faceValueMinor, multiplierBp)
        } catch (e: ArithmeticException) {
            return null
        }
        if (product > Long.MAX_VALUE - BASIS_POINTS / 2) return null
        val price = (product + BASIS_POINTS / 2) / BASIS_POINTS
        return if (price > 0) price else null
    }

    /** سعر العرض حسب طريقة تسعيره؛ null إن تعذّر (لا معامل محدد، أو سعر ثابت غير صالح). */
    fun priceFor(mode: PricingMode, faceValueMinor: Long, fixedPriceMinor: Long?, multiplierBp: Long?): Long? =
        when (mode) {
            PricingMode.FIXED_PRICE -> fixedPriceMinor?.takeIf { it > 0 }
            PricingMode.NET_MULTIPLIER -> multiplierBp?.let { netBalancePrice(faceValueMinor, it) }
        }

    /** يعرض المعامل بمنزلتين على الأقل: 15000 -> 1.50 */
    fun formatMultiplier(multiplierBp: Long): String {
        val stripped = BigDecimal.valueOf(multiplierBp, 4).stripTrailingZeros()
        return (if (stripped.scale() < 2) stripped.setScale(2) else stripped).toPlainString()
    }

    /** يحوّل نص المعامل (حتى 4 منازل) إلى نقاط أساس؛ null إن كان غير صالح أو خارج المدى. */
    fun parseMultiplier(input: String): Long? {
        val cleaned = Money.toAsciiDigits(input.trim()).replace('٫', '.').replace(",", ".")
        if (!Regex("^\\d+(\\.\\d{1,4})?$").matches(cleaned)) return null
        val bp = try {
            BigDecimal(cleaned).movePointRight(4).longValueExact()
        } catch (e: ArithmeticException) {
            return null
        }
        return bp.takeIf { it in 1..MAX_MULTIPLIER_BP }
    }
}
