package com.factorycharge.core.util

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** تواريخ نصية بأرقام لاتينية (yyyy/MM/dd) دون اعتماد على لغة الجهاز. */
object DateText {
    /** بداية اليوم من نص مثل 2026/11/05 (تقبل - بدل / والأرقام العربية)؛ null إن كان غير صالح. */
    fun parseDayStart(text: String): Long? {
        val t = Money.toAsciiDigits(text.trim()).replace('-', '/')
        if (!Regex("^\\d{4}/\\d{1,2}/\\d{1,2}$").matches(t)) return null
        val format = SimpleDateFormat("yyyy/M/d", Locale.US).apply { isLenient = false }
        return try {
            format.parse(t)?.time
        } catch (e: ParseException) {
            null
        }
    }

    /** آخر لحظة في اليوم (23:59:59.999). */
    fun parseDayEnd(text: String): Long? = parseDayStart(text)?.let { start ->
        Calendar.getInstance().apply {
            timeInMillis = start
            add(Calendar.DAY_OF_MONTH, 1)
        }.timeInMillis - 1
    }

    fun formatDay(millis: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(millis))

    fun formatDateTime(millis: Long): String = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(Date(millis))
}
