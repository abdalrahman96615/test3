package com.factorycharge.client

import com.factorycharge.client.data.Converters
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import org.junit.Assert.assertEquals
import org.junit.Test

class ConvertersTest {
    private val c = Converters()

    @Test
    fun enumsRoundTrip() {
        NetworkProvider.entries.forEach { assertEquals(it, c.stringToProvider(c.providerToString(it))) }
        ServiceType.entries.forEach { assertEquals(it, c.stringToService(c.serviceToString(it))) }
        RequestStatus.entries.forEach { assertEquals(it, c.stringToStatus(c.statusToString(it))) }
    }

    /** الاستعلام في PendingRequestDao يستخدم هذا الاسم كنص ثابت. */
    @Test
    fun pendingQueryNameMatchesEnum() {
        assertEquals("PENDING_LOCAL", RequestStatus.PENDING_LOCAL.name)
    }
}
