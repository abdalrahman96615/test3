package com.factorycharge.client

import android.database.sqlite.SQLiteDatabase
import com.factorycharge.client.data.ClientDatabase
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** 14) الحفاظ على البيانات عند Migration 1 -> 2 لقاعدة العميل (Room يتحقق من المخطط بعد الترحيل). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ClientMigrationTest {
    @Test
    fun migrationFrom1To2KeepsRequestsAndWalletSnapshot() {
        val ctx = RuntimeEnvironment.getApplication()
        val file = ctx.getDatabasePath(ClientDatabase.FILE_NAME)
        file.parentFile?.mkdirs()
        val raw = SQLiteDatabase.openOrCreateDatabase(file, null)
        try {
            raw.execSQL("CREATE TABLE `pending_requests` (`id` TEXT NOT NULL, `customerId` TEXT NOT NULL, `provider` TEXT NOT NULL, `serviceType` TEXT NOT NULL, `targetPhone` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `status` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, `note` TEXT, PRIMARY KEY(`id`))")
            raw.execSQL("CREATE INDEX `index_pending_requests_status` ON `pending_requests` (`status`)")
            raw.execSQL("CREATE TABLE `wallet_snapshot` (`customerId` TEXT NOT NULL, `balanceMinor` INTEGER NOT NULL, `debtMinor` INTEGER NOT NULL, `currencyCode` TEXT NOT NULL, `sequence` INTEGER NOT NULL, `issuedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`customerId`))")
            raw.execSQL("INSERT INTO pending_requests VALUES('r1','c1','ORANGE','DATA_PACKAGE','01212345678',3000,'PENDING_LOCAL',5,6,'قديم')")
            raw.execSQL("INSERT INTO wallet_snapshot VALUES('c1',5000,200,'EGP',7,8)")
            raw.version = 1
        } finally {
            raw.close()
        }

        val db = ClientDatabase.build(ctx)
        try {
            runBlocking {
                val r = db.pendingRequestDao().getById("r1")!!
                assertEquals(NetworkProvider.ORANGE, r.provider)
                assertEquals(ServiceType.DATA_PACKAGE, r.serviceType)
                assertEquals("01212345678", r.targetPhone)
                assertEquals(3_000L, r.faceValueMinor)
                assertEquals(3_000L, r.customerPriceMinor)
                assertEquals(RequestStatus.PENDING_LOCAL, r.status)
                assertEquals("قديم", r.note)
                assertEquals("", r.offerId)
                assertNull(r.statusNote)
                assertEquals(5L, r.createdAtMillis)

                val wallet = db.walletSnapshotDao().observeLatest().first()!!
                assertEquals(5_000L, wallet.balanceMinor)
                assertEquals(200L, wallet.debtMinor)
                assertEquals(7L, wallet.sequence)

                // الجداول الجديدة فارغة تماماً (لا كتالوج ولا حساب افتراضي)
                assertEquals(0, db.catalogDao().count())
                assertNull(db.localAccountDao().get())
            }
        } finally {
            db.close()
        }
    }
}
