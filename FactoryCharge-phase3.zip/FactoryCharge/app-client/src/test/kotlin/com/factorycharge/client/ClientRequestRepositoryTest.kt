package com.factorycharge.client

import androidx.room.Room
import com.factorycharge.client.data.CatalogOfferEntity
import com.factorycharge.client.data.ClientDatabase
import com.factorycharge.client.data.ClientRequestRepository
import com.factorycharge.client.data.CreateRequestOutcome
import com.factorycharge.client.data.LocalAccountEntity
import com.factorycharge.client.data.WalletSnapshotEntity
import com.factorycharge.client.data.isAvailableAt
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.request.RequestRejection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** بيانات الكتالوج والحساب هنا لهذه الاختبارات فقط (قاعدة في الذاكرة)، لا شيء منها في قاعدة المستخدم. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ClientRequestRepositoryTest {
    private lateinit var db: ClientDatabase
    private lateinit var repo: ClientRequestRepository
    private var now = 1_000L

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(), ClientDatabase::class.java).allowMainThreadQueries().build()
        repo = ClientRequestRepository(db, nowMillis = { now })
    }

    @After
    fun tearDown() = db.close()

    private fun inTest(block: suspend CoroutineScope.() -> Unit) {
        runBlocking(block = block)
    }

    private suspend fun account() = db.localAccountDao().upsert(LocalAccountEntity("c1", "عميل", "01011111111", 1))

    private suspend fun offer(
        id: String = "o1",
        active: Boolean = true,
        price: Long = 15_000,
        from: Long? = null,
        until: Long? = null,
    ) = db.catalogDao().upsertAll(
        listOf(CatalogOfferEntity(id, NetworkProvider.VODAFONE, ServiceType.BALANCE_TOPUP, "شحن 100", null, 10_000, price, active, 0, from, until, 1, 1)),
    )

    private fun rejected(o: CreateRequestOutcome) = (o as CreateRequestOutcome.Rejected).reason

    @Test
    fun withoutLocalAccountOrCatalogNoRequestCanBeCreated() = inTest {
        assertEquals(RequestRejection.NO_LOCAL_ACCOUNT, rejected(repo.createRequest("r1", "o1", "01012345678", null)))
        account()
        assertEquals(RequestRejection.OFFER_NOT_FOUND, rejected(repo.createRequest("r1", "o1", "01012345678", null))) // كتالوج فارغ
        assertEquals(0, db.pendingRequestDao().count())
    }

    // ---- 7) إنشاء الطلب لا يغيّر الحساب ولا يخصم شيئاً، ويُحفظ محلياً بحالة PENDING_LOCAL
    @Test
    fun createdRequestIsPendingLocalAndLeavesWalletUntouched() = inTest {
        account()
        offer()
        db.walletSnapshotDao().replaceFromAdmin(WalletSnapshotEntity("c1", 5_000, 0, "EGP", 1, 1))

        val created = (repo.createRequest("r1", "o1", "+20 101 234 5678", "  مستعجل ") as CreateRequestOutcome.Created).request
        assertEquals(RequestStatus.PENDING_LOCAL, created.status)
        assertEquals("c1", created.customerId)
        assertEquals("o1", created.offerId)
        assertEquals("01012345678", created.targetPhone)
        assertEquals(10_000L, created.faceValueMinor)
        assertEquals(15_000L, created.customerPriceMinor)
        assertEquals("مستعجل", created.note)
        assertEquals(created, db.pendingRequestDao().getById("r1"))

        val wallet = db.walletSnapshotDao().observeLatest().first()!!
        assertEquals(5_000L, wallet.balanceMinor)
        assertEquals(0L, wallet.debtMinor)
        assertEquals(1, db.pendingRequestDao().observePendingCount().first())
        assertEquals(1, db.pendingRequestDao().observeOpenCount().first())
    }

    // ---- 4) رفض عرض غير فعال / منتهٍ / بسعر صفري
    @Test
    fun inactiveExpiredOrUnpricedOffersAreRejected() = inTest {
        account()
        offer(id = "off", active = false)
        offer(id = "exp", until = 500)
        offer(id = "future", from = 5_000)
        offer(id = "zero", price = 0)
        assertEquals(RequestRejection.OFFER_INACTIVE, rejected(repo.createRequest("a", "off", "01012345678", null)))
        assertEquals(RequestRejection.OFFER_EXPIRED, rejected(repo.createRequest("b", "exp", "01012345678", null)))
        assertEquals(RequestRejection.OFFER_NOT_YET_VALID, rejected(repo.createRequest("c", "future", "01012345678", null)))
        assertEquals(RequestRejection.PRICE_UNAVAILABLE, rejected(repo.createRequest("d", "zero", "01012345678", null)))
        assertEquals(0, db.pendingRequestDao().count())
    }

    // ---- 5) رفض رقم مستفيد غير صالح
    @Test
    fun invalidBeneficiaryIsRejected() = inTest {
        account()
        offer()
        listOf("", "123", "0101234567", "01312345678", "abc").forEach {
            assertEquals(RequestRejection.INVALID_BENEFICIARY, rejected(repo.createRequest("r-$it", "o1", it, null)))
        }
        assertEquals(RequestRejection.NOTE_TOO_LONG, rejected(repo.createRequest("rn", "o1", "01012345678", "x".repeat(201))))
        assertEquals(0, db.pendingRequestDao().count())
    }

    @Test
    fun duplicateRequestIdIsRejectedAndKeepsOriginal() = inTest {
        account()
        offer()
        repo.createRequest("same", "o1", "01012345678", "الأول")
        assertEquals(RequestRejection.DUPLICATE_REQUEST, rejected(repo.createRequest("same", "o1", "01099999999", "الثاني")))
        assertEquals(1, db.pendingRequestDao().count())
        assertEquals("الأول", db.pendingRequestDao().getById("same")!!.note)
        assertEquals(RequestRejection.INVALID_REQUEST_ID, rejected(repo.createRequest(" ", "o1", "01012345678", null)))
    }

    @Test
    fun offerAvailabilityHonoursActiveFlagAndValidityWindow() {
        fun o(active: Boolean = true, from: Long? = null, until: Long? = null) =
            CatalogOfferEntity("x", NetworkProvider.WE, ServiceType.OTHER, "n", null, 0, 100, active, 0, from, until, 1, 1)
        assertTrue(o().isAvailableAt(1_000))
        assertFalse(o(active = false).isAvailableAt(1_000))
        assertFalse(o(until = 999).isAvailableAt(1_000))
        assertTrue(o(until = 1_000).isAvailableAt(1_000))
        assertFalse(o(from = 1_001).isAvailableAt(1_000))
    }

    @Test
    fun emptyCatalogAndAccountByDefault() = inTest {
        assertEquals(0, db.catalogDao().count())
        assertNull(db.localAccountDao().get())
        assertEquals(0, db.pendingRequestDao().count())
    }
}
