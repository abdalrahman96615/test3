package com.factorycharge.client.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/**
 * طلب أنشأه العميل محلياً بحالة PENDING_LOCAL. ليس قيداً مالياً ولا يغيّر أي رصيد، ولا يُخصم شيء بإنشائه.
 * [customerPriceMinor] هو السعر الذي عُرض على العميل من نسخة الكتالوج المحلية (غير موثوق):
 * يعيد المسؤول حساب السعر من كتالوجه عند الاستلام ولا يعتمد هذا الرقم.
 * [statusNote] سبب قرار المسؤول (رفض/إلغاء) حين تُنفَّذ المزامنة لاحقاً.
 */
@Entity(tableName = "pending_requests", indices = [Index("status"), Index("createdAtMillis")])
data class PendingRequestEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val offerId: String,
    val offerName: String,
    val targetPhone: String,
    val faceValueMinor: Long,
    val customerPriceMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String?,
    val statusNote: String?,
)

/**
 * نسخة محلية للقراءة فقط من كتالوج المسؤول (تُملأ بالمزامنة في مرحلة لاحقة؛ فارغة حتى ذلك الحين ولا بيانات
 * افتراضية). [customerPriceMinor] السعر النهائي المحسوب عند المسؤول وقت المزامنة.
 */
@Entity(
    tableName = "catalog_offers",
    indices = [Index(value = ["provider", "serviceType", "isActive", "sortOrder"])],
)
data class CatalogOfferEntity(
    @PrimaryKey val id: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val name: String,
    val description: String?,
    val faceValueMinor: Long,
    val customerPriceMinor: Long,
    val isActive: Boolean,
    val sortOrder: Int,
    val validFromMillis: Long?,
    val validUntilMillis: Long?,
    val revision: Long,
    val syncedAtMillis: Long,
)

/** هوية هذا الجهاز كما سجلها المسؤول (نسخة للقراءة فقط تُملأ بالمزامنة لاحقاً). */
@Entity(tableName = "local_account")
data class LocalAccountEntity(
    @PrimaryKey val customerId: String,
    val displayName: String,
    val registeredPhone: String,
    val updatedAtMillis: Long,
)

/**
 * نسخة للعرض فقط من حساب العميل كما أصدرها المسؤول.
 * لا يوجد في هذا التطبيق جدول للقيود المالية المعتمدة عمداً.
 * هذه النسخة مجرد كاش غير موثَّق في المرحلة 1: لا توقيع ولا تحقق من مصدرها بعد،
 * ويمكن تعديلها من أي شخص يتحكم بالهاتف. لا تُبنى عليها أي عملية مالية.
 */
@Entity(tableName = "wallet_snapshot")
data class WalletSnapshotEntity(
    @PrimaryKey val customerId: String,
    val balanceMinor: Long,
    val debtMinor: Long,
    val currencyCode: String,
    val sequence: Long,
    val issuedAtMillis: Long,
)

/** العرض فعّال وضمن فترة صلاحيته في اللحظة [nowMillis]. */
fun CatalogOfferEntity.isAvailableAt(nowMillis: Long): Boolean =
    isActive && (validFromMillis?.let { nowMillis >= it } ?: true) && (validUntilMillis?.let { nowMillis <= it } ?: true)
