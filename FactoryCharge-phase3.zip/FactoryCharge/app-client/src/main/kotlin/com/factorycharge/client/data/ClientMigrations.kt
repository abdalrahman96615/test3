package com.factorycharge.client.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * ترحيلات قاعدة العميل (لا destructive migration).
 * 1 -> 2 (المرحلة 3): إعادة بناء pending_requests بأعمدة الكتالوج والتسعير، وإضافة catalog_offers و local_account.
 * الطلبات القديمة تُنقل كما هي (amountMinor يصبح القيمة الاسمية وسعر العميل، وoffer فارغ)، و wallet_snapshot لا يُمسّ.
 */
object ClientMigrations {
    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            MIGRATION_1_2_SQL.forEach { db.execSQL(it) }
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)

    internal val MIGRATION_1_2_SQL: List<String> = listOf(
        "CREATE TABLE `pending_requests_new` (`id` TEXT NOT NULL, `customerId` TEXT NOT NULL, `provider` TEXT NOT NULL, " +
            "`serviceType` TEXT NOT NULL, `offerId` TEXT NOT NULL, `offerName` TEXT NOT NULL, `targetPhone` TEXT NOT NULL, " +
            "`faceValueMinor` INTEGER NOT NULL, `customerPriceMinor` INTEGER NOT NULL, `status` TEXT NOT NULL, " +
            "`createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, `note` TEXT, `statusNote` TEXT, PRIMARY KEY(`id`))",
        "INSERT INTO `pending_requests_new` (`id`, `customerId`, `provider`, `serviceType`, `offerId`, `offerName`, `targetPhone`, " +
            "`faceValueMinor`, `customerPriceMinor`, `status`, `createdAtMillis`, `updatedAtMillis`, `note`, `statusNote`) " +
            "SELECT `id`, `customerId`, `provider`, `serviceType`, '', '', `targetPhone`, `amountMinor`, `amountMinor`, `status`, " +
            "`createdAtMillis`, `updatedAtMillis`, `note`, NULL FROM `pending_requests`",
        "DROP TABLE `pending_requests`",
        "ALTER TABLE `pending_requests_new` RENAME TO `pending_requests`",
        "CREATE INDEX IF NOT EXISTS `index_pending_requests_status` ON `pending_requests` (`status`)",
        "CREATE INDEX IF NOT EXISTS `index_pending_requests_createdAtMillis` ON `pending_requests` (`createdAtMillis`)",
        "CREATE TABLE IF NOT EXISTS `catalog_offers` (`id` TEXT NOT NULL, `provider` TEXT NOT NULL, `serviceType` TEXT NOT NULL, " +
            "`name` TEXT NOT NULL, `description` TEXT, `faceValueMinor` INTEGER NOT NULL, `customerPriceMinor` INTEGER NOT NULL, " +
            "`isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, `validFromMillis` INTEGER, `validUntilMillis` INTEGER, " +
            "`revision` INTEGER NOT NULL, `syncedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))",
        "CREATE INDEX IF NOT EXISTS `index_catalog_offers_provider_serviceType_isActive_sortOrder` " +
            "ON `catalog_offers` (`provider`, `serviceType`, `isActive`, `sortOrder`)",
        "CREATE TABLE IF NOT EXISTS `local_account` (`customerId` TEXT NOT NULL, `displayName` TEXT NOT NULL, " +
            "`registeredPhone` TEXT NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`customerId`))",
    )
}
