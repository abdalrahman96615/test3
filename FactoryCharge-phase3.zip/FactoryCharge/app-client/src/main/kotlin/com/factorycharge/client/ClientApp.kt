package com.factorycharge.client

import android.app.Application
import com.factorycharge.client.data.ClientDatabase
import com.factorycharge.client.data.ClientRequestRepository

class ClientApp : Application() {
    val database: ClientDatabase by lazy { ClientDatabase.build(this) }
    val requestRepository: ClientRequestRepository by lazy { ClientRequestRepository(database) }
}
