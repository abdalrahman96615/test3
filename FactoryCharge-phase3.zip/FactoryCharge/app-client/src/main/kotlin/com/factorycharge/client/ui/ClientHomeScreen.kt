package com.factorycharge.client.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.client.R
import com.factorycharge.client.data.WalletSnapshotEntity
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.StatCard
import com.factorycharge.core.design.UiState
import com.factorycharge.core.util.Money

@Composable
fun ClientHomeScreen(
    onNewRequest: () -> Unit,
    onCatalog: () -> Unit,
    onMyRequests: () -> Unit,
    viewModel: ClientHomeViewModel = viewModel(factory = ClientHomeViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    ClientScaffold(title = stringResource(R.string.home_title)) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::load)
                is UiState.Success -> ClientHomeContent(s.data, onNewRequest, onCatalog, onMyRequests)
            }
        }
    }
}

@Composable
private fun ClientHomeContent(
    data: ClientHomeData,
    onNewRequest: () -> Unit,
    onCatalog: () -> Unit,
    onMyRequests: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        InfoBanner(text = stringResource(R.string.home_readonly_banner), icon = Icons.Default.Info)
        InfoBanner(text = stringResource(R.string.home_offline_banner), icon = Icons.Default.Warning)
        val wallet = data.wallet
        if (wallet == null) {
            EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.wallet_empty_title),
                message = stringResource(R.string.wallet_empty_message),
            )
        } else {
            WalletCard(wallet)
        }
        StatCard(
            label = stringResource(R.string.stat_open_requests),
            value = data.openRequests.toString(),
            icon = Icons.Default.Notifications,
            modifier = Modifier.fillMaxWidth(),
        )

        val canRequest = data.hasAccount && data.offersAvailable > 0
        Button(
            onClick = onNewRequest,
            enabled = canRequest,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.action_new_request), style = MaterialTheme.typography.titleMedium) }
        if (!canRequest) {
            Text(
                text = stringResource(if (!data.hasAccount) R.string.request_blocked_no_account else R.string.request_blocked_no_catalog),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedButton(onClick = onCatalog, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.action_catalog))
        }
        OutlinedButton(onClick = onMyRequests, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.action_my_requests))
        }
    }
}

@Composable
private fun WalletCard(wallet: WalletSnapshotEntity) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            WalletValue(
                label = stringResource(R.string.wallet_balance),
                value = Money.format(wallet.balanceMinor, wallet.currencyCode),
                modifier = Modifier.weight(1f),
            )
            WalletValue(
                label = stringResource(R.string.wallet_debt),
                value = Money.format(wallet.debtMinor, wallet.currencyCode),
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun WalletValue(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
    }
}
