package com.factorycharge.client.data

import androidx.room.TypeConverter
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

class Converters {
    @TypeConverter fun providerToString(v: NetworkProvider): String = v.name
    @TypeConverter fun stringToProvider(v: String): NetworkProvider = NetworkProvider.valueOf(v)

    @TypeConverter fun serviceToString(v: ServiceType): String = v.name
    @TypeConverter fun stringToService(v: String): ServiceType = ServiceType.valueOf(v)

    @TypeConverter fun statusToString(v: RequestStatus): String = v.name
    @TypeConverter fun stringToStatus(v: String): RequestStatus = RequestStatus.valueOf(v)
}
