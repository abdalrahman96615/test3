package com.factorycharge.client.data

import androidx.room.withTransaction
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.request.OfferView
import com.factorycharge.core.request.RequestCheck
import com.factorycharge.core.request.RequestRejection
import com.factorycharge.core.request.RequestRules

sealed interface CreateRequestOutcome {
    data class Created(val request: PendingRequestEntity) : CreateRequestOutcome
    data class Rejected(val reason: RequestRejection) : CreateRequestOutcome
}

/**
 * إنشاء طلبات الشحن على جهاز العميل. **لا يلمس أي رصيد أو مديونية** (لا يوجد هنا نظام مالي أصلاً):
 * يُحفظ الطلب بحالة PENDING_LOCAL فقط. الأسعار من الكتالوج المحلي غير موثوقة؛ المسؤول يعيد التحقق منها عند الاستلام.
 */
class ClientRequestRepository(
    private val db: ClientDatabase,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) {
    /** [requestId] يولّده الطالب مرة واحدة لكل نموذج، فتكرار الإرسال لا ينشئ طلبين. */
    suspend fun createRequest(
        requestId: String,
        offerId: String,
        targetPhone: String,
        note: String?,
    ): CreateRequestOutcome = db.withTransaction<CreateRequestOutcome> {
        if (requestId.isBlank()) return@withTransaction CreateRequestOutcome.Rejected(RequestRejection.INVALID_REQUEST_ID)
        if (db.pendingRequestDao().getById(requestId) != null) {
            return@withTransaction CreateRequestOutcome.Rejected(RequestRejection.DUPLICATE_REQUEST)
        }
        val account = db.localAccountDao().get()
            ?: return@withTransaction CreateRequestOutcome.Rejected(RequestRejection.NO_LOCAL_ACCOUNT)
        val offer = db.catalogDao().getById(offerId)
        val now = nowMillis()
        val view = offer?.let {
            OfferView(it.id, it.provider, it.serviceType, it.name, it.faceValueMinor, it.customerPriceMinor, it.isActive, it.validFromMillis, it.validUntilMillis)
        }
        val check = RequestRules.check(view, offer?.provider ?: com.factorycharge.core.model.NetworkProvider.OTHER, offer?.serviceType ?: com.factorycharge.core.model.ServiceType.OTHER, targetPhone, note, now)
        when (check) {
            is RequestCheck.Rejected -> CreateRequestOutcome.Rejected(check.reason)
            is RequestCheck.Ok -> {
                val entity = PendingRequestEntity(
                    id = requestId,
                    customerId = account.customerId,
                    provider = check.offer.provider,
                    serviceType = check.offer.serviceType,
                    offerId = check.offer.id,
                    offerName = check.offer.name,
                    targetPhone = check.beneficiary,
                    faceValueMinor = check.offer.faceValueMinor,
                    customerPriceMinor = check.priceMinor,
                    status = RequestStatus.PENDING_LOCAL,
                    createdAtMillis = now,
                    updatedAtMillis = now,
                    note = check.note,
                    statusNote = null,
                )
                db.pendingRequestDao().insert(entity)
                CreateRequestOutcome.Created(entity)
            }
        }
    }
}
