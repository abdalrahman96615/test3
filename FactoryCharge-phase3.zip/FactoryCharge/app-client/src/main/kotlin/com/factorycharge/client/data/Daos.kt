package com.factorycharge.client.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingRequestDao {
    /** الاسم هنا يجب أن يطابق RequestStatus.PENDING_LOCAL. */
    @Query("SELECT COUNT(*) FROM pending_requests WHERE status = 'PENDING_LOCAL'")
    fun observePendingCount(): Flow<Int>

    /** الطلبات الجارية (غير النهائية): PENDING_LOCAL و SUBMITTED و UNDER_REVIEW و APPROVED. */
    @Query("SELECT COUNT(*) FROM pending_requests WHERE status IN ('PENDING_LOCAL', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED')")
    fun observeOpenCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(request: PendingRequestEntity)

    @Query("SELECT * FROM pending_requests ORDER BY createdAtMillis DESC, id DESC")
    fun observeAll(): Flow<List<PendingRequestEntity>>

    @Query("SELECT * FROM pending_requests WHERE id = :id")
    fun observeById(id: String): Flow<PendingRequestEntity?>

    @Query("SELECT * FROM pending_requests WHERE id = :id")
    suspend fun getById(id: String): PendingRequestEntity?

    @Query("SELECT COUNT(*) FROM pending_requests")
    suspend fun count(): Int
}

@Dao
interface CatalogDao {
    /** للاستخدام من طبقة المزامنة فقط (مرحلة لاحقة)؛ لا تستدعيها أي شاشة. */
    @Upsert
    suspend fun upsertAll(offers: List<CatalogOfferEntity>)

    @Query("SELECT * FROM catalog_offers ORDER BY provider, serviceType, sortOrder, name")
    fun observeAll(): Flow<List<CatalogOfferEntity>>

    @Query("SELECT * FROM catalog_offers WHERE id = :id")
    suspend fun getById(id: String): CatalogOfferEntity?

    @Query("SELECT COUNT(*) FROM catalog_offers")
    suspend fun count(): Int
}

@Dao
interface LocalAccountDao {
    /** للاستخدام من طبقة المزامنة فقط (مرحلة لاحقة). */
    @Upsert
    suspend fun upsert(account: LocalAccountEntity)

    @Query("SELECT * FROM local_account LIMIT 1")
    fun observe(): Flow<LocalAccountEntity?>

    @Query("SELECT * FROM local_account LIMIT 1")
    suspend fun get(): LocalAccountEntity?
}

@Dao
interface WalletSnapshotDao {
    @Query("SELECT * FROM wallet_snapshot ORDER BY issuedAtMillis DESC LIMIT 1")
    fun observeLatest(): Flow<WalletSnapshotEntity?>

    /**
     * للاستخدام من طبقة الاستلام فقط (تُبنى في مرحلة لاحقة بعد تصميم آلية التحقق).
     * يجب ألا تستدعيها أي شاشة مباشرة.
     */
    @Upsert
    suspend fun replaceFromAdmin(snapshot: WalletSnapshotEntity)
}
