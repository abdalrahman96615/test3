package com.factorycharge.client.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.factorycharge.client.R
import com.factorycharge.client.ui.CatalogScreen
import com.factorycharge.client.ui.ClientHomeScreen
import com.factorycharge.client.ui.ClientRequestDetailsScreen
import com.factorycharge.client.ui.MyRequestsScreen
import com.factorycharge.client.ui.NewRequestScreen
import com.factorycharge.core.design.OnboardingScreen

object ClientRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CATALOG = "catalog"
    const val MY_REQUESTS = "requests"
    const val NEW_REQUEST = "new_request?offerId={offerId}"
    const val REQUEST_DETAILS = "request/{id}"

    fun newRequest(offerId: String? = null) = if (offerId == null) "new_request" else "new_request?offerId=$offerId"
    fun request(id: String) = "request/$id"
}

@Composable
fun ClientNavHost(
    onboardingDone: Boolean,
    onOnboardingFinished: () -> Unit,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = if (onboardingDone) ClientRoutes.HOME else ClientRoutes.ONBOARDING,
    ) {
        composable(ClientRoutes.ONBOARDING) {
            OnboardingScreen(
                roleLabel = stringResource(R.string.onboarding_role),
                title = stringResource(R.string.onboarding_title),
                description = stringResource(R.string.onboarding_description),
                points = listOf(
                    stringResource(R.string.onboarding_point_1),
                    stringResource(R.string.onboarding_point_2),
                    stringResource(R.string.onboarding_point_3),
                ),
                continueLabel = stringResource(R.string.onboarding_start),
                onContinue = {
                    onOnboardingFinished()
                    navController.navigate(ClientRoutes.HOME) {
                        popUpTo(ClientRoutes.ONBOARDING) { inclusive = true }
                    }
                },
            )
        }
        composable(ClientRoutes.HOME) {
            ClientHomeScreen(
                onNewRequest = { navController.navigate(ClientRoutes.newRequest()) },
                onCatalog = { navController.navigate(ClientRoutes.CATALOG) },
                onMyRequests = { navController.navigate(ClientRoutes.MY_REQUESTS) },
            )
        }
        composable(ClientRoutes.CATALOG) {
            CatalogScreen(
                onBack = { navController.popBackStack() },
                onOffer = { id -> navController.navigate(ClientRoutes.newRequest(id)) },
            )
        }
        composable(
            ClientRoutes.NEW_REQUEST,
            arguments = listOf(navArgument("offerId") { type = NavType.StringType; nullable = true; defaultValue = null }),
        ) { entry ->
            NewRequestScreen(
                initialOfferId = entry.arguments?.getString("offerId"),
                onBack = { navController.popBackStack() },
                onCreated = { id ->
                    navController.navigate(ClientRoutes.request(id)) {
                        popUpTo(ClientRoutes.NEW_REQUEST) { inclusive = true }
                    }
                },
            )
        }
        composable(ClientRoutes.MY_REQUESTS) {
            MyRequestsScreen(
                onBack = { navController.popBackStack() },
                onOpen = { id -> navController.navigate(ClientRoutes.request(id)) },
            )
        }
        composable(
            ClientRoutes.REQUEST_DETAILS,
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
        ) { entry ->
            ClientRequestDetailsScreen(
                requestId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
    }
}
