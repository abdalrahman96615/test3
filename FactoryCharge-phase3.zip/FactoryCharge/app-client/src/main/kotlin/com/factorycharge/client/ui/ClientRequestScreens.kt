package com.factorycharge.client.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.client.R
import com.factorycharge.client.data.CatalogOfferEntity
import com.factorycharge.client.data.PendingRequestEntity
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.OfferPickerSection
import com.factorycharge.core.design.RequestStatusChip
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.util.DateText

// ------------------------------------------------------------------ كتالوج الخدمات

@Composable
fun CatalogScreen(
    onBack: () -> Unit,
    onOffer: (String) -> Unit,
    viewModel: CatalogViewModel = viewModel(factory = CatalogViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    ClientScaffold(title = stringResource(R.string.catalog_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = {})
                is UiState.Success -> if (s.data.isEmpty()) {
                    EmptyState(
                        icon = Icons.Default.ShoppingCart,
                        title = stringResource(R.string.catalog_empty_title),
                        message = stringResource(R.string.catalog_empty_message),
                    )
                } else {
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        s.data.groupBy { it.provider }.forEach { (provider, offers) ->
                            item(key = "h-" + provider.name) {
                                Text(stringResource(provider.labelRes), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            items(offers, key = { it.id }) { offer -> CatalogCard(offer, onClick = { onOffer(offer.id) }) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CatalogCard(offer: CatalogOfferEntity, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(offer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(offer.serviceType.labelRes), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            offer.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                if (offer.faceValueMinor > 0) {
                    Text(stringResource(R.string.face_value) + ": " + moneyLabel(offer.faceValueMinor), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                }
                Text(moneyLabel(offer.customerPriceMinor), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

// ------------------------------------------------------------------ طلب شحن (نموذج ثم تأكيد)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewRequestScreen(
    initialOfferId: String?,
    onBack: () -> Unit,
    onCreated: (String) -> Unit,
    viewModel: NewRequestViewModel = viewModel(factory = NewRequestViewModel.factory(initialOfferId)),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state.createdId) {
        state.createdId?.let(onCreated)
    }
    ClientScaffold(title = stringResource(R.string.new_request_title), onBack = onBack) { padding ->
        when {
            !state.loaded -> LoadingState(Modifier.padding(padding))
            state.account == null -> EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.request_blocked_no_account),
                message = "",
                modifier = Modifier.padding(padding),
            )
            state.offers.isEmpty() -> EmptyState(
                icon = Icons.Default.ShoppingCart,
                title = stringResource(R.string.catalog_empty_title),
                message = stringResource(R.string.catalog_empty_message),
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (state.step == NewRequestStep.FORM) {
                    OfferPickerSection(state.offers, state.selectedOfferId, viewModel::selectOffer)

                    Text(stringResource(R.string.beneficiary_title), style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = state.choice == BeneficiaryChoice.REGISTERED,
                            onClick = { viewModel.onChoice(BeneficiaryChoice.REGISTERED) },
                            label = { Text(stringResource(R.string.beneficiary_registered, state.account?.registeredPhone.orEmpty())) },
                        )
                        FilterChip(
                            selected = state.choice == BeneficiaryChoice.OTHER,
                            onClick = { viewModel.onChoice(BeneficiaryChoice.OTHER) },
                            label = { Text(stringResource(R.string.beneficiary_other)) },
                        )
                    }
                    if (state.choice == BeneficiaryChoice.OTHER) {
                        OutlinedTextField(
                            value = state.otherPhone, onValueChange = viewModel::onOtherPhone, singleLine = true,
                            label = { Text(stringResource(R.string.beneficiary_phone)) }, modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    OutlinedTextField(
                        value = state.note, onValueChange = viewModel::onNote,
                        label = { Text(stringResource(R.string.note_optional)) }, modifier = Modifier.fillMaxWidth(),
                    )
                    state.selected?.let { offer ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(stringResource(R.string.final_price), style = MaterialTheme.typography.labelLarge)
                                Text(moneyLabel(offer.priceMinor), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text(stringResource(R.string.price_unverified_note), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    state.rejection?.let { Text(stringResource(it.labelRes), color = MaterialTheme.colorScheme.error) }
                    Button(
                        onClick = viewModel::continueToConfirm,
                        enabled = state.selectedOfferId != null && state.phoneRaw.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) { Text(stringResource(R.string.action_continue), style = MaterialTheme.typography.titleMedium) }
                } else {
                    val offer = state.selected
                    if (offer != null) {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(stringResource(R.string.confirm_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                LabeledRow(stringResource(R.string.label_network), stringResource(offer.provider.labelRes))
                                LabeledRow(stringResource(R.string.label_service), stringResource(offer.serviceType.labelRes) + " — " + offer.name)
                                LabeledRow(stringResource(R.string.label_beneficiary), state.phoneRaw)
                                if (offer.faceValueMinor > 0) LabeledRow(stringResource(R.string.face_value), moneyLabel(offer.faceValueMinor))
                                LabeledRow(stringResource(R.string.final_price), moneyLabel(offer.priceMinor))
                                if (state.note.isNotBlank()) LabeledRow(stringResource(R.string.note_optional), state.note)
                            }
                        }
                        InfoBanner(text = stringResource(R.string.confirm_no_deduction), icon = Icons.Default.Info)
                    }
                    if (state.unexpectedError) {
                        Text(stringResource(R.string.unexpected_error), color = MaterialTheme.colorScheme.error)
                    }
                    Button(
                        onClick = viewModel::submit,
                        enabled = !state.submitting,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) { Text(stringResource(R.string.confirm_submit), style = MaterialTheme.typography.titleMedium) }
                    OutlinedButton(onClick = viewModel::backToForm, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.action_back_to_edit))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ طلباتي

private val CURRENT_STATUSES = setOf(RequestStatus.PENDING_LOCAL, RequestStatus.SUBMITTED, RequestStatus.UNDER_REVIEW, RequestStatus.APPROVED)

@Composable
fun MyRequestsScreen(
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    viewModel: MyRequestsViewModel = viewModel(factory = MyRequestsViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    ClientScaffold(title = stringResource(R.string.my_requests_title), onBack = onBack) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(R.string.tab_current)) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(R.string.tab_history)) })
            }
            Box(modifier = Modifier.weight(1f)) {
                when (val s = state) {
                    UiState.Loading -> LoadingState()
                    is UiState.Error -> ErrorState(onRetry = {})
                    is UiState.Success -> {
                        val list = s.data.filter { (it.status in CURRENT_STATUSES) == (tab == 0) }
                        if (list.isEmpty()) {
                            EmptyState(
                                icon = Icons.AutoMirrored.Filled.List,
                                title = stringResource(if (tab == 0) R.string.requests_empty_current else R.string.requests_empty_history),
                                message = stringResource(R.string.requests_empty_message),
                            )
                        } else {
                            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(list, key = { it.id }) { r -> RequestCard(r, onClick = { onOpen(r.id) }) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestCard(r: PendingRequestEntity, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(r.offerName.ifBlank { stringResource(r.serviceType.labelRes) }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                RequestStatusChip(r.status)
            }
            Text(stringResource(r.provider.labelRes) + " • " + r.targetPhone, style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(DateText.formatDateTime(r.createdAtMillis), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text(moneyLabel(r.customerPriceMinor), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun ClientRequestDetailsScreen(
    requestId: String,
    onBack: () -> Unit,
    viewModel: ClientRequestDetailsViewModel = viewModel(factory = ClientRequestDetailsViewModel.factory(requestId)),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    ClientScaffold(title = stringResource(R.string.request_details_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = {})
                is UiState.Success -> {
                    val r = s.data
                    if (r == null) {
                        EmptyState(icon = Icons.AutoMirrored.Filled.List, title = stringResource(R.string.request_not_found), message = "")
                    } else {
                        Column(
                            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(r.offerName.ifBlank { stringResource(r.serviceType.labelRes) }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        RequestStatusChip(r.status)
                                    }
                                    LabeledRow(stringResource(R.string.label_network), stringResource(r.provider.labelRes))
                                    LabeledRow(stringResource(R.string.label_service), stringResource(r.serviceType.labelRes))
                                    LabeledRow(stringResource(R.string.label_beneficiary), r.targetPhone)
                                    if (r.faceValueMinor > 0) LabeledRow(stringResource(R.string.face_value), moneyLabel(r.faceValueMinor))
                                    LabeledRow(stringResource(R.string.final_price), moneyLabel(r.customerPriceMinor))
                                    LabeledRow(stringResource(R.string.label_created_at), DateText.formatDateTime(r.createdAtMillis))
                                    r.note?.let { LabeledRow(stringResource(R.string.note_optional), it) }
                                    r.statusNote?.let { LabeledRow(stringResource(R.string.label_admin_note), it) }
                                }
                            }
                            InfoBanner(
                                text = stringResource(
                                    if (r.status == RequestStatus.PENDING_LOCAL) R.string.details_pending_local_note else R.string.details_no_deduction_note,
                                ),
                                icon = Icons.Default.Info,
                            )
                        }
                    }
                }
            }
        }
    }
}
