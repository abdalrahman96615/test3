package com.factorycharge.client.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.factorycharge.client.data.CatalogOfferEntity
import com.factorycharge.client.data.ClientRequestRepository
import com.factorycharge.client.data.CreateRequestOutcome
import com.factorycharge.client.data.LocalAccountEntity
import com.factorycharge.client.data.PendingRequestEntity
import com.factorycharge.client.data.isAvailableAt
import com.factorycharge.core.design.OfferOption
import com.factorycharge.core.design.UiState
import com.factorycharge.core.request.OfferView
import com.factorycharge.core.request.RequestCheck
import com.factorycharge.core.request.RequestRejection
import com.factorycharge.core.request.RequestRules
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

private fun <T> Flow<T>.asUiState(): Flow<UiState<T>> =
    map<T, UiState<T>> { UiState.Success(it) }.catch { emit(UiState.Error(it)) }

// ------------------------------------------------------------------ الكتالوج المحلي (للقراءة)

class CatalogViewModel(app: com.factorycharge.client.ClientApp) : ViewModel() {
    val state: StateFlow<UiState<List<CatalogOfferEntity>>> = app.database.catalogDao().observeAll()
        .map { list ->
            val now = System.currentTimeMillis()
            list.filter { it.isAvailableAt(now) }
        }
        .asUiState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    companion object {
        val Factory = clientFactory { CatalogViewModel(it) }
    }
}

// ------------------------------------------------------------------ إنشاء طلب

enum class BeneficiaryChoice { REGISTERED, OTHER }
enum class NewRequestStep { FORM, CONFIRM }

data class NewRequestState(
    val loaded: Boolean = false,
    val account: LocalAccountEntity? = null,
    val offers: List<OfferOption> = emptyList(),
    val selectedOfferId: String? = null,
    val choice: BeneficiaryChoice = BeneficiaryChoice.REGISTERED,
    val otherPhone: String = "",
    val note: String = "",
    val step: NewRequestStep = NewRequestStep.FORM,
    val rejection: RequestRejection? = null,
    val submitting: Boolean = false,
    val createdId: String? = null,
    val unexpectedError: Boolean = false,
) {
    val selected: OfferOption? get() = offers.firstOrNull { it.id == selectedOfferId }
    val phoneRaw: String get() = if (choice == BeneficiaryChoice.REGISTERED) account?.registeredPhone.orEmpty() else otherPhone
}

class NewRequestViewModel(
    private val app: com.factorycharge.client.ClientApp,
    initialOfferId: String?,
) : ViewModel() {
    // يُولَّد مرة واحدة: الضغط المزدوج أو إعادة الإرسال لا ينشئ طلبين.
    private val requestId = UUID.randomUUID().toString()
    private val repository: ClientRequestRepository = app.requestRepository
    private val _state = MutableStateFlow(NewRequestState(selectedOfferId = initialOfferId))
    val state: StateFlow<NewRequestState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(app.database.catalogDao().observeAll(), app.database.localAccountDao().observe()) { catalog, account ->
                val now = System.currentTimeMillis()
                val options = catalog.filter { it.isAvailableAt(now) && it.customerPriceMinor > 0 }.map {
                    OfferOption(it.id, it.provider, it.serviceType, it.name, it.description, it.faceValueMinor, it.customerPriceMinor)
                }
                options to account
            }.collect { (options, account) ->
                _state.update { it.copy(loaded = true, offers = options, account = account) }
            }
        }
    }

    fun selectOffer(id: String) = _state.update { it.copy(selectedOfferId = id, rejection = null) }
    fun onChoice(c: BeneficiaryChoice) = _state.update { it.copy(choice = c, rejection = null) }
    fun onOtherPhone(v: String) = _state.update { it.copy(otherPhone = v, rejection = null) }
    fun onNote(v: String) = _state.update { it.copy(note = v, rejection = null) }
    fun backToForm() = _state.update { it.copy(step = NewRequestStep.FORM) }

    fun continueToConfirm() {
        val s = _state.value
        val offer = s.selected
        if (offer == null) {
            _state.update { it.copy(rejection = RequestRejection.OFFER_NOT_FOUND) }
            return
        }
        // نفس قواعد الطلب المشتركة؛ سعر الكتالوج المحلي للعرض فقط والمسؤول يعيد التحقق.
        val check = RequestRules.check(
            OfferView(offer.id, offer.provider, offer.serviceType, offer.name, offer.faceValueMinor, offer.priceMinor, true, null, null),
            offer.provider, offer.serviceType, s.phoneRaw, s.note, System.currentTimeMillis(),
        )
        _state.update {
            when (check) {
                is RequestCheck.Rejected -> it.copy(rejection = check.reason)
                is RequestCheck.Ok -> it.copy(step = NewRequestStep.CONFIRM, rejection = null)
            }
        }
    }

    fun submit() {
        val s = _state.value
        val offer = s.selected ?: return
        if (s.submitting || s.createdId != null) return
        _state.update { it.copy(submitting = true, rejection = null, unexpectedError = false) }
        viewModelScope.launch {
            try {
                val outcome = repository.createRequest(requestId, offer.id, s.phoneRaw, s.note)
                _state.update {
                    when (outcome) {
                        is CreateRequestOutcome.Created -> it.copy(submitting = false, createdId = outcome.request.id)
                        is CreateRequestOutcome.Rejected -> it.copy(
                            submitting = false,
                            // تكرار المعرّف = الطلب محفوظ سابقاً: نعتبره منشأً بدل إظهار خطأ مربك
                            createdId = if (outcome.reason == RequestRejection.DUPLICATE_REQUEST) requestId else null,
                            step = if (outcome.reason == RequestRejection.DUPLICATE_REQUEST) it.step else NewRequestStep.FORM,
                            rejection = if (outcome.reason == RequestRejection.DUPLICATE_REQUEST) null else outcome.reason,
                        )
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                _state.update { it.copy(submitting = false, unexpectedError = true) }
            }
        }
    }

    companion object {
        fun factory(initialOfferId: String?) = clientFactory { NewRequestViewModel(it, initialOfferId) }
    }
}

// ------------------------------------------------------------------ طلباتي

class MyRequestsViewModel(app: com.factorycharge.client.ClientApp) : ViewModel() {
    val state: StateFlow<UiState<List<PendingRequestEntity>>> = app.database.pendingRequestDao().observeAll()
        .asUiState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    companion object {
        val Factory = clientFactory { MyRequestsViewModel(it) }
    }
}

class ClientRequestDetailsViewModel(app: com.factorycharge.client.ClientApp, requestId: String) : ViewModel() {
    val state: StateFlow<UiState<PendingRequestEntity?>> = app.database.pendingRequestDao().observeById(requestId)
        .asUiState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    companion object {
        fun factory(requestId: String) = clientFactory { ClientRequestDetailsViewModel(it, requestId) }
    }
}
