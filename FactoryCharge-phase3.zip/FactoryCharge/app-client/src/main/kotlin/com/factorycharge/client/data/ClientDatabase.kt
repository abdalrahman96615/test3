package com.factorycharge.client.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * قاعدة بيانات العميل: طلبات محلية + نسخة محلية من كتالوج المسؤول + هوية الجهاز + نسخة عرض فقط من الحساب.
 * لا قيود مالية هنا. سياسة الإصدارات: كل تغيير = رفع version + Migration صريحة (انظر [ClientMigrations])
 * + إيداع schema الجديد؛ ممنوع destructive migration.
 * - الإصدار 1: المرحلتان 1-2. - الإصدار 2: المرحلة 3 (الكتالوج المحلي والطلبات الموسّعة).
 */
@Database(
    entities = [
        PendingRequestEntity::class,
        WalletSnapshotEntity::class,
        CatalogOfferEntity::class,
        LocalAccountEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class ClientDatabase : RoomDatabase() {
    abstract fun pendingRequestDao(): PendingRequestDao
    abstract fun walletSnapshotDao(): WalletSnapshotDao
    abstract fun catalogDao(): CatalogDao
    abstract fun localAccountDao(): LocalAccountDao

    companion object {
        const val FILE_NAME = "factorycharge_client.db"

        fun build(context: Context): ClientDatabase =
            Room.databaseBuilder(context.applicationContext, ClientDatabase::class.java, FILE_NAME)
                .addMigrations(*ClientMigrations.ALL)
                .build()
    }
}
