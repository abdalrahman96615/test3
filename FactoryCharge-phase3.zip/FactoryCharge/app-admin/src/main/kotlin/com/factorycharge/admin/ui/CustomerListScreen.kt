package com.factorycharge.admin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.admin.data.CustomerWithBalances
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel

@Composable
fun CustomerListScreen(
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onOpen: (String) -> Unit,
    viewModel: CustomerListViewModel = viewModel(factory = CustomerListViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()

    AppScaffold(
        title = stringResource(R.string.customers_title),
        onBack = onBack,
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.customers_add))
            }
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::setQuery,
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text(stringResource(R.string.customers_search_hint)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )
            Box(modifier = Modifier.weight(1f)) {
                when (val s = state) {
                    UiState.Loading -> LoadingState()
                    is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                    is UiState.Success -> {
                        if (s.data.isEmpty()) {
                            EmptyState(
                                icon = Icons.Default.Person,
                                title = stringResource(
                                    if (query.isBlank()) R.string.customers_empty_title else R.string.customers_no_results,
                                ),
                                message = if (query.isBlank()) stringResource(R.string.customers_empty_message) else "",
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(s.data, key = { it.customer.id }) { item ->
                                    CustomerCard(item, onClick = { onOpen(item.customer.id) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerCard(item: CustomerWithBalances, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = item.customer.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                if (!item.customer.isActive) {
                    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.errorContainer) {
                        Text(
                            text = stringResource(R.string.customer_inactive_badge),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }
            }
            Text(
                text = item.customer.phone,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LabeledAmount(stringResource(R.string.tile_wallet), item.balanceMinor, Modifier.weight(1f))
                LabeledAmount(stringResource(R.string.tile_debt), item.debtMinor, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LabeledAmount(label: String, amountMinor: Long, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(moneyLabel(amountMinor), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
    }
}
