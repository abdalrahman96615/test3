package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.StatCard
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus

@Composable
fun OperationsLogScreen(
    onBack: () -> Unit,
    viewModel: OperationsLogViewModel = viewModel(factory = OperationsLogViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    AppScaffold(title = stringResource(R.string.log_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = {})
                is UiState.Success -> if (s.data.isEmpty()) {
                    EmptyState(
                        icon = Icons.AutoMirrored.Filled.List,
                        title = stringResource(R.string.statement_empty_title),
                        message = stringResource(R.string.statement_empty_message),
                    )
                } else {
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(s.data, key = { it.entry.id }) { row -> EntryCard(row.entry, customerName = row.customerName) }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(
    onBack: () -> Unit,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    AppScaffold(title = stringResource(R.string.reports_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = {})
                is UiState.Success -> ReportsContent(s.data)
            }
        }
    }
}

@Composable
private fun ReportsContent(data: ReportsData) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        FinanceTile(
            label = stringResource(R.string.home_total_wallets), amountMinor = data.totals.totalBalanceMinor, icon = Icons.Default.AccountBox,
            container = MaterialTheme.colorScheme.primaryContainer, content = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        FinanceTile(
            label = stringResource(R.string.home_total_debts), amountMinor = data.totals.totalDebtMinor, icon = Icons.Default.Warning,
            container = MaterialTheme.colorScheme.errorContainer, content = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(stringResource(R.string.reports_requests_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val statuses = listOf(RequestStatus.SUBMITTED, RequestStatus.UNDER_REVIEW, RequestStatus.APPROVED, RequestStatus.EXECUTED, RequestStatus.REJECTED, RequestStatus.CANCELLED)
        statuses.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { st ->
                    StatCard(
                        label = stringResource(st.labelRes),
                        value = (data.statusCounts[st.name] ?: 0).toString(),
                        icon = Icons.AutoMirrored.Filled.List,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        Text(stringResource(R.string.reports_executed_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (data.executedByProvider.isEmpty()) {
            Text(stringResource(R.string.reports_no_executed), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        data.executedByProvider.forEach { p ->
            val providerLabel = NetworkProvider.entries.firstOrNull { it.name == p.provider }?.let { stringResource(it.labelRes) } ?: p.provider
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(providerLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(stringResource(R.string.reports_count, p.count), style = MaterialTheme.typography.labelLarge)
                    }
                    Text(stringResource(R.string.req_face_value) + ": " + moneyLabel(p.faceTotalMinor), style = MaterialTheme.typography.bodyMedium)
                    Text(stringResource(R.string.req_customer_price) + ": " + moneyLabel(p.priceTotalMinor), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
