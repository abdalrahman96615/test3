package com.factorycharge.admin.ui

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.factorycharge.admin.R
import com.factorycharge.admin.data.CatalogRepository
import com.factorycharge.admin.data.CustomerWithBalances
import com.factorycharge.admin.data.ExecutionOutcome
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.IncomingRequest
import com.factorycharge.admin.data.IngestOutcome
import com.factorycharge.admin.data.LedgerEntryEntity
import com.factorycharge.admin.data.LedgerEntryWithCustomer
import com.factorycharge.admin.data.LedgerTotals
import com.factorycharge.admin.data.ProviderTotals
import com.factorycharge.admin.data.RequestEventEntity
import com.factorycharge.admin.data.RequestFilter
import com.factorycharge.admin.data.RequestRepository
import com.factorycharge.admin.data.RequestWithCustomer
import com.factorycharge.admin.data.StatusCount
import com.factorycharge.admin.data.StatusOutcome
import com.factorycharge.admin.data.priceMinor
import com.factorycharge.core.design.OfferOption
import com.factorycharge.core.design.UiState
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.request.RequestRejection
import com.factorycharge.core.util.DateText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// ------------------------------------------------------------------ صندوق الطلبات

enum class StatusGroup(@StringRes val labelRes: Int, val statuses: Set<RequestStatus>) {
    ALL(R.string.inbox_group_all, emptySet()),
    NEW(R.string.inbox_group_new, setOf(RequestStatus.SUBMITTED)),
    REVIEW(R.string.inbox_group_review, setOf(RequestStatus.UNDER_REVIEW)),
    APPROVED(R.string.inbox_group_approved, setOf(RequestStatus.APPROVED)),
    EXECUTED(R.string.inbox_group_executed, setOf(RequestStatus.EXECUTED)),
    CLOSED(R.string.inbox_group_closed, setOf(RequestStatus.REJECTED, RequestStatus.CANCELLED)),
}

data class InboxFilterUi(
    val group: StatusGroup = StatusGroup.ALL,
    val provider: NetworkProvider? = null,
    val serviceType: ServiceType? = null,
    val customerQuery: String = "",
    val fromText: String = "",
    val toText: String = "",
) {
    val fromMillis: Long? get() = if (fromText.isBlank()) null else DateText.parseDayStart(fromText)
    val toMillis: Long? get() = if (toText.isBlank()) null else DateText.parseDayEnd(toText)
    val dateInvalid: Boolean
        get() = (fromText.isNotBlank() && fromMillis == null) || (toText.isNotBlank() && toMillis == null)

    fun toFilter() = RequestFilter(group.statuses, provider, serviceType, customerQuery, fromMillis, toMillis)
}

@OptIn(ExperimentalCoroutinesApi::class)
class RequestsInboxViewModel(private val requests: RequestRepository) : ViewModel() {
    private val _filter = MutableStateFlow(InboxFilterUi())
    val filter: StateFlow<InboxFilterUi> = _filter.asStateFlow()
    private val retryTick = MutableStateFlow(0)

    val state: StateFlow<UiState<List<RequestWithCustomer>>> =
        combine(_filter, retryTick) { f, _ -> f.toFilter() }
            .flatMapLatest { requests.observeRequests(it).asUiState() }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun updateFilter(block: (InboxFilterUi) -> InboxFilterUi) {
        _filter.update(block)
    }
    fun retry() = retryTick.update { it + 1 }

    companion object {
        val Factory: ViewModelProvider.Factory = appFactory { RequestsInboxViewModel(it.requestRepository) }
    }
}

// ------------------------------------------------------------------ تفاصيل الطلب وإجراءاته

data class RequestDetailsData(
    val request: RequestWithCustomer,
    val events: List<RequestEventEntity>,
    val customer: CustomerWithBalances?,
    val executionEntries: List<LedgerEntryEntity>,
)

data class UiMessage(@StringRes val res: Int, val isError: Boolean)

@OptIn(ExperimentalCoroutinesApi::class)
class RequestDetailsViewModel(
    private val requests: RequestRepository,
    private val finance: FinancialRepository,
    private val requestId: String,
) : ViewModel() {
    private val retryTick = MutableStateFlow(0)

    /** null داخل Success = الطلب غير موجود. */
    val state: StateFlow<UiState<RequestDetailsData?>> = retryTick
        .flatMapLatest {
            requests.observeRequest(requestId).flatMapLatest { row ->
                if (row == null) {
                    flowOf<RequestDetailsData?>(null)
                } else {
                    combine(
                        requests.observeEvents(requestId),
                        finance.observeCustomer(row.request.customerId),
                        finance.observeExecutionEntries(requestId),
                    ) { events, customer, entries -> RequestDetailsData(row, events, customer, entries) }
                }
            }.asUiState()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _message = MutableStateFlow<UiMessage?>(null)
    val message: StateFlow<UiMessage?> = _message.asStateFlow()

    fun retry() = retryTick.update { it + 1 }
    fun clearMessage() {
        _message.value = null
    }

    fun changeStatus(next: RequestStatus, note: String? = null) = launchAction {
        when (val r = requests.changeStatus(requestId, next, note)) {
            is StatusOutcome.Changed -> UiMessage(R.string.msg_status_changed, false)
            is StatusOutcome.Rejected -> UiMessage(r.reason.labelRes, true)
        }
    }

    fun recordFailure(reason: String) = launchAction {
        when (val r = requests.recordExecutionFailure(requestId, reason)) {
            is StatusOutcome.Changed -> UiMessage(R.string.msg_failure_recorded, false)
            is StatusOutcome.Rejected -> UiMessage(r.reason.labelRes, true)
        }
    }

    /** تأكيد أن المسؤول نفّذ الشحن فعلياً ونجح: يسجل الخصم عبر النظام المالي الموجود. */
    fun confirmExecuted() = launchAction {
        when (val r = finance.executeChargeRequest(requestId)) {
            is ExecutionOutcome.Executed -> UiMessage(R.string.msg_executed, false)
            is ExecutionOutcome.AlreadyExecuted -> UiMessage(R.string.msg_already_executed, false)
            is ExecutionOutcome.Rejected -> UiMessage(r.reason.labelRes, true)
        }
    }

    private fun launchAction(block: suspend () -> UiMessage) {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                _message.value = block()
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                _message.value = UiMessage(R.string.unexpected_error, true)
            } finally {
                _busy.value = false
            }
        }
    }

    companion object {
        fun factory(requestId: String): ViewModelProvider.Factory =
            appFactory { RequestDetailsViewModel(it.requestRepository, it.repository, requestId) }
    }
}

// ------------------------------------------------------------------ تسجيل طلب نيابة عن عميل (إدخال يدوي)

enum class IntakeStep { FORM, CONFIRM }

data class IntakeState(
    val customer: CustomerWithBalances? = null,
    val loaded: Boolean = false,
    val offers: List<OfferOption> = emptyList(),
    val selectedOfferId: String? = null,
    val phone: String = "",
    val note: String = "",
    val step: IntakeStep = IntakeStep.FORM,
    val rejection: RequestRejection? = null,
    val submitting: Boolean = false,
    val createdRequestId: String? = null,
) {
    val selected: OfferOption? get() = offers.firstOrNull { it.id == selectedOfferId }
}

class RequestIntakeViewModel(
    private val finance: FinancialRepository,
    private val catalog: CatalogRepository,
    private val requests: RequestRepository,
    private val customerId: String,
) : ViewModel() {
    // معرّف الطلب يُولَّد مرة واحدة لكل نموذج: الضغط المزدوج لا ينشئ طلبين.
    private val requestId = UUID.randomUUID().toString()
    private val _state = MutableStateFlow(IntakeState())
    val state: StateFlow<IntakeState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(finance.observeCustomer(customerId), catalog.observeOffers(), catalog.observeMultiplierBp()) { c, offers, m ->
                val options = offers.filter { it.isActive }.mapNotNull { o ->
                    o.priceMinor(m)?.let { price ->
                        OfferOption(o.id, o.provider, o.serviceType, o.name, o.description, o.faceValueMinor, price)
                    }
                }
                Triple(c, options, m)
            }.collect { (c, options, _) ->
                _state.update { it.copy(customer = c, loaded = true, offers = options) }
            }
        }
    }

    fun selectOffer(id: String) = _state.update { it.copy(selectedOfferId = id, rejection = null) }
    fun onPhone(v: String) = _state.update { it.copy(phone = v, rejection = null) }
    fun onNote(v: String) = _state.update { it.copy(note = v, rejection = null) }
    fun backToForm() = _state.update { it.copy(step = IntakeStep.FORM) }

    fun continueToConfirm() {
        val s = _state.value
        val offer = s.selected
        if (offer == null) {
            _state.update { it.copy(rejection = RequestRejection.OFFER_NOT_FOUND) }
            return
        }
        // فحص مبدئي بنفس قواعد الاستلام (الاستلام الفعلي يعيد الفحص على الكتالوج المعتمد)
        val check = com.factorycharge.core.request.RequestRules.check(
            com.factorycharge.core.request.OfferView(
                offer.id, offer.provider, offer.serviceType, offer.name, offer.faceValueMinor, offer.priceMinor,
                true, null, null,
            ),
            offer.provider, offer.serviceType, s.phone, s.note, System.currentTimeMillis(),
        )
        _state.update {
            when (check) {
                is com.factorycharge.core.request.RequestCheck.Rejected -> it.copy(rejection = check.reason)
                is com.factorycharge.core.request.RequestCheck.Ok -> it.copy(step = IntakeStep.CONFIRM, rejection = null)
            }
        }
    }

    fun submit() {
        val s = _state.value
        val offer = s.selected ?: return
        if (s.submitting || s.createdRequestId != null) return
        _state.update { it.copy(submitting = true, rejection = null) }
        viewModelScope.launch {
            val outcome = requests.ingest(
                IncomingRequest(
                    requestId = requestId, customerId = customerId, offerId = offer.id, provider = offer.provider,
                    serviceType = offer.serviceType, targetPhone = s.phone, note = s.note, claimedPriceMinor = null,
                ),
            )
            _state.update {
                when (outcome) {
                    is IngestOutcome.Created -> it.copy(submitting = false, createdRequestId = outcome.request.id)
                    is IngestOutcome.Duplicate -> it.copy(submitting = false, createdRequestId = outcome.request.id)
                    is IngestOutcome.Rejected -> it.copy(submitting = false, step = IntakeStep.FORM, rejection = outcome.reason)
                }
            }
        }
    }

    companion object {
        fun factory(customerId: String): ViewModelProvider.Factory =
            appFactory { RequestIntakeViewModel(it.repository, it.catalogRepository, it.requestRepository, customerId) }
    }
}

// ------------------------------------------------------------------ سجل العمليات والتقارير

class OperationsLogViewModel(finance: FinancialRepository) : ViewModel() {
    val state: StateFlow<UiState<List<LedgerEntryWithCustomer>>> = finance.observeRecentEntries(200)
        .asUiState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    companion object {
        val Factory: ViewModelProvider.Factory = appFactory { OperationsLogViewModel(it.repository) }
    }
}

data class ReportsData(
    val totals: LedgerTotals,
    val customers: Int,
    val statusCounts: Map<String, Int>,
    val executedByProvider: List<ProviderTotals>,
)

class ReportsViewModel(finance: FinancialRepository, requests: RequestRepository) : ViewModel() {
    val state: StateFlow<UiState<ReportsData>> = combine(
        finance.observeTotals(),
        finance.observeCustomerCount(),
        requests.observeStatusCounts(),
        requests.observeExecutedByProvider(),
    ) { totals, customers, counts: List<StatusCount>, providers ->
        ReportsData(totals, customers, counts.associate { it.status to it.count }, providers)
    }.asUiState().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    companion object {
        val Factory: ViewModelProvider.Factory = appFactory { ReportsViewModel(it.repository, it.requestRepository) }
    }
}
