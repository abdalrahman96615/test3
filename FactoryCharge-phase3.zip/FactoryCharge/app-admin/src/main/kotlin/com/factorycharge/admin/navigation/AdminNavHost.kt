package com.factorycharge.admin.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.factorycharge.admin.R
import com.factorycharge.admin.ui.AdminHomeScreen
import com.factorycharge.admin.ui.CashKind
import com.factorycharge.admin.ui.CashOperationScreen
import com.factorycharge.admin.ui.CreditLimitScreen
import com.factorycharge.admin.ui.CustomerDetailsScreen
import com.factorycharge.admin.ui.CustomerEditScreen
import com.factorycharge.admin.ui.CustomerListScreen
import com.factorycharge.admin.ui.OfferEditScreen
import com.factorycharge.admin.ui.OperationsLogScreen
import com.factorycharge.admin.ui.PricingScreen
import com.factorycharge.admin.ui.ReportsScreen
import com.factorycharge.admin.ui.RequestDetailsScreen
import com.factorycharge.admin.ui.RequestIntakeScreen
import com.factorycharge.admin.ui.RequestsInboxScreen
import com.factorycharge.admin.ui.ServiceCatalogScreen
import com.factorycharge.admin.ui.StatementScreen
import com.factorycharge.core.design.OnboardingScreen

object AdminRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CUSTOMERS = "customers"
    const val CUSTOMER_NEW = "customer_new"
    const val REQUESTS = "requests"
    const val CATALOG = "catalog"
    const val OFFER_NEW = "offer_new"
    const val PRICING = "pricing"
    const val OPERATIONS_LOG = "operations"
    const val REPORTS = "reports"

    private const val ID_ARG = "id"
    const val CUSTOMER_DETAILS = "customer/{$ID_ARG}"
    const val CUSTOMER_EDIT = "customer/{$ID_ARG}/edit"
    const val DEPOSIT = "customer/{$ID_ARG}/deposit"
    const val WITHDRAW = "customer/{$ID_ARG}/withdraw"
    const val STATEMENT = "customer/{$ID_ARG}/statement"
    const val CREDIT_LIMIT = "customer/{$ID_ARG}/limit"
    const val INTAKE = "customer/{$ID_ARG}/request"
    const val REQUEST_DETAILS = "request/{$ID_ARG}"
    const val OFFER_EDIT = "offer/{$ID_ARG}/edit"

    fun details(id: String) = "customer/$id"
    fun edit(id: String) = "customer/$id/edit"
    fun deposit(id: String) = "customer/$id/deposit"
    fun withdraw(id: String) = "customer/$id/withdraw"
    fun statement(id: String) = "customer/$id/statement"
    fun creditLimit(id: String) = "customer/$id/limit"
    fun intake(id: String) = "customer/$id/request"
    fun request(id: String) = "request/$id"
    fun offerEdit(id: String) = "offer/$id/edit"

    fun idOf(entry: NavBackStackEntry): String = entry.arguments?.getString(ID_ARG).orEmpty()
    val idArguments = listOf(navArgument(ID_ARG) { type = NavType.StringType })
}

@Composable
fun AdminNavHost(
    onboardingDone: Boolean,
    onOnboardingFinished: () -> Unit,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = if (onboardingDone) AdminRoutes.HOME else AdminRoutes.ONBOARDING,
    ) {
        composable(AdminRoutes.ONBOARDING) {
            OnboardingScreen(
                roleLabel = stringResource(R.string.onboarding_role),
                title = stringResource(R.string.onboarding_title),
                description = stringResource(R.string.onboarding_description),
                points = listOf(
                    stringResource(R.string.onboarding_point_1),
                    stringResource(R.string.onboarding_point_2),
                    stringResource(R.string.onboarding_point_3),
                ),
                continueLabel = stringResource(R.string.onboarding_start),
                onContinue = {
                    onOnboardingFinished()
                    navController.navigate(AdminRoutes.HOME) {
                        popUpTo(AdminRoutes.ONBOARDING) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.HOME) {
            AdminHomeScreen(
                onOpenCustomers = { navController.navigate(AdminRoutes.CUSTOMERS) },
                onOpenRequests = { navController.navigate(AdminRoutes.REQUESTS) },
                onOpenCatalog = { navController.navigate(AdminRoutes.CATALOG) },
                onOpenPricing = { navController.navigate(AdminRoutes.PRICING) },
                onOpenLog = { navController.navigate(AdminRoutes.OPERATIONS_LOG) },
                onOpenReports = { navController.navigate(AdminRoutes.REPORTS) },
            )
        }
        composable(AdminRoutes.CUSTOMERS) {
            CustomerListScreen(
                onBack = { navController.popBackStack() },
                onAdd = { navController.navigate(AdminRoutes.CUSTOMER_NEW) },
                onOpen = { id -> navController.navigate(AdminRoutes.details(id)) },
            )
        }
        composable(AdminRoutes.CUSTOMER_NEW) {
            CustomerEditScreen(
                customerId = null,
                onBack = { navController.popBackStack() },
                onSaved = { id ->
                    navController.navigate(AdminRoutes.details(id)) {
                        popUpTo(AdminRoutes.CUSTOMER_NEW) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.CUSTOMER_DETAILS, arguments = AdminRoutes.idArguments) { entry ->
            val id = AdminRoutes.idOf(entry)
            CustomerDetailsScreen(
                customerId = id,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(AdminRoutes.edit(id)) },
                onDeposit = { navController.navigate(AdminRoutes.deposit(id)) },
                onWithdraw = { navController.navigate(AdminRoutes.withdraw(id)) },
                onStatement = { navController.navigate(AdminRoutes.statement(id)) },
                onCreditLimit = { navController.navigate(AdminRoutes.creditLimit(id)) },
                onNewRequest = { navController.navigate(AdminRoutes.intake(id)) },
            )
        }
        composable(AdminRoutes.CUSTOMER_EDIT, arguments = AdminRoutes.idArguments) { entry ->
            CustomerEditScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.DEPOSIT, arguments = AdminRoutes.idArguments) { entry ->
            CashOperationScreen(
                customerId = AdminRoutes.idOf(entry),
                kind = CashKind.DEPOSIT,
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.WITHDRAW, arguments = AdminRoutes.idArguments) { entry ->
            CashOperationScreen(
                customerId = AdminRoutes.idOf(entry),
                kind = CashKind.WITHDRAWAL,
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.STATEMENT, arguments = AdminRoutes.idArguments) { entry ->
            StatementScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.CREDIT_LIMIT, arguments = AdminRoutes.idArguments) { entry ->
            CreditLimitScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.REQUESTS) {
            RequestsInboxScreen(
                onBack = { navController.popBackStack() },
                onOpen = { id -> navController.navigate(AdminRoutes.request(id)) },
            )
        }
        composable(AdminRoutes.REQUEST_DETAILS, arguments = AdminRoutes.idArguments) { entry ->
            RequestDetailsScreen(requestId = AdminRoutes.idOf(entry), onBack = { navController.popBackStack() })
        }
        composable(AdminRoutes.INTAKE, arguments = AdminRoutes.idArguments) { entry ->
            RequestIntakeScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
                onCreated = { requestId ->
                    navController.navigate(AdminRoutes.request(requestId)) {
                        popUpTo(AdminRoutes.INTAKE) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.CATALOG) {
            ServiceCatalogScreen(
                onBack = { navController.popBackStack() },
                onAdd = { navController.navigate(AdminRoutes.OFFER_NEW) },
                onEdit = { id -> navController.navigate(AdminRoutes.offerEdit(id)) },
                onPricing = { navController.navigate(AdminRoutes.PRICING) },
            )
        }
        composable(AdminRoutes.OFFER_NEW) {
            OfferEditScreen(offerId = null, onBack = { navController.popBackStack() }, onSaved = { navController.popBackStack() })
        }
        composable(AdminRoutes.OFFER_EDIT, arguments = AdminRoutes.idArguments) { entry ->
            OfferEditScreen(offerId = AdminRoutes.idOf(entry), onBack = { navController.popBackStack() }, onSaved = { navController.popBackStack() })
        }
        composable(AdminRoutes.PRICING) {
            PricingScreen(
                onBack = { navController.popBackStack() },
                onOpenOffer = { id -> navController.navigate(AdminRoutes.offerEdit(id)) },
            )
        }
        composable(AdminRoutes.OPERATIONS_LOG) {
            OperationsLogScreen(onBack = { navController.popBackStack() })
        }
        composable(AdminRoutes.REPORTS) {
            ReportsScreen(onBack = { navController.popBackStack() })
        }
    }
}
