package com.factorycharge.admin.data

import androidx.room.TypeConverter
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.RequestEventType
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/**
 * تُخزَّن التعدادات بأسمائها. أسماء LedgerEntryType مستخدمة حرفياً في Triggers
 * (مثل 'DEBT_CREATED')؛ لا تُغيَّر دون تحديث [LedgerTriggers].
 */
class Converters {
    @TypeConverter fun providerToString(v: NetworkProvider): String = v.name
    @TypeConverter fun stringToProvider(v: String): NetworkProvider = NetworkProvider.valueOf(v)

    @TypeConverter fun serviceToString(v: ServiceType): String = v.name
    @TypeConverter fun stringToService(v: String): ServiceType = ServiceType.valueOf(v)

    @TypeConverter fun statusToString(v: RequestStatus): String = v.name
    @TypeConverter fun stringToStatus(v: String): RequestStatus = RequestStatus.valueOf(v)

    @TypeConverter fun pricingModeToString(v: PricingMode): String = v.name
    @TypeConverter fun stringToPricingMode(v: String): PricingMode = PricingMode.valueOf(v)

    @TypeConverter fun eventTypeToString(v: RequestEventType): String = v.name
    @TypeConverter fun stringToEventType(v: String): RequestEventType = RequestEventType.valueOf(v)

    @TypeConverter fun entryTypeToString(v: LedgerEntryType): String = v.name
    @TypeConverter fun stringToEntryType(v: String): LedgerEntryType = LedgerEntryType.valueOf(v)

    @TypeConverter fun operationKindToString(v: OperationKind): String = v.name
    @TypeConverter fun stringToOperationKind(v: String): OperationKind = OperationKind.valueOf(v)
}
