package com.factorycharge.admin.data

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/** عميل مع رصيده ومديونيته المحسوبين من مجموع قيود الدفتر. */
data class CustomerWithBalances(
    @Embedded val customer: CustomerEntity,
    val balanceMinor: Long,
    val debtMinor: Long,
)

/** مجاميع الدفتر (لعميل واحد أو للكل). */
data class LedgerTotals(
    val totalBalanceMinor: Long,
    val totalDebtMinor: Long,
)

@Dao
interface CustomerDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(customer: CustomerEntity)

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: String): CustomerEntity?

    @Query("UPDATE customers SET displayName = :name, phone = :phone WHERE id = :id")
    suspend fun updateProfile(id: String, name: String, phone: String): Int

    @Query("UPDATE customers SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: String, active: Boolean): Int

    @Query("UPDATE customers SET creditLimitMinor = :limitMinor WHERE id = :id")
    suspend fun setCreditLimit(id: String, limitMinor: Long): Int

    @Query("SELECT COUNT(*) FROM customers")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM customers WHERE isActive = 1")
    fun observeActiveCount(): Flow<Int>

    /** [query] يجب أن يكون مُهرَّباً (escape بالرمز !) من المستودع. */
    @Query(
        """
        SELECT c.*,
               COALESCE(SUM(l.balanceDeltaMinor), 0) AS balanceMinor,
               COALESCE(SUM(l.debtDeltaMinor), 0) AS debtMinor
        FROM customers AS c
        LEFT JOIN ledger_entries AS l ON l.customerId = c.id
        WHERE (:query = ''
               OR c.displayName LIKE '%' || :query || '%' ESCAPE '!'
               OR c.phone LIKE '%' || :query || '%' ESCAPE '!')
        GROUP BY c.id
        ORDER BY c.displayName COLLATE NOCASE
        """,
    )
    fun observeWithBalances(query: String): Flow<List<CustomerWithBalances>>

    @Query(
        """
        SELECT c.*,
               COALESCE(SUM(l.balanceDeltaMinor), 0) AS balanceMinor,
               COALESCE(SUM(l.debtDeltaMinor), 0) AS debtMinor
        FROM customers AS c
        LEFT JOIN ledger_entries AS l ON l.customerId = c.id
        WHERE c.id = :id
        GROUP BY c.id
        """,
    )
    fun observeWithBalancesById(id: String): Flow<CustomerWithBalances?>
}

@Dao
interface LedgerDao {
    /** الإدراج هو العملية الكتابية الوحيدة على الدفتر. لا تعديل ولا حذف. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entry: LedgerEntryEntity)

    @Query("SELECT COALESCE(MAX(sequence), 0) FROM ledger_entries")
    suspend fun maxSequence(): Long

    @Query("SELECT COUNT(*) FROM ledger_entries WHERE operationId = :operationId")
    suspend fun countByOperation(operationId: String): Int

    @Query("SELECT COUNT(*) FROM ledger_entries WHERE reversesEntryId = :entryId")
    suspend fun countReversalsOf(entryId: String): Int

    @Query("SELECT * FROM ledger_entries WHERE id = :id")
    suspend fun getById(id: String): LedgerEntryEntity?

    @Query(
        """
        SELECT COALESCE(SUM(balanceDeltaMinor), 0) AS totalBalanceMinor,
               COALESCE(SUM(debtDeltaMinor), 0) AS totalDebtMinor
        FROM ledger_entries WHERE customerId = :customerId
        """,
    )
    suspend fun getTotals(customerId: String): LedgerTotals

    @Query(
        """
        SELECT COALESCE(SUM(balanceDeltaMinor), 0) AS totalBalanceMinor,
               COALESCE(SUM(debtDeltaMinor), 0) AS totalDebtMinor
        FROM ledger_entries
        """,
    )
    fun observeAllTotals(): Flow<LedgerTotals>

    /** الأقدم أولاً (للتحقق والاختبار). */
    @Query("SELECT * FROM ledger_entries WHERE customerId = :customerId ORDER BY sequence ASC")
    suspend fun listForCustomer(customerId: String): List<LedgerEntryEntity>

    /** كشف الحساب: الأحدث أولاً، بالترتيب المتسلسل لا بالتوقيت (الساعة قد تتغير). */
    @Query("SELECT * FROM ledger_entries WHERE customerId = :customerId ORDER BY sequence DESC")
    fun observeStatement(customerId: String): Flow<List<LedgerEntryEntity>>

    @Query("SELECT COUNT(*) FROM ledger_entries")
    suspend fun count(): Int

    /** قيود عملية واحدة بترتيبها (مثل قيود تنفيذ طلب شحن). */
    @Query("SELECT * FROM ledger_entries WHERE operationId = :operationId ORDER BY lineNo ASC")
    suspend fun listByOperation(operationId: String): List<LedgerEntryEntity>

    @Query("SELECT * FROM ledger_entries WHERE operationId = :operationId ORDER BY lineNo ASC")
    fun observeByOperation(operationId: String): Flow<List<LedgerEntryEntity>>

    /** سجل العمليات العام: الأحدث أولاً. */
    @Query(
        """
        SELECT l.*, c.displayName AS customerName
        FROM ledger_entries AS l JOIN customers AS c ON c.id = l.customerId
        ORDER BY l.sequence DESC LIMIT :limit
        """,
    )
    fun observeRecentWithCustomer(limit: Int): Flow<List<LedgerEntryWithCustomer>>
}

data class LedgerEntryWithCustomer(
    @Embedded val entry: LedgerEntryEntity,
    val customerName: String,
)

/** طلب مع بيانات عميله المسجلة. */
data class RequestWithCustomer(
    @Embedded val request: ChargeRequestEntity,
    val customerName: String,
    val customerPhone: String,
)

data class StatusCount(val status: String, val count: Int)

data class ProviderTotals(
    val provider: String,
    val count: Int,
    val faceTotalMinor: Long,
    val priceTotalMinor: Long,
)

@Dao
interface ServiceOfferDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(offer: ServiceOfferEntity)

    @Update
    suspend fun update(offer: ServiceOfferEntity)

    @Query("SELECT * FROM service_offers WHERE id = :id")
    suspend fun getById(id: String): ServiceOfferEntity?

    @Query("SELECT * FROM service_offers WHERE id = :id")
    fun observeById(id: String): Flow<ServiceOfferEntity?>

    @Query("SELECT * FROM service_offers ORDER BY provider, serviceType, sortOrder, name")
    fun observeAll(): Flow<List<ServiceOfferEntity>>

    @Query("SELECT COUNT(*) FROM service_offers")
    suspend fun count(): Int
}

@Dao
interface SettingsDao {
    @Upsert
    suspend fun upsert(setting: AppSettingEntity)

    @Query("SELECT * FROM app_settings WHERE settingKey = :key")
    suspend fun get(key: String): AppSettingEntity?

    @Query("SELECT * FROM app_settings WHERE settingKey = :key")
    fun observe(key: String): Flow<AppSettingEntity?>
}

@Dao
interface ChargeRequestDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(request: ChargeRequestEntity)

    @Query("SELECT * FROM charge_requests WHERE id = :id")
    suspend fun getById(id: String): ChargeRequestEntity?

    @Query("SELECT COUNT(*) FROM charge_requests")
    suspend fun count(): Int

    /** الأسماء هنا يجب أن تطابق RequestStatus.SUBMITTED و UNDER_REVIEW. */
    @Query("SELECT COUNT(*) FROM charge_requests WHERE status IN ('SUBMITTED', 'UNDER_REVIEW')")
    fun observePendingReviewCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM charge_requests WHERE status = 'SUBMITTED'")
    fun observeNewCount(): Flow<Int>

    @Query(
        """
        SELECT r.*, c.displayName AS customerName, c.phone AS customerPhone
        FROM charge_requests AS r JOIN customers AS c ON c.id = r.customerId
        WHERE r.id = :id
        """,
    )
    fun observeById(id: String): Flow<RequestWithCustomer?>

    /** كل الفلاتر اختيارية. [customerQuery] مُهرَّب (ESCAPE '!') من المستودع. */
    @Query(
        """
        SELECT r.*, c.displayName AS customerName, c.phone AS customerPhone
        FROM charge_requests AS r JOIN customers AS c ON c.id = r.customerId
        WHERE (:allStatuses = 1 OR r.status IN (:statuses))
          AND (:provider IS NULL OR r.provider = :provider)
          AND (:serviceType IS NULL OR r.serviceType = :serviceType)
          AND (:customerQuery = ''
               OR c.displayName LIKE '%' || :customerQuery || '%' ESCAPE '!'
               OR c.phone LIKE '%' || :customerQuery || '%' ESCAPE '!')
          AND r.createdAtMillis >= :fromMillis AND r.createdAtMillis <= :toMillis
        ORDER BY r.createdAtMillis DESC, r.id DESC
        """,
    )
    fun observeFiltered(
        allStatuses: Boolean,
        statuses: List<String>,
        provider: String?,
        serviceType: String?,
        customerQuery: String,
        fromMillis: Long,
        toMillis: Long,
    ): Flow<List<RequestWithCustomer>>

    @Query("UPDATE charge_requests SET status = :status, statusNote = :note, updatedAtMillis = :now WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, note: String?, now: Long): Int

    @Query("UPDATE charge_requests SET status = 'EXECUTED', executedAtMillis = :now, updatedAtMillis = :now WHERE id = :id AND status = 'APPROVED'")
    suspend fun markExecuted(id: String, now: Long): Int

    @Query("UPDATE charge_requests SET lastFailureReason = :reason, updatedAtMillis = :now WHERE id = :id AND status = 'APPROVED'")
    suspend fun markFailure(id: String, reason: String, now: Long): Int

    @Query("SELECT status, COUNT(*) AS count FROM charge_requests GROUP BY status")
    fun observeStatusCounts(): Flow<List<StatusCount>>

    @Query(
        """
        SELECT provider, COUNT(*) AS count,
               COALESCE(SUM(faceValueMinor), 0) AS faceTotalMinor,
               COALESCE(SUM(customerPriceMinor), 0) AS priceTotalMinor
        FROM charge_requests WHERE status = 'EXECUTED' GROUP BY provider ORDER BY provider
        """,
    )
    fun observeExecutedByProvider(): Flow<List<ProviderTotals>>
}

@Dao
interface RequestEventDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(event: RequestEventEntity)

    @Query("SELECT * FROM request_events WHERE requestId = :requestId ORDER BY seq ASC")
    fun observeForRequest(requestId: String): Flow<List<RequestEventEntity>>

    @Query("SELECT * FROM request_events WHERE requestId = :requestId ORDER BY seq ASC")
    suspend fun listForRequest(requestId: String): List<RequestEventEntity>
}
