package com.factorycharge.admin.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * قاعدة بيانات المسؤول (المصدر الوحيد للقيود المالية).
 *
 * سياسة الإصدارات: لا destructive migration أبداً. كل تغيير في المخطط = رفع `version` + `Migration`
 * صريحة في [AdminMigrations] + إيداع ملف schema الجديد في Git.
 * - الإصدار 1: المرحلة 2 (عملاء + دفتر).
 * - الإصدار 2: المرحلة 3 (كتالوج، إعدادات، طلبات موسّعة، سجل أحداث الطلب).
 */
@Database(
    entities = [
        CustomerEntity::class,
        ChargeRequestEntity::class,
        LedgerEntryEntity::class,
        ServiceOfferEntity::class,
        AppSettingEntity::class,
        RequestEventEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AdminDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun chargeRequestDao(): ChargeRequestDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun serviceOfferDao(): ServiceOfferDao
    abstract fun settingsDao(): SettingsDao
    abstract fun requestEventDao(): RequestEventDao

    companion object {
        const val FILE_NAME = "factorycharge_admin.db"

        /** بدون fallbackToDestructiveMigration عمداً: لا نحذف بيانات مالية بصمت. */
        fun build(context: Context): AdminDatabase =
            Room.databaseBuilder(context.applicationContext, AdminDatabase::class.java, FILE_NAME)
                .addMigrations(*AdminMigrations.ALL)
                .addCallback(LedgerTriggers.callback)
                .build()
    }
}
