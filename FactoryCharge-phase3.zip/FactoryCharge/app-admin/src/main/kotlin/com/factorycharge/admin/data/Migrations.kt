package com.factorycharge.admin.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * ترحيلات قاعدة المسؤول. لا يُستخدم أي destructive migration، والعملاء والدفتر لا يُمسّان.
 *
 * 1 -> 2 (المرحلة 3): كتالوج الخدمات، الإعدادات، سجل أحداث الطلب، وإعادة بناء جدول الطلبات بأعمدة
 * الكتالوج والتسعير. أي طلبات قديمة تُنقل كما هي: amountMinor يصبح القيمة الاسمية وسعر العميل معاً،
 * ويُترك offerId فارغاً. الـ DDL مطابق تماماً لما يولّده Room للإصدار 2 (يتحقق منه Room بعد الترحيل).
 */
object AdminMigrations {

    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            MIGRATION_1_2_SQL.forEach { db.execSQL(it) }
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)

    internal val MIGRATION_1_2_SQL: List<String> = listOf(
        // --- كتالوج الخدمات
        "CREATE TABLE IF NOT EXISTS `service_offers` (`id` TEXT NOT NULL, `provider` TEXT NOT NULL, `serviceType` TEXT NOT NULL, " +
            "`name` TEXT NOT NULL, `description` TEXT, `pricingMode` TEXT NOT NULL, `faceValueMinor` INTEGER NOT NULL, " +
            "`fixedPriceMinor` INTEGER, `isActive` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, `validFromMillis` INTEGER, " +
            "`validUntilMillis` INTEGER, `revision` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL, " +
            "`updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))",
        "CREATE INDEX IF NOT EXISTS `index_service_offers_provider_serviceType_isActive_sortOrder` " +
            "ON `service_offers` (`provider`, `serviceType`, `isActive`, `sortOrder`)",
        // --- الإعدادات
        "CREATE TABLE IF NOT EXISTS `app_settings` (`settingKey` TEXT NOT NULL, `longValue` INTEGER NOT NULL, " +
            "`updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`settingKey`))",
        // --- إعادة بناء جدول الطلبات (لا جداول أخرى تشير إليه في الإصدار 1)
        "CREATE TABLE `charge_requests_new` (`id` TEXT NOT NULL, `customerId` TEXT NOT NULL, `provider` TEXT NOT NULL, " +
            "`serviceType` TEXT NOT NULL, `offerId` TEXT, `offerName` TEXT NOT NULL, `targetPhone` TEXT NOT NULL, " +
            "`faceValueMinor` INTEGER NOT NULL, `customerPriceMinor` INTEGER NOT NULL, `status` TEXT NOT NULL, " +
            "`createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, `note` TEXT, `statusNote` TEXT, " +
            "`lastFailureReason` TEXT, `executedAtMillis` INTEGER, PRIMARY KEY(`id`), " +
            "FOREIGN KEY(`customerId`) REFERENCES `customers`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT , " +
            "FOREIGN KEY(`offerId`) REFERENCES `service_offers`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )",
        "INSERT INTO `charge_requests_new` (`id`, `customerId`, `provider`, `serviceType`, `offerId`, `offerName`, `targetPhone`, " +
            "`faceValueMinor`, `customerPriceMinor`, `status`, `createdAtMillis`, `updatedAtMillis`, `note`, `statusNote`, " +
            "`lastFailureReason`, `executedAtMillis`) " +
            "SELECT `id`, `customerId`, `provider`, `serviceType`, NULL, '', `targetPhone`, `amountMinor`, `amountMinor`, `status`, " +
            "`createdAtMillis`, `updatedAtMillis`, `note`, NULL, NULL, NULL FROM `charge_requests`",
        "DROP TABLE `charge_requests`",
        "ALTER TABLE `charge_requests_new` RENAME TO `charge_requests`",
        "CREATE INDEX IF NOT EXISTS `index_charge_requests_customerId` ON `charge_requests` (`customerId`)",
        "CREATE INDEX IF NOT EXISTS `index_charge_requests_status` ON `charge_requests` (`status`)",
        "CREATE INDEX IF NOT EXISTS `index_charge_requests_offerId` ON `charge_requests` (`offerId`)",
        "CREATE INDEX IF NOT EXISTS `index_charge_requests_createdAtMillis` ON `charge_requests` (`createdAtMillis`)",
        // --- سجل أحداث الطلب
        "CREATE TABLE IF NOT EXISTS `request_events` (`seq` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `requestId` TEXT NOT NULL, " +
            "`type` TEXT NOT NULL, `fromStatus` TEXT, `toStatus` TEXT, `note` TEXT, `createdAtMillis` INTEGER NOT NULL, " +
            "FOREIGN KEY(`requestId`) REFERENCES `charge_requests`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )",
        "CREATE INDEX IF NOT EXISTS `index_request_events_requestId` ON `request_events` (`requestId`)",
    )
}
