package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.StatCard
import com.factorycharge.core.design.UiState

@Composable
fun AdminHomeScreen(
    onOpenCustomers: () -> Unit,
    onOpenRequests: () -> Unit,
    onOpenCatalog: () -> Unit,
    onOpenPricing: () -> Unit,
    onOpenLog: () -> Unit,
    onOpenReports: () -> Unit,
    viewModel: AdminHomeViewModel = viewModel(factory = AdminHomeViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    AppScaffold(title = stringResource(R.string.home_title)) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::load)
                is UiState.Success -> AdminHomeContent(s.data, onOpenCustomers, onOpenRequests, onOpenCatalog, onOpenPricing, onOpenLog, onOpenReports)
            }
        }
    }
}

@Composable
private fun AdminHomeContent(
    data: AdminHomeData,
    onOpenCustomers: () -> Unit,
    onOpenRequests: () -> Unit,
    onOpenCatalog: () -> Unit,
    onOpenPricing: () -> Unit,
    onOpenLog: () -> Unit,
    onOpenReports: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        InfoBanner(
            text = stringResource(R.string.home_trust_banner),
            icon = Icons.Default.Lock,
        )
        FinanceTile(
            label = stringResource(R.string.home_total_wallets),
            amountMinor = data.totalBalanceMinor,
            icon = Icons.Default.AccountBox,
            container = MaterialTheme.colorScheme.primaryContainer,
            content = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        FinanceTile(
            label = stringResource(R.string.home_total_debts),
            amountMinor = data.totalDebtMinor,
            icon = Icons.Default.Warning,
            container = MaterialTheme.colorScheme.errorContainer,
            content = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                label = stringResource(R.string.home_customers_count),
                value = data.customers.toString(),
                icon = Icons.Default.Person,
                modifier = Modifier.weight(1f),
            )
            StatCard(
                label = stringResource(R.string.home_active_count),
                value = data.activeCustomers.toString(),
                icon = Icons.Default.Person,
                modifier = Modifier.weight(1f),
            )
        }
        NavTile(stringResource(R.string.home_open_requests), Icons.Default.Notifications, onOpenRequests, badge = data.newRequests)
        NavTile(stringResource(R.string.home_open_customers), Icons.Default.Person, onOpenCustomers)
        NavTile(stringResource(R.string.home_open_catalog), Icons.Default.ShoppingCart, onOpenCatalog)
        NavTile(stringResource(R.string.home_open_pricing), Icons.Default.Settings, onOpenPricing)
        NavTile(stringResource(R.string.home_open_log), Icons.AutoMirrored.Filled.List, onOpenLog)
        NavTile(stringResource(R.string.home_open_reports), Icons.Default.Info, onOpenReports)
    }
}
