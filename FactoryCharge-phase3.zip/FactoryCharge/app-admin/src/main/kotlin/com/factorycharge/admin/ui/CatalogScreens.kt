package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.pricing.PriceCalculator
import com.factorycharge.core.util.DateText

// ------------------------------------------------------------------ كتالوج الخدمات

@Composable
fun ServiceCatalogScreen(
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (String) -> Unit,
    onPricing: () -> Unit,
    viewModel: ServiceCatalogViewModel = viewModel(factory = ServiceCatalogViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    AppScaffold(
        title = stringResource(R.string.catalog_title),
        onBack = onBack,
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.catalog_add))
            }
        },
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                is UiState.Success -> {
                    val data = s.data
                    if (data.rows.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.ShoppingCart,
                            title = stringResource(R.string.catalog_empty_title),
                            message = stringResource(R.string.catalog_empty_message),
                        )
                    } else {
                        val needsMultiplier = data.multiplierBp == null && data.rows.any { it.offer.pricingMode == PricingMode.NET_MULTIPLIER }
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            if (needsMultiplier) {
                                item(key = "multiplier-warning") {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        InfoBanner(text = stringResource(R.string.catalog_multiplier_missing), icon = Icons.Default.Warning)
                                        OutlinedButton(onClick = onPricing, modifier = Modifier.fillMaxWidth()) {
                                            Text(stringResource(R.string.home_open_pricing))
                                        }
                                    }
                                }
                            }
                            items(data.rows, key = { it.offer.id }) { row ->
                                OfferCard(row, onEdit = { onEdit(row.offer.id) }, onActiveChange = { viewModel.setActive(row.offer.id, it) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OfferCard(row: OfferRow, onEdit: () -> Unit, onActiveChange: (Boolean) -> Unit) {
    val offer = row.offer
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (offer.isActive) MaterialTheme.colorScheme.surfaceContainerLow else MaterialTheme.colorScheme.surfaceContainerHighest,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(offer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        stringResource(offer.provider.labelRes) + " • " + stringResource(offer.serviceType.labelRes),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = offer.isActive, onCheckedChange = onActiveChange)
            }
            offer.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                if (offer.faceValueMinor > 0) {
                    Text(
                        stringResource(R.string.field_face_value) + ": " + moneyLabel(offer.faceValueMinor),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
                Text(
                    stringResource(R.string.field_sell_price) + ": " +
                        (row.priceMinor?.let { moneyLabel(it) } ?: stringResource(R.string.price_not_set)),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (row.priceMinor == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
            }
            if (offer.validFromMillis != null || offer.validUntilMillis != null) {
                Text(
                    stringResource(R.string.offer_validity) + ": " +
                        (offer.validFromMillis?.let { DateText.formatDay(it) } ?: "—") + "  ←  " +
                        (offer.validUntilMillis?.let { DateText.formatDay(it) } ?: "—"),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            OutlinedButton(onClick = onEdit) { Text(stringResource(R.string.action_edit)) }
        }
    }
}

// ------------------------------------------------------------------ إضافة / تعديل عرض

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfferEditScreen(
    offerId: String?,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: OfferEditViewModel = viewModel(factory = appFactory { OfferEditViewModel(it.catalogRepository, offerId) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state.savedId) {
        if (state.savedId != null) onSaved()
    }
    AppScaffold(
        title = stringResource(if (viewModel.isEdit) R.string.offer_edit_title else R.string.offer_add_title),
        onBack = onBack,
    ) { padding ->
        when {
            state.loading -> LoadingState(Modifier.padding(padding))
            state.notFound -> EmptyState(
                icon = Icons.Default.ShoppingCart,
                title = stringResource(R.string.offer_not_found),
                message = "",
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(stringResource(R.string.picker_network_label), style = MaterialTheme.typography.titleSmall)
                ChoiceRow {
                    NetworkProvider.selectable.forEach { p ->
                        FilterChip(selected = state.provider == p, onClick = { viewModel.onProvider(p) }, label = { Text(stringResource(p.labelRes)) })
                    }
                }
                Text(stringResource(R.string.picker_service_label), style = MaterialTheme.typography.titleSmall)
                ChoiceRow {
                    ServiceType.entries.forEach { t ->
                        FilterChip(selected = state.serviceType == t, onClick = { viewModel.onServiceType(t) }, label = { Text(stringResource(t.labelRes)) })
                    }
                }
                OutlinedTextField(
                    value = state.name, onValueChange = viewModel::onName, singleLine = true,
                    label = { Text(stringResource(R.string.field_offer_name)) }, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = state.description, onValueChange = viewModel::onDescription,
                    label = { Text(stringResource(R.string.field_offer_description)) }, modifier = Modifier.fillMaxWidth(),
                )
                if (state.serviceType == ServiceType.BALANCE_TOPUP) {
                    Text(stringResource(R.string.field_pricing_mode), style = MaterialTheme.typography.titleSmall)
                    ChoiceRow {
                        PricingMode.entries.forEach { m ->
                            FilterChip(selected = state.pricingMode == m, onClick = { viewModel.onPricingMode(m) }, label = { Text(stringResource(m.labelRes)) })
                        }
                    }
                }
                val invalidMsg = stringResource(R.string.error_invalid_amount)
                AmountField(
                    value = state.faceText, onValueChange = viewModel::onFace,
                    label = stringResource(R.string.field_face_value), isError = state.invalidField == OfferField.FACE,
                    supportingText = if (state.invalidField == OfferField.FACE) invalidMsg else null,
                )
                if (state.pricingMode == PricingMode.FIXED_PRICE) {
                    AmountField(
                        value = state.priceText, onValueChange = viewModel::onPrice,
                        label = stringResource(R.string.field_sell_price), isError = state.invalidField == OfferField.PRICE,
                        supportingText = if (state.invalidField == OfferField.PRICE) invalidMsg else null,
                    )
                } else {
                    Text(
                        stringResource(R.string.offer_price_from_multiplier),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                OutlinedTextField(
                    value = state.sortText, onValueChange = viewModel::onSort, singleLine = true,
                    label = { Text(stringResource(R.string.field_sort_order)) },
                    isError = state.invalidField == OfferField.SORT, modifier = Modifier.fillMaxWidth(),
                )
                val dateMsg = stringResource(R.string.error_invalid_date)
                OutlinedTextField(
                    value = state.fromText, onValueChange = viewModel::onFrom, singleLine = true,
                    label = { Text(stringResource(R.string.field_valid_from)) }, placeholder = { Text("2026/01/31") },
                    isError = state.invalidField == OfferField.FROM,
                    supportingText = if (state.invalidField == OfferField.FROM) ({ Text(dateMsg) }) else null,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = state.untilText, onValueChange = viewModel::onUntil, singleLine = true,
                    label = { Text(stringResource(R.string.field_valid_until)) }, placeholder = { Text("2026/12/31") },
                    isError = state.invalidField == OfferField.UNTIL,
                    supportingText = if (state.invalidField == OfferField.UNTIL) ({ Text(dateMsg) }) else null,
                    modifier = Modifier.fillMaxWidth(),
                )
                state.error?.let {
                    Text(stringResource(it.labelRes), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
                Button(
                    onClick = viewModel::save,
                    enabled = !state.saving && state.name.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text(stringResource(R.string.action_save), style = MaterialTheme.typography.titleMedium) }
            }
        }
    }
}

// ------------------------------------------------------------------ إدارة الأسعار

@Composable
fun PricingScreen(
    onBack: () -> Unit,
    onOpenOffer: (String) -> Unit,
    viewModel: PricingViewModel = viewModel(factory = PricingViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    AppScaffold(title = stringResource(R.string.pricing_title), onBack = onBack) { padding ->
        if (!state.loaded) {
            LoadingState(Modifier.padding(padding))
        } else {
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(stringResource(R.string.pricing_multiplier_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    stringResource(R.string.pricing_multiplier_help),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (state.storedBp == null) {
                    InfoBanner(text = stringResource(R.string.pricing_not_saved_yet), icon = Icons.Default.Warning)
                }
                AmountField(
                    value = state.multiplierText, onValueChange = viewModel::onMultiplier,
                    label = stringResource(R.string.pricing_multiplier_field), isError = state.error != null,
                    supportingText = state.error?.let { stringResource(it.labelRes) },
                )
                state.exampleMinor?.let {
                    Text(
                        stringResource(R.string.pricing_example, moneyLabel(10_000), moneyLabel(it)),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                if (state.saved) {
                    Text(stringResource(R.string.pricing_saved), color = MaterialTheme.colorScheme.primary)
                }
                Button(
                    onClick = viewModel::save,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text(stringResource(R.string.limit_save), style = MaterialTheme.typography.titleMedium) }

                Text(stringResource(R.string.pricing_offers_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (state.rows.isEmpty()) {
                    Text(stringResource(R.string.pricing_no_net_offers), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                state.rows.forEach { row ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Default.Settings, contentDescription = null)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(row.offer.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(
                                    stringResource(row.offer.provider.labelRes) + " • " + moneyLabel(row.offer.faceValueMinor),
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            }
                            Text(
                                row.priceMinor?.let { moneyLabel(it) } ?: stringResource(R.string.price_not_set),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (row.priceMinor == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            )
                            OutlinedButton(onClick = { onOpenOffer(row.offer.id) }) { Text(stringResource(R.string.action_edit)) }
                        }
                    }
                }
            }
        }
    }
}
