package com.factorycharge.admin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.admin.data.RequestWithCustomer
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.OfferPickerSection
import com.factorycharge.core.design.RequestStatusChip
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel
import com.factorycharge.core.ledger.AccountState
import com.factorycharge.core.ledger.LedgerRules
import com.factorycharge.core.ledger.PlanResult
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

// ------------------------------------------------------------------ صندوق الطلبات

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestsInboxScreen(
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    viewModel: RequestsInboxViewModel = viewModel(factory = RequestsInboxViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val filter by viewModel.filter.collectAsStateWithLifecycle()
    var showFilters by rememberSaveable { mutableStateOf(false) }

    AppScaffold(title = stringResource(R.string.inbox_title), onBack = onBack) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            ChoiceRow(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                StatusGroup.entries.forEach { g ->
                    FilterChip(
                        selected = filter.group == g,
                        onClick = { viewModel.updateFilter { it.copy(group = g) } },
                        label = { Text(stringResource(g.labelRes)) },
                    )
                }
            }
            TextButton(onClick = { showFilters = !showFilters }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text(stringResource(if (showFilters) R.string.inbox_hide_filters else R.string.inbox_show_filters))
            }
            if (showFilters) {
                Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceRow {
                        FilterChip(selected = filter.provider == null, onClick = { viewModel.updateFilter { it.copy(provider = null) } }, label = { Text(stringResource(R.string.inbox_any_network)) })
                        NetworkProvider.selectable.forEach { p ->
                            FilterChip(selected = filter.provider == p, onClick = { viewModel.updateFilter { it.copy(provider = p) } }, label = { Text(stringResource(p.labelRes)) })
                        }
                    }
                    ChoiceRow {
                        FilterChip(selected = filter.serviceType == null, onClick = { viewModel.updateFilter { it.copy(serviceType = null) } }, label = { Text(stringResource(R.string.inbox_any_service)) })
                        ServiceType.entries.forEach { t ->
                            FilterChip(selected = filter.serviceType == t, onClick = { viewModel.updateFilter { it.copy(serviceType = t) } }, label = { Text(stringResource(t.labelRes)) })
                        }
                    }
                    OutlinedTextField(
                        value = filter.customerQuery,
                        onValueChange = { v -> viewModel.updateFilter { it.copy(customerQuery = v) } },
                        singleLine = true,
                        label = { Text(stringResource(R.string.customers_search_hint)) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = filter.fromText, onValueChange = { v -> viewModel.updateFilter { it.copy(fromText = v) } },
                            singleLine = true, label = { Text(stringResource(R.string.inbox_date_from)) }, placeholder = { Text("2026/01/31") },
                            isError = filter.fromText.isNotBlank() && filter.fromMillis == null, modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = filter.toText, onValueChange = { v -> viewModel.updateFilter { it.copy(toText = v) } },
                            singleLine = true, label = { Text(stringResource(R.string.inbox_date_to)) }, placeholder = { Text("2026/12/31") },
                            isError = filter.toText.isNotBlank() && filter.toMillis == null, modifier = Modifier.weight(1f),
                        )
                    }
                    if (filter.dateInvalid) {
                        Text(stringResource(R.string.error_invalid_date), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Box(modifier = Modifier.weight(1f)) {
                when (val s = state) {
                    UiState.Loading -> LoadingState()
                    is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                    is UiState.Success -> if (s.data.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.Notifications,
                            title = stringResource(R.string.inbox_empty_title),
                            message = stringResource(R.string.inbox_empty_message),
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(s.data, key = { it.request.id }) { row -> RequestCard(row, onClick = { onOpen(row.request.id) }) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestCard(row: RequestWithCustomer, onClick: () -> Unit) {
    val r = row.request
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(row.customerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                RequestStatusChip(r.status)
            }
            Text(
                r.offerName.ifBlank { stringResource(r.serviceType.labelRes) } + " • " + stringResource(r.provider.labelRes),
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(r.targetPhone, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text(moneyLabel(r.customerPriceMinor), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Text(formatDateTime(r.createdAtMillis), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ------------------------------------------------------------------ تفاصيل الطلب

private enum class DetailsDialog { REJECT, CANCEL, FAILURE, EXECUTE }

@Composable
fun RequestDetailsScreen(
    requestId: String,
    onBack: () -> Unit,
    viewModel: RequestDetailsViewModel = viewModel(factory = RequestDetailsViewModel.factory(requestId)),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    var dialog by rememberSaveable { mutableStateOf<DetailsDialog?>(null) }

    AppScaffold(title = stringResource(R.string.request_details_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                is UiState.Success -> {
                    val data = s.data
                    if (data == null) {
                        EmptyState(
                            icon = Icons.Default.Notifications,
                            title = stringResource(R.string.request_not_found),
                            message = "",
                        )
                    } else {
                        val r = data.request.request
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            message?.let { m ->
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (m.isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(if (m.isError) Icons.Default.Warning else Icons.Default.CheckCircle, contentDescription = null)
                                        Text(stringResource(m.res), modifier = Modifier.weight(1f))
                                        TextButton(onClick = viewModel::clearMessage) { Text(stringResource(R.string.receipt_done)) }
                                    }
                                }
                            }
                            InfoCard(
                                title = stringResource(R.string.request_section_info),
                                header = { RequestStatusChip(r.status) },
                            ) {
                                InfoLine(R.string.req_customer, data.request.customerName)
                                InfoLine(R.string.req_registered_phone, data.request.customerPhone)
                                InfoLine(R.string.req_beneficiary, r.targetPhone)
                                InfoLine(R.string.req_network, stringResource(r.provider.labelRes))
                                InfoLine(R.string.req_service, stringResource(r.serviceType.labelRes) + if (r.offerName.isNotBlank()) " — " + r.offerName else "")
                                InfoLine(R.string.req_face_value, moneyLabel(r.faceValueMinor))
                                InfoLine(R.string.req_customer_price, moneyLabel(r.customerPriceMinor))
                                InfoLine(R.string.req_created_at, formatDateTime(r.createdAtMillis))
                                r.executedAtMillis?.let { InfoLine(R.string.req_executed_at, formatDateTime(it)) }
                                r.note?.let { InfoLine(R.string.req_note, it) }
                                r.statusNote?.let { InfoLine(R.string.req_status_note, it) }
                                r.lastFailureReason?.let { InfoLine(R.string.req_last_failure, it) }
                            }

                            // ---- الإجراءات حسب الحالة
                            when (r.status) {
                                RequestStatus.SUBMITTED -> {
                                    ActionButton(R.string.action_start_review, !busy) { viewModel.changeStatus(RequestStatus.UNDER_REVIEW) }
                                    ActionButton(R.string.action_approve, !busy) { viewModel.changeStatus(RequestStatus.APPROVED) }
                                    OutlinedButton(onClick = { dialog = DetailsDialog.REJECT }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_reject)) }
                                    OutlinedButton(onClick = { dialog = DetailsDialog.CANCEL }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_cancel_request)) }
                                }
                                RequestStatus.UNDER_REVIEW -> {
                                    ActionButton(R.string.action_approve, !busy) { viewModel.changeStatus(RequestStatus.APPROVED) }
                                    OutlinedButton(onClick = { dialog = DetailsDialog.REJECT }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_reject)) }
                                }
                                RequestStatus.APPROVED -> {
                                    Text(stringResource(R.string.exec_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    ActionButton(R.string.action_confirm_executed, !busy) { dialog = DetailsDialog.EXECUTE }
                                    FilledTonalButton(onClick = { dialog = DetailsDialog.FAILURE }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                                        Text(stringResource(R.string.action_charge_failed))
                                    }
                                    OutlinedButton(onClick = { dialog = DetailsDialog.CANCEL }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_cancel_request)) }
                                }
                                else -> Unit
                            }

                            if (r.status == RequestStatus.EXECUTED && data.executionEntries.isNotEmpty()) {
                                InfoCard(title = stringResource(R.string.request_section_ledger)) {
                                    data.executionEntries.forEach { e ->
                                        InfoLine(e.type.labelRes, moneyLabel(e.amountMinor))
                                    }
                                    val last = data.executionEntries.last()
                                    HorizontalDivider()
                                    InfoLine(R.string.preview_balance_after, moneyLabel(last.balanceAfterMinor))
                                    InfoLine(R.string.preview_debt_after, moneyLabel(last.debtAfterMinor))
                                }
                            }

                            InfoCard(title = stringResource(R.string.request_section_timeline)) {
                                data.events.forEach { e ->
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(stringResource(e.type.labelRes), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        if (e.fromStatus != null && e.toStatus != null && e.fromStatus != e.toStatus) {
                                            Text(stringResource(e.fromStatus.labelRes) + "  ←  " + stringResource(e.toStatus.labelRes), style = MaterialTheme.typography.bodySmall)
                                        }
                                        e.note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                                        Text(formatDateTime(e.createdAtMillis), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }

                        when (dialog) {
                            DetailsDialog.REJECT -> ReasonDialog(R.string.action_reject, R.string.reason_label, onDismiss = { dialog = null }) {
                                viewModel.changeStatus(RequestStatus.REJECTED, it); dialog = null
                            }
                            DetailsDialog.CANCEL -> ReasonDialog(R.string.action_cancel_request, R.string.reason_label, onDismiss = { dialog = null }) {
                                viewModel.changeStatus(RequestStatus.CANCELLED, it); dialog = null
                            }
                            DetailsDialog.FAILURE -> ReasonDialog(R.string.action_charge_failed, R.string.failure_reason_label, onDismiss = { dialog = null }) {
                                viewModel.recordFailure(it); dialog = null
                            }
                            DetailsDialog.EXECUTE -> {
                                val customer = data.customer
                                val plan = customer?.let {
                                    LedgerRules.planPartialConsumption(
                                        AccountState(it.balanceMinor, it.debtMinor, it.customer.creditLimitMinor), r.customerPriceMinor,
                                    )
                                }
                                AlertDialog(
                                    onDismissRequest = { dialog = null },
                                    title = { Text(stringResource(R.string.exec_dialog_title)) },
                                    text = {
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(stringResource(R.string.exec_dialog_warning))
                                            InfoLine(R.string.req_customer_price, moneyLabel(r.customerPriceMinor))
                                            when (plan) {
                                                is PlanResult.Ok -> {
                                                    plan.postings.forEach { p -> InfoLine(p.type.labelRes, moneyLabel(p.amountMinor)) }
                                                    InfoLine(R.string.preview_balance_after, moneyLabel(plan.resulting.balanceMinor))
                                                    InfoLine(R.string.preview_debt_after, moneyLabel(plan.resulting.debtMinor))
                                                }
                                                is PlanResult.Rejected -> Text(stringResource(plan.reason.labelRes), color = MaterialTheme.colorScheme.error)
                                                null -> Unit
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Button(onClick = { viewModel.confirmExecuted(); dialog = null }, enabled = plan is PlanResult.Ok && !busy) {
                                            Text(stringResource(R.string.action_confirm_executed))
                                        }
                                    },
                                    dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.dialog_cancel)) } },
                                )
                            }
                            null -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(labelRes: Int, enabled: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(52.dp)) {
        Text(stringResource(labelRes), style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun InfoCard(title: String, header: @Composable () -> Unit = {}, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                header()
            }
            content()
        }
    }
}

@Composable
private fun InfoLine(labelRes: Int, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(labelRes), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.45f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.55f))
    }
}

@Composable
private fun ReasonDialog(titleRes: Int, labelRes: Int, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(stringResource(labelRes)) }, modifier = Modifier.fillMaxWidth())
        },
        confirmButton = { Button(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(stringResource(titleRes)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.dialog_cancel)) } },
    )
}

// ------------------------------------------------------------------ تسجيل طلب نيابة عن عميل

@Composable
fun RequestIntakeScreen(
    customerId: String,
    onBack: () -> Unit,
    onCreated: (String) -> Unit,
    viewModel: RequestIntakeViewModel = viewModel(factory = RequestIntakeViewModel.factory(customerId)),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state.createdRequestId) {
        state.createdRequestId?.let(onCreated)
    }
    AppScaffold(title = stringResource(R.string.intake_title), onBack = onBack) { padding ->
        val customer = state.customer
        when {
            !state.loaded -> LoadingState(Modifier.padding(padding))
            customer == null -> EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.customer_not_found_title),
                message = stringResource(R.string.customer_not_found_message),
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(customer.customer.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.intake_help), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (state.step == IntakeStep.FORM) {
                    if (state.offers.isEmpty()) {
                        EmptyState(
                            icon = Icons.Default.Notifications,
                            title = stringResource(R.string.intake_no_offers_title),
                            message = stringResource(R.string.intake_no_offers_message),
                        )
                    } else {
                        OfferPickerSection(state.offers, state.selectedOfferId, viewModel::selectOffer)
                        OutlinedTextField(
                            value = state.phone, onValueChange = viewModel::onPhone, singleLine = true,
                            label = { Text(stringResource(R.string.req_beneficiary)) }, modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            value = state.note, onValueChange = viewModel::onNote,
                            label = { Text(stringResource(R.string.field_description)) }, modifier = Modifier.fillMaxWidth(),
                        )
                        state.rejection?.let { Text(stringResource(it.labelRes), color = MaterialTheme.colorScheme.error) }
                        ActionButton(R.string.action_continue, state.selectedOfferId != null && state.phone.isNotBlank()) { viewModel.continueToConfirm() }
                    }
                } else {
                    val offer = state.selected
                    if (offer != null) {
                        InfoCard(title = stringResource(R.string.intake_confirm_title)) {
                            InfoLine(R.string.req_network, stringResource(offer.provider.labelRes))
                            InfoLine(R.string.req_service, stringResource(offer.serviceType.labelRes) + " — " + offer.name)
                            InfoLine(R.string.req_beneficiary, state.phone)
                            if (offer.faceValueMinor > 0) InfoLine(R.string.req_face_value, moneyLabel(offer.faceValueMinor))
                            InfoLine(R.string.req_customer_price, moneyLabel(offer.priceMinor))
                        }
                        Text(stringResource(R.string.intake_no_deduction), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ActionButton(R.string.intake_confirm_submit, !state.submitting) { viewModel.submit() }
                    OutlinedButton(onClick = viewModel::backToForm, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_back_to_edit)) }
                }
            }
        }
    }
}
