package com.factorycharge.admin.data

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.factorycharge.core.ledger.AccountState
import com.factorycharge.core.ledger.CustomerError
import com.factorycharge.core.ledger.LedgerRules
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.ledger.OperationRejection
import com.factorycharge.core.ledger.PlanResult
import com.factorycharge.core.model.RequestEventType
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.ledger.Posting
import com.factorycharge.core.util.PhoneNumber
import kotlinx.coroutines.flow.Flow
import java.util.UUID

sealed interface OperationOutcome {
    /** سُجّلت كل قيود العملية في الدفتر في معاملة واحدة. */
    data class Recorded(
        val entries: List<LedgerEntryEntity>,
        val resulting: AccountState,
    ) : OperationOutcome

    /** رُفضت العملية ولم يُكتب أي شيء في الدفتر. */
    data class Rejected(val reason: OperationRejection) : OperationOutcome
}

/** نتيجة تأكيد تنفيذ طلب شحن. */
sealed interface ExecutionOutcome {
    /** نُفِّذ الآن: سُجّل الخصم وتغيّرت الحالة إلى EXECUTED في معاملة واحدة. */
    data class Executed(
        val request: ChargeRequestEntity,
        val entries: List<LedgerEntryEntity>,
        val resulting: AccountState,
    ) : ExecutionOutcome

    /** كان منفذاً من قبل: نتيجة التنفيذ السابقة كما هي، ولم يُنشأ أي قيد جديد. */
    data class AlreadyExecuted(
        val request: ChargeRequestEntity,
        val entries: List<LedgerEntryEntity>,
    ) : ExecutionOutcome

    /** رُفض التنفيذ ولم يُسجَّل أي خصم ولم تتغير حالة الطلب. */
    data class Rejected(val reason: OperationRejection) : ExecutionOutcome
}

sealed interface CustomerResult {
    data class Saved(val customerId: String) : CustomerResult
    data class Failed(val error: CustomerError) : CustomerResult
}

/**
 * المكان الوحيد الذي يكتب في الدفتر. كل عملية مالية = معاملة Room واحدة (all-or-nothing):
 * فحص التكرار + قراءة الحالة + تخطيط القيود + إدراجها. القواعد الحسابية في [LedgerRules].
 *
 * معاملات الإنشاء:
 * [beforeCommit] نقطة اختبار فقط: تُستدعى في نهاية معاملة تنفيذ الطلب قبل إتمامها (فشل هنا يجب أن يتراجع
 * عن القيود وتغيير الحالة معاً).
 * [afterEntryInserted] نقطة اختبار فقط: تُستدعى بعد إدراج كل قيد داخل المعاملة، ليتمكن الاختبار
 * من إفشال العملية في المنتصف والتأكد من التراجع الكامل. القيمة الافتراضية لا تفعل شيئاً.
 */
class FinancialRepository(
    private val db: AdminDatabase,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val newId: () -> String = { UUID.randomUUID().toString() },
    private val afterEntryInserted: (index: Int) -> Unit = {},
    private val beforeCommit: () -> Unit = {},
) {
    private val customers get() = db.customerDao()
    private val ledger get() = db.ledgerDao()

    // ---------------------------------------------------------------- العملاء

    suspend fun addCustomer(name: String, phone: String, creditLimitMinor: Long = 0L): CustomerResult {
        val cleanName = cleanName(name) ?: return CustomerResult.Failed(CustomerError.INVALID_NAME)
        val cleanPhone = PhoneNumber.normalize(phone) ?: return CustomerResult.Failed(CustomerError.INVALID_PHONE)
        if (creditLimitMinor < 0) return CustomerResult.Failed(CustomerError.NEGATIVE_LIMIT)
        val id = newId()
        return try {
            customers.insert(
                CustomerEntity(
                    id = id,
                    displayName = cleanName,
                    phone = cleanPhone,
                    createdAtMillis = nowMillis(),
                    isActive = true,
                    creditLimitMinor = creditLimitMinor,
                ),
            )
            CustomerResult.Saved(id)
        } catch (e: SQLiteConstraintException) {
            CustomerResult.Failed(CustomerError.DUPLICATE_PHONE)
        }
    }

    suspend fun updateCustomer(id: String, name: String, phone: String): CustomerResult {
        val cleanName = cleanName(name) ?: return CustomerResult.Failed(CustomerError.INVALID_NAME)
        val cleanPhone = PhoneNumber.normalize(phone) ?: return CustomerResult.Failed(CustomerError.INVALID_PHONE)
        return try {
            if (customers.updateProfile(id, cleanName, cleanPhone) == 0) {
                CustomerResult.Failed(CustomerError.NOT_FOUND)
            } else {
                CustomerResult.Saved(id)
            }
        } catch (e: SQLiteConstraintException) {
            CustomerResult.Failed(CustomerError.DUPLICATE_PHONE)
        }
    }

    suspend fun setCustomerActive(id: String, active: Boolean): CustomerResult =
        if (customers.setActive(id, active) == 0) CustomerResult.Failed(CustomerError.NOT_FOUND) else CustomerResult.Saved(id)

    /** لا يُقبل حد أقل من المديونية الحالية (للإيقاف الفعلي للائتمان اجعله مساوياً لها). */
    suspend fun setCreditLimit(id: String, limitMinor: Long): CustomerResult {
        if (limitMinor < 0) return CustomerResult.Failed(CustomerError.NEGATIVE_LIMIT)
        return db.withTransaction<CustomerResult> {
            if (customers.getById(id) == null) return@withTransaction CustomerResult.Failed(CustomerError.NOT_FOUND)
            if (limitMinor < ledger.getTotals(id).totalDebtMinor) {
                return@withTransaction CustomerResult.Failed(CustomerError.LIMIT_BELOW_DEBT)
            }
            customers.setCreditLimit(id, limitMinor)
            CustomerResult.Saved(id)
        }
    }

    suspend fun getCustomer(id: String): CustomerEntity? = customers.getById(id)

    // ---------------------------------------------------------------- العمليات المالية

    /** إيداع نقدي: تسوية المديونية أولاً ثم الباقي للمحفظة، في معاملة واحدة. */
    suspend fun deposit(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CASH_DEPOSIT, description) {
            LedgerRules.planDeposit(it, amountMinor)
        }

    /** سحب نقدي (تسليم نقد للعميل) من رصيد المحفظة فقط. */
    suspend fun withdraw(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CASH_WITHDRAWAL, description) {
            LedgerRules.planWithdrawal(it, amountMinor)
        }

    /**
     * خصم بسياسة partial (للاستخدام المستقبلي من مرحلة الشحن؛ لا تنفيذ للشحن هنا ولا شاشة لها):
     * الرصيد أولاً ثم الفرق مديونية ضمن الحد الائتماني، وكل الأجزاء تُسجَّل في معاملة واحدة.
     */
    suspend fun recordConsumption(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CONSUMPTION, description) {
            LedgerRules.planPartialConsumption(it, amountMinor)
        }

    /**
     * تصحيح بقيد عكسي: ينشئ قيداً جديداً بأثر معاكس لقيد سابق دون المساس بالأصل.
     * القيد يُعكس مرة واحدة، ولا يُعكس قيد عكسي، ولا يجوز أن ينتج رصيد/دين سالب.
     */
    suspend fun reverseEntry(entryId: String, operationId: String, description: String? = null): OperationOutcome =
        guarded {
            db.withTransaction<OperationOutcome> {
                precheck(operationId)?.let { return@withTransaction it }
                val original = ledger.getById(entryId)
                    ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.ENTRY_NOT_FOUND)
                if (ledger.countReversalsOf(entryId) > 0) {
                    return@withTransaction OperationOutcome.Rejected(OperationRejection.ENTRY_ALREADY_REVERSED)
                }
                val customer = customers.getById(original.customerId)
                    ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_NOT_FOUND)
                val state = loadState(customer)
                val originalPosting = Posting(original.type, original.balanceDeltaMinor, original.debtDeltaMinor)
                when (val plan = LedgerRules.planReversal(state, originalPosting)) {
                    is PlanResult.Rejected -> OperationOutcome.Rejected(plan.reason)
                    is PlanResult.Ok -> record(customer.id, operationId, OperationKind.REVERSAL, description, entryId, state, plan.postings)
                }
            }
        }

    /**
     * تأكيد تنفيذ طلب شحن (بعد أن نفّذه المسؤول فعلياً خارج التطبيق ونجح). هو المكان الوحيد الذي يُسجَّل فيه
     * خصم الطلب، ويستخدم نفس النظام المالي (سياسة partial) بالخطوات التالية داخل معاملة واحدة:
     * 1) الطلب معتمد (APPROVED) ولم يُنفَّذ؛ 2) العميل نشط؛ 3) خطة partial على السعر المعتمد للطلب
     * (الرصيد أولاً ثم دين ضمن الحد الائتماني، وإلا رفض كامل)؛ 4) إدراج القيود؛ 5) تغيير الحالة إلى EXECUTED.
     * معرّف العملية مشتق من requestId فلا يمكن خصم الطلب مرتين حتى لو تكرر الضغط أو الاستدعاء.
     */
    suspend fun executeChargeRequest(requestId: String): ExecutionOutcome =
        try {
            db.withTransaction<ExecutionOutcome> {
                val requests = db.chargeRequestDao()
                val request = requests.getById(requestId)
                    ?: return@withTransaction ExecutionOutcome.Rejected(OperationRejection.REQUEST_NOT_FOUND)
                val operationId = executionOperationId(requestId)
                if (request.status == RequestStatus.EXECUTED) {
                    return@withTransaction ExecutionOutcome.AlreadyExecuted(request, ledger.listByOperation(operationId))
                }
                if (request.status != RequestStatus.APPROVED) {
                    return@withTransaction ExecutionOutcome.Rejected(OperationRejection.REQUEST_NOT_APPROVED)
                }
                val customer = customers.getById(request.customerId)
                    ?: return@withTransaction ExecutionOutcome.Rejected(OperationRejection.CUSTOMER_NOT_FOUND)
                if (!customer.isActive) {
                    return@withTransaction ExecutionOutcome.Rejected(OperationRejection.CUSTOMER_INACTIVE)
                }
                if (ledger.countByOperation(operationId) > 0) {
                    return@withTransaction ExecutionOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
                }
                val state = loadState(customer)
                when (val plan = LedgerRules.planPartialConsumption(state, request.customerPriceMinor)) {
                    is PlanResult.Rejected -> ExecutionOutcome.Rejected(plan.reason)
                    is PlanResult.Ok -> {
                        val recorded = record(
                            customer.id, operationId, OperationKind.CONSUMPTION,
                            "شحن: " + request.offerName + " → " + request.targetPhone,
                            null, state, plan.postings,
                        )
                        val now = nowMillis()
                        if (requests.markExecuted(requestId, now) != 1) {
                            throw IllegalStateException("request $requestId was not APPROVED at commit time")
                        }
                        db.requestEventDao().insert(
                            RequestEventEntity(
                                requestId = requestId,
                                type = RequestEventType.EXECUTED,
                                fromStatus = RequestStatus.APPROVED,
                                toStatus = RequestStatus.EXECUTED,
                                note = operationId,
                                createdAtMillis = now,
                            ),
                        )
                        beforeCommit()
                        ExecutionOutcome.Executed(requests.getById(requestId)!!, recorded.entries, recorded.resulting)
                    }
                }
            }
        } catch (e: SQLiteConstraintException) {
            if (e.message?.contains("ledger_entries.operationId") == true) {
                ExecutionOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
            } else {
                throw e
            }
        }

    /** قيود تنفيذ طلب (للعرض): تُقرأ بمعرف العملية المشتق من الطلب. */
    fun observeExecutionEntries(requestId: String): Flow<List<LedgerEntryEntity>> =
        ledger.observeByOperation(executionOperationId(requestId))

    // ---------------------------------------------------------------- القراءة

    fun observeCustomers(query: String): Flow<List<CustomerWithBalances>> =
        customers.observeWithBalances(escapeLike(query.trim()))

    fun observeCustomer(id: String): Flow<CustomerWithBalances?> = customers.observeWithBalancesById(id)

    fun observeStatement(customerId: String): Flow<List<LedgerEntryEntity>> = ledger.observeStatement(customerId)

    fun observeTotals(): Flow<LedgerTotals> = ledger.observeAllTotals()

    /** سجل العمليات العام (الأحدث أولاً). */
    fun observeRecentEntries(limit: Int = 200): Flow<List<LedgerEntryWithCustomer>> = ledger.observeRecentWithCustomer(limit)

    fun observeCustomerCount(): Flow<Int> = customers.observeCount()

    fun observeActiveCustomerCount(): Flow<Int> = customers.observeActiveCount()

    // ---------------------------------------------------------------- داخلي

    private suspend fun runPlanned(
        customerId: String,
        operationId: String,
        kind: OperationKind,
        description: String?,
        plan: (AccountState) -> PlanResult,
    ): OperationOutcome = guarded {
        db.withTransaction<OperationOutcome> {
            precheck(operationId)?.let { return@withTransaction it }
            val customer = customers.getById(customerId)
                ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_NOT_FOUND)
            if (!customer.isActive) {
                return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_INACTIVE)
            }
            val state = loadState(customer)
            when (val p = plan(state)) {
                is PlanResult.Rejected -> OperationOutcome.Rejected(p.reason)
                is PlanResult.Ok -> record(customer.id, operationId, kind, description, null, state, p.postings)
            }
        }
    }

    private suspend fun precheck(operationId: String): OperationOutcome.Rejected? {
        if (operationId.isBlank()) return OperationOutcome.Rejected(OperationRejection.INVALID_OPERATION_ID)
        if (ledger.countByOperation(operationId) > 0) return OperationOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
        return null
    }

    /** الحالة تُشتق دائماً من مجموع الدفتر داخل نفس المعاملة، لا من أي قيمة مخزَّنة. */
    private suspend fun loadState(customer: CustomerEntity): AccountState {
        val totals = ledger.getTotals(customer.id)
        return AccountState(totals.totalBalanceMinor, totals.totalDebtMinor, customer.creditLimitMinor)
    }

    private suspend fun record(
        customerId: String,
        operationId: String,
        kind: OperationKind,
        description: String?,
        reversesEntryId: String?,
        startState: AccountState,
        postings: List<Posting>,
    ): OperationOutcome.Recorded {
        val now = nowMillis()
        val note = description?.trim()?.take(MAX_DESCRIPTION)?.ifBlank { null }
        var state = startState
        var sequence = ledger.maxSequence()
        val saved = ArrayList<LedgerEntryEntity>(postings.size)
        postings.forEachIndexed { index, posting ->
            state = LedgerRules.apply(state, posting)
            sequence += 1
            val entry = LedgerEntryEntity(
                id = newId(),
                operationId = operationId,
                lineNo = index,
                customerId = customerId,
                type = posting.type,
                operationKind = kind,
                amountMinor = posting.amountMinor,
                balanceDeltaMinor = posting.balanceDeltaMinor,
                debtDeltaMinor = posting.debtDeltaMinor,
                balanceAfterMinor = state.balanceMinor,
                debtAfterMinor = state.debtMinor,
                sequence = sequence,
                createdAtMillis = now,
                description = note,
                reversesEntryId = reversesEntryId,
            )
            ledger.insert(entry)
            afterEntryInserted(index)
            saved += entry
        }
        return OperationOutcome.Recorded(saved, state)
    }

    /** تحويل مخالفة التفرد على operationId (سباق نظري) إلى رفض واضح؛ غير ذلك يُعاد رميه. */
    private suspend fun guarded(block: suspend () -> OperationOutcome): OperationOutcome =
        try {
            block()
        } catch (e: SQLiteConstraintException) {
            if (e.message?.contains("ledger_entries.operationId") == true) {
                OperationOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
            } else {
                throw e
            }
        }

    private fun cleanName(raw: String): String? =
        raw.trim().replace(Regex("\\s+"), " ").takeIf { it.isNotEmpty() && it.length <= MAX_NAME }

    /** يهرّب % و _ و ! لأن البحث نصي حرفي (ESCAPE '!' في الاستعلام). */
    private fun escapeLike(q: String): String =
        q.replace("!", "!!").replace("%", "!%").replace("_", "!_")

    companion object {
        private const val MAX_DESCRIPTION = 200
        private const val MAX_NAME = 100

        /** معرّف عملية الخصم لطلب شحن: ثابت ومشتق من requestId (أساس منع الخصم المزدوج). */
        fun executionOperationId(requestId: String): String = "charge-exec:$requestId"
    }
}
