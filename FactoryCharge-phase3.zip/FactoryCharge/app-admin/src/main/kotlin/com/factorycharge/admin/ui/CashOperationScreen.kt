package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.admin.data.OperationOutcome
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.moneyLabel
import com.factorycharge.core.ledger.PlanResult

/** شاشة مشتركة للإيداع والسحب (تختلف بـ [kind]). */
@Composable
fun CashOperationScreen(
    customerId: String,
    kind: CashKind,
    onBack: () -> Unit,
    viewModel: CashOperationViewModel = viewModel(factory = adminFactory { CashOperationViewModel(it, customerId, kind) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val title = stringResource(if (kind == CashKind.DEPOSIT) R.string.deposit_title else R.string.withdraw_title)

    AppScaffold(title = title, onBack = onBack) { padding ->
        val customer = state.customer
        when {
            !state.loaded -> LoadingState(Modifier.padding(padding))
            customer == null -> EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.customer_not_found_title),
                message = stringResource(R.string.customer_not_found_message),
                modifier = Modifier.padding(padding),
            )
            state.receipt != null -> ReceiptContent(
                receipt = state.receipt!!,
                onDone = onBack,
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(customer.customer.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        LineItem(stringResource(R.string.cash_current_balance), moneyLabel(customer.balanceMinor))
                        LineItem(stringResource(R.string.cash_current_debt), moneyLabel(customer.debtMinor))
                    }
                }

                AmountField(
                    value = state.amountText,
                    onValueChange = viewModel::onAmount,
                    label = stringResource(R.string.field_amount),
                    isError = state.amountInvalid,
                    supportingText = if (state.amountInvalid) stringResource(R.string.error_invalid_amount) else null,
                )
                OutlinedTextField(
                    value = state.description,
                    onValueChange = viewModel::onDescription,
                    label = { Text(stringResource(R.string.field_description)) },
                    modifier = Modifier.fillMaxWidth(),
                )

                when (val preview = state.preview) {
                    is PlanResult.Ok -> Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.preview_title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            preview.postings.forEach { p ->
                                LineItem(stringResource(p.type.labelRes), moneyLabel(p.amountMinor))
                            }
                            HorizontalDivider()
                            LineItem(stringResource(R.string.preview_balance_after), moneyLabel(preview.resulting.balanceMinor))
                            LineItem(stringResource(R.string.preview_debt_after), moneyLabel(preview.resulting.debtMinor))
                        }
                    }
                    is PlanResult.Rejected -> if (state.amountText.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(stringResource(preview.reason.labelRes), color = MaterialTheme.colorScheme.error)
                        }
                    }
                    null -> Unit
                }

                state.rejection?.let {
                    Text(stringResource(it.labelRes), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
                if (state.unexpectedError) {
                    Text(stringResource(R.string.unexpected_error), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }

                Button(
                    onClick = viewModel::submit,
                    enabled = state.preview is PlanResult.Ok && !state.submitting && customer.customer.isActive,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text(
                        stringResource(if (kind == CashKind.DEPOSIT) R.string.deposit_submit else R.string.withdraw_submit),
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
            }
        }
    }
}

@Composable
private fun ReceiptContent(receipt: OperationOutcome.Recorded, onDone: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(stringResource(R.string.receipt_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                receipt.entries.forEach { e ->
                    LineItem(stringResource(e.type.labelRes), moneyLabel(e.amountMinor))
                }
                HorizontalDivider()
                LineItem(stringResource(R.string.preview_balance_after), moneyLabel(receipt.resulting.balanceMinor))
                LineItem(stringResource(R.string.preview_debt_after), moneyLabel(receipt.resulting.debtMinor))
                receipt.entries.firstOrNull()?.let {
                    LineItem(stringResource(R.string.receipt_reference), "#" + it.operationId.takeLast(8))
                }
            }
        }
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(stringResource(R.string.receipt_done), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun LineItem(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
