package com.factorycharge.admin.data

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * حماية الدفتر على مستوى SQLite نفسه (دفاع في العمق، بالإضافة لقواعد Kotlin):
 *  1) ممنوع UPDATE وممنوع DELETE على ledger_entries.
 *  2) كل INSERT يُتحقق منه: مبلغ موجب، رصيد/مديونية غير سالبين، sequence = أعلى رقم + 1 (بلا ثغرات)،
 *     والرصيد/المديونية الناتجان يساويان مجموع الدفتر السابق + أثر القيد، والحد الائتماني لقيد DEBT_CREATED.
 * تُثبَّت عند الإنشاء وعند كل فتح (IF NOT EXISTS) فلا يمكن أن تغيب.
 * ملاحظة صريحة: هذا يحمي من أخطاء كودنا ومن تعديل عبر واجهات Room/SQLite العادية؛ من يملك
 * صلاحية root على الهاتف أو ملف القاعدة نفسه يستطيع إسقاط الـ Triggers. الحماية التشفيرية مرحلة لاحقة.
 */
object LedgerTriggers {

    val callback: RoomDatabase.Callback = object : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) = install(db)
        override fun onOpen(db: SupportSQLiteDatabase) = install(db)
    }

    /** كل الـ Triggers (يُستدعى بعد وجود كل الجداول: عند الإنشاء وعند كل فتح، حتى بعد الترحيل). */
    fun install(db: SupportSQLiteDatabase) {
        installLedger(db)
        EVENT_STATEMENTS.forEach { db.execSQL(it) }
    }

    /** triggers الدفتر فقط (جدول ledger_entries موجود منذ الإصدار 1). */
    fun installLedger(db: SupportSQLiteDatabase) {
        LEDGER_STATEMENTS.forEach { db.execSQL(it) }
    }

    /** سجل أحداث الطلب append-only أيضاً (جدول request_events منذ الإصدار 2). */
    private val EVENT_STATEMENTS: List<String> = listOf(
        """
        CREATE TRIGGER IF NOT EXISTS request_events_no_update
        BEFORE UPDATE ON request_events
        BEGIN
            SELECT RAISE(ABORT, 'request_events is append-only: UPDATE is not allowed');
        END
        """.trimIndent(),
        """
        CREATE TRIGGER IF NOT EXISTS request_events_no_delete
        BEFORE DELETE ON request_events
        BEGIN
            SELECT RAISE(ABORT, 'request_events is append-only: DELETE is not allowed');
        END
        """.trimIndent(),
    )

    private val LEDGER_STATEMENTS: List<String> = listOf(
        """
        CREATE TRIGGER IF NOT EXISTS ledger_entries_no_update
        BEFORE UPDATE ON ledger_entries
        BEGIN
            SELECT RAISE(ABORT, 'ledger_entries is append-only: UPDATE is not allowed');
        END
        """.trimIndent(),
        """
        CREATE TRIGGER IF NOT EXISTS ledger_entries_no_delete
        BEFORE DELETE ON ledger_entries
        BEGIN
            SELECT RAISE(ABORT, 'ledger_entries is append-only: DELETE is not allowed');
        END
        """.trimIndent(),
        """
        CREATE TRIGGER IF NOT EXISTS ledger_entries_validate_insert
        BEFORE INSERT ON ledger_entries
        BEGIN
            SELECT RAISE(ABORT, 'invalid ledger entry: amount must be positive')
                WHERE NEW.amountMinor <= 0;
            SELECT RAISE(ABORT, 'invalid ledger entry: balance would be negative')
                WHERE NEW.balanceAfterMinor < 0;
            SELECT RAISE(ABORT, 'invalid ledger entry: debt would be negative')
                WHERE NEW.debtAfterMinor < 0;
            SELECT RAISE(ABORT, 'invalid ledger entry: sequence must be max+1')
                WHERE NEW.sequence <> COALESCE((SELECT MAX(sequence) FROM ledger_entries), 0) + 1;
            SELECT RAISE(ABORT, 'invalid ledger entry: balanceAfter does not match ledger')
                WHERE NEW.balanceAfterMinor <>
                    COALESCE((SELECT SUM(balanceDeltaMinor) FROM ledger_entries WHERE customerId = NEW.customerId), 0)
                    + NEW.balanceDeltaMinor;
            SELECT RAISE(ABORT, 'invalid ledger entry: debtAfter does not match ledger')
                WHERE NEW.debtAfterMinor <>
                    COALESCE((SELECT SUM(debtDeltaMinor) FROM ledger_entries WHERE customerId = NEW.customerId), 0)
                    + NEW.debtDeltaMinor;
            SELECT RAISE(ABORT, 'invalid ledger entry: exactly one of balance/debt delta must change')
                WHERE (NEW.balanceDeltaMinor = 0) = (NEW.debtDeltaMinor = 0);
            SELECT RAISE(ABORT, 'invalid ledger entry: credit limit exceeded')
                WHERE NEW.type = 'DEBT_CREATED'
                  AND NEW.debtAfterMinor > (SELECT creditLimitMinor FROM customers WHERE id = NEW.customerId);
        END
        """.trimIndent(),
    )
}
