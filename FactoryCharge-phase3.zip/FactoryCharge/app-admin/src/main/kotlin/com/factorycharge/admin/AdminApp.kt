package com.factorycharge.admin

import android.app.Application
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.admin.data.CatalogRepository
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.RequestRepository

class AdminApp : Application() {
    val database: AdminDatabase by lazy { AdminDatabase.build(this) }
    val repository: FinancialRepository by lazy { FinancialRepository(database) }
    val catalogRepository: CatalogRepository by lazy { CatalogRepository(database) }
    val requestRepository: RequestRepository by lazy { RequestRepository(database) }
}
