package com.factorycharge.admin.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.RequestEventType
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/**
 * عميل. [id] معرّف ثابت (UUID) لا يتغير أبداً. الرصيد والمديونية **غير مخزَّنين** هنا؛
 * يُحسبان دائماً من مجموع قيود الدفتر. [creditLimitMinor] إعداد (سياسة) وليس رصيداً.
 * رقم الهاتف فريد لمنع تكرار العميل.
 */
@Entity(
    tableName = "customers",
    indices = [Index(value = ["phone"], unique = true)],
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val phone: String,
    val createdAtMillis: Long,
    val isActive: Boolean,
    val creditLimitMinor: Long,
)

/**
 * عرض في كتالوج الخدمات (يديره المسؤول، ويمكن تعديل أسعاره دون تحديث APK).
 * [faceValueMinor] القيمة الاسمية و[fixedPriceMinor] سعر البيع الثابت حقلان منفصلان.
 * عروض NET_MULTIPLIER لا تخزّن سعراً: يُحسب من القيمة الاسمية × معامل الإعدادات.
 * لا يُحذف العرض أبداً (تُرجع إليه الطلبات)؛ يُعطَّل فقط. [revision] يزيد مع كل تعديل.
 */
@Entity(
    tableName = "service_offers",
    indices = [Index(value = ["provider", "serviceType", "isActive", "sortOrder"])],
)
data class ServiceOfferEntity(
    @PrimaryKey val id: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val name: String,
    val description: String?,
    val pricingMode: PricingMode,
    val faceValueMinor: Long,
    val fixedPriceMinor: Long?,
    val isActive: Boolean,
    val sortOrder: Int,
    val validFromMillis: Long?,
    val validUntilMillis: Long?,
    val revision: Long,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

/** إعدادات رقمية بسيطة (مثل معامل تسعير الرصيد الصافي بنقاط الأساس). لا قيم افتراضية مخزَّنة مسبقاً. */
@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val settingKey: String,
    val longValue: Long,
    val updatedAtMillis: Long,
) {
    companion object {
        const val NET_MULTIPLIER_BP = "net_multiplier_bp"
    }
}

/**
 * طلب شحن على جهاز المسؤول. لا يغيّر أي رصيد بإنشائه. [customerPriceMinor] هو السعر المعتمد
 * (أعاد المسؤول حسابه من الكتالوج عند الاستلام) وهو ما يُخصم عند التنفيذ. [offerName] لقطة للعرض.
 */
@Entity(
    tableName = "charge_requests",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
        ForeignKey(
            entity = ServiceOfferEntity::class,
            parentColumns = ["id"],
            childColumns = ["offerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("customerId"), Index("status"), Index("offerId"), Index("createdAtMillis")],
)
data class ChargeRequestEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val offerId: String?,
    val offerName: String,
    val targetPhone: String,
    val faceValueMinor: Long,
    val customerPriceMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String?,
    val statusNote: String?,
    val lastFailureReason: String?,
    val executedAtMillis: Long?,
)

/** سجل أحداث الطلب (تدقيق): لا يُعدَّل ولا يُحذف (Triggers). */
@Entity(
    tableName = "request_events",
    foreignKeys = [
        ForeignKey(
            entity = ChargeRequestEntity::class,
            parentColumns = ["id"],
            childColumns = ["requestId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("requestId")],
)
data class RequestEventEntity(
    @PrimaryKey(autoGenerate = true) val seq: Long = 0,
    val requestId: String,
    val type: RequestEventType,
    val fromStatus: RequestStatus?,
    val toStatus: RequestStatus?,
    val note: String?,
    val createdAtMillis: Long,
)

/**
 * قيد في الدفتر (append-only). لا يُعدَّل ولا يُحذف أبداً: يمنع ذلك Triggers في SQLite
 * (انظر [LedgerTriggers]) ولا يوجد أي DAO للتعديل أو الحذف. التصحيح = قيد جديد من نوع REVERSAL.
 *
 * - [operationId]: معرّف العملية (مفتاح عدم التكرار). قيود العملية الواحدة تتشارك المعرّف وتُرقَّم بـ [lineNo].
 * - [sequence]: رقم عالمي متسلسل بلا ثغرات على مستوى الدفتر كله (يفرضه Trigger).
 * - [balanceDeltaMinor] / [debtDeltaMinor]: الأثر الموقَّع؛ واحد منهما فقط غير صفري.
 * - [balanceAfterMinor] / [debtAfterMinor]: الرصيد/المديونية بعد القيد (يتحقق منها Trigger مقابل مجموع الدفتر).
 * - [reversesEntryId]: للقيد العكسي فقط، وفريد: القيد يُعكس مرة واحدة.
 */
@Entity(
    tableName = "ledger_entries",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
        ForeignKey(
            entity = LedgerEntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["reversesEntryId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["sequence"], unique = true),
        Index(value = ["operationId", "lineNo"], unique = true),
        Index(value = ["customerId", "sequence"]),
        Index(value = ["reversesEntryId"], unique = true),
    ],
)
data class LedgerEntryEntity(
    @PrimaryKey val id: String,
    val operationId: String,
    val lineNo: Int,
    val customerId: String,
    val type: LedgerEntryType,
    val operationKind: OperationKind,
    val amountMinor: Long,
    val balanceDeltaMinor: Long,
    val debtDeltaMinor: Long,
    val balanceAfterMinor: Long,
    val debtAfterMinor: Long,
    val sequence: Long,
    val createdAtMillis: Long,
    val description: String?,
    val reversesEntryId: String?,
)
