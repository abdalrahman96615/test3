package com.factorycharge.admin.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.factorycharge.admin.data.CatalogRepository
import com.factorycharge.admin.data.OfferResult
import com.factorycharge.admin.data.ServiceOfferEntity
import com.factorycharge.admin.data.priceMinor
import com.factorycharge.core.catalog.OfferDraft
import com.factorycharge.core.catalog.OfferError
import com.factorycharge.core.design.UiState
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.pricing.PriceCalculator
import com.factorycharge.core.util.DateText
import com.factorycharge.core.util.Money
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OfferRow(val offer: ServiceOfferEntity, val priceMinor: Long?)

data class CatalogData(val rows: List<OfferRow>, val multiplierBp: Long?)

// ------------------------------------------------------------------ قائمة الكتالوج

@OptIn(ExperimentalCoroutinesApi::class)
class ServiceCatalogViewModel(private val catalog: CatalogRepository) : ViewModel() {
    private val retryTick = MutableStateFlow(0)

    val state: StateFlow<UiState<CatalogData>> = retryTick
        .flatMapLatest {
            combine(catalog.observeOffers(), catalog.observeMultiplierBp()) { offers, multiplier ->
                CatalogData(offers.map { OfferRow(it, it.priceMinor(multiplier)) }, multiplier)
            }.asUiState()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun retry() {
        retryTick.update { it + 1 }
    }

    fun setActive(id: String, active: Boolean) {
        viewModelScope.launch { catalog.setOfferActive(id, active) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = appFactory { ServiceCatalogViewModel(it.catalogRepository) }
    }
}

// ------------------------------------------------------------------ إضافة / تعديل عرض

enum class OfferField { FACE, PRICE, SORT, FROM, UNTIL }

data class OfferFormState(
    val loading: Boolean = false,
    val notFound: Boolean = false,
    val provider: NetworkProvider = NetworkProvider.VODAFONE,
    val serviceType: ServiceType = ServiceType.BALANCE_TOPUP,
    val name: String = "",
    val description: String = "",
    val pricingMode: PricingMode = PricingMode.NET_MULTIPLIER,
    val faceText: String = "",
    val priceText: String = "",
    val sortText: String = "0",
    val fromText: String = "",
    val untilText: String = "",
    val invalidField: OfferField? = null,
    val error: OfferError? = null,
    val saving: Boolean = false,
    val savedId: String? = null,
)

class OfferEditViewModel(
    private val catalog: CatalogRepository,
    private val offerId: String?,
) : ViewModel() {
    private val _state = MutableStateFlow(OfferFormState(loading = offerId != null))
    val state: StateFlow<OfferFormState> = _state.asStateFlow()
    val isEdit: Boolean get() = offerId != null

    init {
        if (offerId != null) {
            viewModelScope.launch {
                val o = catalog.getOffer(offerId)
                _state.update {
                    if (o == null) {
                        it.copy(loading = false, notFound = true)
                    } else {
                        it.copy(
                            loading = false, provider = o.provider, serviceType = o.serviceType, name = o.name,
                            description = o.description.orEmpty(), pricingMode = o.pricingMode,
                            faceText = if (o.faceValueMinor > 0) Money.plain(o.faceValueMinor) else "",
                            priceText = o.fixedPriceMinor?.let { p -> Money.plain(p) }.orEmpty(),
                            sortText = o.sortOrder.toString(),
                            fromText = o.validFromMillis?.let { m -> DateText.formatDay(m) }.orEmpty(),
                            untilText = o.validUntilMillis?.let { m -> DateText.formatDay(m) }.orEmpty(),
                        )
                    }
                }
            }
        }
    }

    private fun edit(block: (OfferFormState) -> OfferFormState) = _state.update { block(it).copy(error = null, invalidField = null) }

    fun onProvider(v: NetworkProvider) = edit { it.copy(provider = v) }

    fun onServiceType(v: ServiceType) = edit {
        // التسعير بالمعامل للرصيد الصافي فقط
        val mode = if (v == ServiceType.BALANCE_TOPUP) it.pricingMode else PricingMode.FIXED_PRICE
        it.copy(serviceType = v, pricingMode = mode)
    }

    fun onPricingMode(v: PricingMode) = edit { it.copy(pricingMode = v) }
    fun onName(v: String) = edit { it.copy(name = v) }
    fun onDescription(v: String) = edit { it.copy(description = v) }
    fun onFace(v: String) = edit { it.copy(faceText = v) }
    fun onPrice(v: String) = edit { it.copy(priceText = v) }
    fun onSort(v: String) = edit { it.copy(sortText = v) }
    fun onFrom(v: String) = edit { it.copy(fromText = v) }
    fun onUntil(v: String) = edit { it.copy(untilText = v) }

    fun save() {
        val s = _state.value
        if (s.saving) return
        fun fail(field: OfferField) {
            _state.update { it.copy(invalidField = field) }
        }
        val face = if (s.faceText.isBlank()) 0L else Money.parseToMinor(s.faceText) ?: return fail(OfferField.FACE)
        val price: Long? = if (s.pricingMode == PricingMode.FIXED_PRICE) {
            Money.parseToMinor(s.priceText) ?: return fail(OfferField.PRICE)
        } else {
            null
        }
        val sort = if (s.sortText.isBlank()) 0 else s.sortText.trim().toIntOrNull() ?: return fail(OfferField.SORT)
        val from = if (s.fromText.isBlank()) null else DateText.parseDayStart(s.fromText) ?: return fail(OfferField.FROM)
        val until = if (s.untilText.isBlank()) null else DateText.parseDayEnd(s.untilText) ?: return fail(OfferField.UNTIL)
        val draft = OfferDraft(
            s.provider, s.serviceType, s.name, s.description.ifBlank { null }, s.pricingMode, face, price, from, until, sort,
        )
        _state.update { it.copy(saving = true, error = null, invalidField = null) }
        viewModelScope.launch {
            val result = if (offerId == null) catalog.addOffer(draft) else catalog.updateOffer(offerId, draft)
            _state.update {
                when (result) {
                    is OfferResult.Saved -> it.copy(saving = false, savedId = result.offerId)
                    is OfferResult.Failed -> it.copy(saving = false, error = result.error)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ إدارة الأسعار (معامل الرصيد الصافي)

data class PricingState(
    val loaded: Boolean = false,
    val storedBp: Long? = null,
    val multiplierText: String = "",
    val suggested: Boolean = false,
    val error: OfferError? = null,
    val saved: Boolean = false,
    val rows: List<OfferRow> = emptyList(),
) {
    /** مثال حي: سعر رصيد 100 جنيه بالمعامل المكتوب حالياً. */
    val exampleMinor: Long? get() = PriceCalculator.parseMultiplier(multiplierText)?.let { PriceCalculator.netBalancePrice(10_000, it) }
}

class PricingViewModel(private val catalog: CatalogRepository) : ViewModel() {
    private val _state = MutableStateFlow(PricingState())
    val state: StateFlow<PricingState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(catalog.observeMultiplierBp(), catalog.observeOffers()) { bp, offers -> bp to offers }
                .collect { (bp, offers) ->
                    _state.update {
                        val first = !it.loaded
                        it.copy(
                            loaded = true,
                            storedBp = bp,
                            // قبل أول حفظ: نقترح 1.5 في الحقل فقط (ليست قيمة مخزَّنة حتى يضغط المسؤول حفظ)
                            multiplierText = if (first) PriceCalculator.formatMultiplier(bp ?: SUGGESTED_BP) else it.multiplierText,
                            suggested = if (first) bp == null else it.suggested && bp == null,
                            rows = offers.filter { o -> o.pricingMode == PricingMode.NET_MULTIPLIER }.map { o -> OfferRow(o, o.priceMinor(bp)) },
                        )
                    }
                }
        }
    }

    fun onMultiplier(v: String) = _state.update { it.copy(multiplierText = v, error = null, saved = false) }

    fun save() {
        val bp = PriceCalculator.parseMultiplier(_state.value.multiplierText)
        if (bp == null) {
            _state.update { it.copy(error = OfferError.INVALID_MULTIPLIER, saved = false) }
            return
        }
        viewModelScope.launch {
            val error = catalog.setMultiplierBp(bp)
            _state.update { it.copy(error = error, saved = error == null, suggested = false) }
        }
    }

    companion object {
        /** اقتراح عرض فقط في حقل الإدخال (المعامل الذي طلبه صاحب المشروع)؛ لا يُستخدم في أي حساب قبل الحفظ. */
        const val SUGGESTED_BP = 15_000L
        val Factory: ViewModelProvider.Factory = appFactory { PricingViewModel(it.catalogRepository) }
    }
}
