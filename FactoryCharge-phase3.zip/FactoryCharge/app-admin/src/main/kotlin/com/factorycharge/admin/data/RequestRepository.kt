package com.factorycharge.admin.data

import androidx.room.withTransaction
import com.factorycharge.core.model.DeviceRole
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestEventType
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.request.RequestCheck
import com.factorycharge.core.request.RequestRejection
import com.factorycharge.core.request.RequestRules
import com.factorycharge.core.util.Money
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * طلب وارد إلى المسؤول (اليوم: يدوياً من المسؤول نيابة عن عميل؛ لاحقاً: من طبقة الاتصال).
 * [claimedPriceMinor] السعر الذي رآه العميل — غير موثوق ولا يُستخدم في أي حساب؛ يُقارَن فقط لتسجيل الاختلاف.
 */
data class IncomingRequest(
    val requestId: String,
    val customerId: String,
    val offerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val targetPhone: String,
    val note: String? = null,
    val claimedPriceMinor: Long? = null,
    val createdAtMillis: Long? = null,
)

sealed interface IngestOutcome {
    data class Created(val request: ChargeRequestEntity) : IngestOutcome
    /** الطلب مستلم من قبل (نفس requestId): لم يتغير شيء. */
    data class Duplicate(val request: ChargeRequestEntity) : IngestOutcome
    data class Rejected(val reason: RequestRejection) : IngestOutcome
}

sealed interface StatusOutcome {
    data class Changed(val request: ChargeRequestEntity) : StatusOutcome
    data class Rejected(val reason: RequestRejection) : StatusOutcome
}

data class RequestFilter(
    val statuses: Set<RequestStatus> = emptySet(),
    val provider: NetworkProvider? = null,
    val serviceType: ServiceType? = null,
    val customerQuery: String = "",
    val fromMillis: Long? = null,
    val toMillis: Long? = null,
)

/**
 * استلام الطلبات وإدارة حالتها على جهاز المسؤول. **لا تلمس الدفتر المالي أبداً**: إنشاء الطلب أو
 * الموافقة أو الرفض لا يخصم شيئاً. الخصم يتم فقط عبر [FinancialRepository.executeChargeRequest].
 */
class RequestRepository(
    private val db: AdminDatabase,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val newId: () -> String = { UUID.randomUUID().toString() },
) {
    private val requests get() = db.chargeRequestDao()
    private val events get() = db.requestEventDao()

    /** يعيد المسؤول حساب السعر من كتالوجه المعتمد ويتجاهل سعر العميل المعروض. */
    suspend fun ingest(incoming: IncomingRequest): IngestOutcome =
        db.withTransaction<IngestOutcome> {
            if (incoming.requestId.isBlank()) return@withTransaction IngestOutcome.Rejected(RequestRejection.INVALID_REQUEST_ID)
            requests.getById(incoming.requestId)?.let { return@withTransaction IngestOutcome.Duplicate(it) }
            val customer = db.customerDao().getById(incoming.customerId)
                ?: return@withTransaction IngestOutcome.Rejected(RequestRejection.CUSTOMER_NOT_FOUND)
            if (!customer.isActive) return@withTransaction IngestOutcome.Rejected(RequestRejection.CUSTOMER_INACTIVE)

            val now = nowMillis()
            val offer = db.serviceOfferDao().getById(incoming.offerId)
            val multiplier = db.settingsDao().get(AppSettingEntity.NET_MULTIPLIER_BP)?.longValue
            val check = RequestRules.check(
                offer?.toView(multiplier), incoming.provider, incoming.serviceType, incoming.targetPhone, incoming.note, now,
            )
            when (check) {
                is RequestCheck.Rejected -> IngestOutcome.Rejected(check.reason)
                is RequestCheck.Ok -> {
                    val created = minOf(incoming.createdAtMillis ?: now, now)
                    val entity = ChargeRequestEntity(
                        id = incoming.requestId,
                        customerId = customer.id,
                        provider = check.offer.provider,
                        serviceType = check.offer.serviceType,
                        offerId = check.offer.id,
                        offerName = check.offer.name,
                        targetPhone = check.beneficiary,
                        faceValueMinor = check.offer.faceValueMinor,
                        customerPriceMinor = check.priceMinor,
                        status = RequestStatus.SUBMITTED,
                        createdAtMillis = created,
                        updatedAtMillis = now,
                        note = check.note,
                        statusNote = null,
                        lastFailureReason = null,
                        executedAtMillis = null,
                    )
                    requests.insert(entity)
                    events.insert(event(entity.id, RequestEventType.INGESTED, null, RequestStatus.SUBMITTED, null, now))
                    val claimed = incoming.claimedPriceMinor
                    if (claimed != null && claimed != check.priceMinor) {
                        val note = Money.formatGrouped(claimed) + " ← " + Money.formatGrouped(check.priceMinor)
                        events.insert(event(entity.id, RequestEventType.PRICE_MISMATCH, null, null, note, now))
                    }
                    IngestOutcome.Created(entity)
                }
            }
        }

    /**
     * تغيير حالة غير مالي وفق RequestStatus. التنفيذ (EXECUTED) ممنوع هنا لأنه يسجل خصماً مالياً.
     * الرفض والإلغاء يتطلبان سبباً.
     */
    suspend fun changeStatus(requestId: String, next: RequestStatus, note: String? = null): StatusOutcome {
        if (next == RequestStatus.EXECUTED) return StatusOutcome.Rejected(RequestRejection.USE_EXECUTE_ACTION)
        return db.withTransaction<StatusOutcome> {
            val request = requests.getById(requestId) ?: return@withTransaction StatusOutcome.Rejected(RequestRejection.REQUEST_NOT_FOUND)
            if (!request.status.canTransitionTo(next, DeviceRole.ADMIN)) {
                return@withTransaction StatusOutcome.Rejected(RequestRejection.INVALID_TRANSITION)
            }
            val clean = note?.trim()?.ifBlank { null }
            if ((next == RequestStatus.REJECTED || next == RequestStatus.CANCELLED) && clean == null) {
                return@withTransaction StatusOutcome.Rejected(RequestRejection.REASON_REQUIRED)
            }
            if (next == RequestStatus.APPROVED) {
                val customer = db.customerDao().getById(request.customerId)
                    ?: return@withTransaction StatusOutcome.Rejected(RequestRejection.CUSTOMER_NOT_FOUND)
                if (!customer.isActive) return@withTransaction StatusOutcome.Rejected(RequestRejection.CUSTOMER_INACTIVE)
            }
            val now = nowMillis()
            requests.updateStatus(requestId, next.name, clean ?: request.statusNote, now)
            events.insert(event(requestId, RequestEventType.STATUS_CHANGED, request.status, next, clean, now))
            StatusOutcome.Changed(requests.getById(requestId)!!)
        }
    }

    /**
     * تسجيل فشل الشحن الفعلي (خارج التطبيق) لطلب معتمد: يُحفظ السبب في الطلب وفي سجل الأحداث،
     * ويبقى الطلب APPROVED لإعادة المحاولة أو الإلغاء. **لا يُسجَّل أي خصم.**
     */
    suspend fun recordExecutionFailure(requestId: String, reason: String): StatusOutcome {
        val clean = reason.trim().ifBlank { null } ?: return StatusOutcome.Rejected(RequestRejection.REASON_REQUIRED)
        return db.withTransaction<StatusOutcome> {
            val request = requests.getById(requestId) ?: return@withTransaction StatusOutcome.Rejected(RequestRejection.REQUEST_NOT_FOUND)
            if (request.status != RequestStatus.APPROVED) {
                return@withTransaction StatusOutcome.Rejected(RequestRejection.INVALID_TRANSITION)
            }
            val now = nowMillis()
            requests.markFailure(requestId, clean, now)
            events.insert(event(requestId, RequestEventType.EXECUTION_FAILED, RequestStatus.APPROVED, RequestStatus.APPROVED, clean, now))
            StatusOutcome.Changed(requests.getById(requestId)!!)
        }
    }

    fun observeRequests(filter: RequestFilter): Flow<List<RequestWithCustomer>> = requests.observeFiltered(
        allStatuses = filter.statuses.isEmpty(),
        statuses = filter.statuses.map { it.name },
        provider = filter.provider?.name,
        serviceType = filter.serviceType?.name,
        customerQuery = escapeLikeQuery(filter.customerQuery.trim()),
        fromMillis = filter.fromMillis ?: 0L,
        toMillis = filter.toMillis ?: Long.MAX_VALUE,
    )

    fun observeRequest(id: String): Flow<RequestWithCustomer?> = requests.observeById(id)

    fun observeEvents(id: String): Flow<List<RequestEventEntity>> = events.observeForRequest(id)

    fun observeNewCount(): Flow<Int> = requests.observeNewCount()

    fun observeStatusCounts(): Flow<List<StatusCount>> = requests.observeStatusCounts()

    fun observeExecutedByProvider(): Flow<List<ProviderTotals>> = requests.observeExecutedByProvider()

    private fun event(
        requestId: String,
        type: RequestEventType,
        from: RequestStatus?,
        to: RequestStatus?,
        note: String?,
        now: Long,
    ) = RequestEventEntity(requestId = requestId, type = type, fromStatus = from, toStatus = to, note = note, createdAtMillis = now)
}

/** يهرّب % و _ و ! لأن البحث نصي حرفي (ESCAPE '!' في الاستعلام). */
internal fun escapeLikeQuery(q: String): String = q.replace("!", "!!").replace("%", "!%").replace("_", "!_")
