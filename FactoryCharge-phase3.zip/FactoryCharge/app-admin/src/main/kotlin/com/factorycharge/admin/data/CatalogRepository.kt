package com.factorycharge.admin.data

import androidx.room.withTransaction
import com.factorycharge.core.catalog.OfferDraft
import com.factorycharge.core.catalog.OfferError
import com.factorycharge.core.catalog.OfferRules
import com.factorycharge.core.pricing.PriceCalculator
import com.factorycharge.core.request.OfferView
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

sealed interface OfferResult {
    data class Saved(val offerId: String) : OfferResult
    data class Failed(val error: OfferError) : OfferResult
}

/** سعر العرض الحالي (للعرض والتحقق)؛ null إن لم يمكن حسابه (مثلاً لم يُحدَّد معامل التسعير). */
fun ServiceOfferEntity.priceMinor(multiplierBp: Long?): Long? =
    PriceCalculator.priceFor(pricingMode, faceValueMinor, fixedPriceMinor, multiplierBp)

fun ServiceOfferEntity.toView(multiplierBp: Long?): OfferView = OfferView(
    id = id,
    provider = provider,
    serviceType = serviceType,
    name = name,
    faceValueMinor = faceValueMinor,
    priceMinor = priceMinor(multiplierBp),
    isActive = isActive,
    validFromMillis = validFromMillis,
    validUntilMillis = validUntilMillis,
)

/**
 * إدارة كتالوج الخدمات والأسعار. يعمل بالكامل محلياً على هاتف المسؤول؛ تعديل الأسعار والعروض لا يحتاج
 * تحديث APK. لا يوجد حذف للعروض (تُرجع إليها الطلبات)؛ التعطيل فقط. لا قيم أسعار أو معامل افتراضية مخزَّنة.
 */
class CatalogRepository(
    private val db: AdminDatabase,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val newId: () -> String = { UUID.randomUUID().toString() },
) {
    private val offers get() = db.serviceOfferDao()
    private val settings get() = db.settingsDao()

    fun observeOffers(): Flow<List<ServiceOfferEntity>> = offers.observeAll()

    fun observeOffer(id: String): Flow<ServiceOfferEntity?> = offers.observeById(id)

    suspend fun getOffer(id: String): ServiceOfferEntity? = offers.getById(id)

    /** معامل تسعير الرصيد الصافي بنقاط الأساس؛ null إن لم يحدده المسؤول بعد. */
    fun observeMultiplierBp(): Flow<Long?> = settings.observe(AppSettingEntity.NET_MULTIPLIER_BP).map { it?.longValue }

    suspend fun getMultiplierBp(): Long? = settings.get(AppSettingEntity.NET_MULTIPLIER_BP)?.longValue

    /** يعيد null عند النجاح أو سبب الرفض. */
    suspend fun setMultiplierBp(bp: Long): OfferError? {
        if (bp < 1 || bp > PriceCalculator.MAX_MULTIPLIER_BP) return OfferError.INVALID_MULTIPLIER
        settings.upsert(AppSettingEntity(AppSettingEntity.NET_MULTIPLIER_BP, bp, nowMillis()))
        return null
    }

    suspend fun addOffer(draft: OfferDraft): OfferResult {
        OfferRules.validate(draft)?.let { return OfferResult.Failed(it) }
        val now = nowMillis()
        val id = newId()
        offers.insert(
            ServiceOfferEntity(
                id = id,
                provider = draft.provider,
                serviceType = draft.serviceType,
                name = OfferRules.cleanName(draft.name)!!,
                description = draft.description?.trim()?.ifBlank { null },
                pricingMode = draft.pricingMode,
                faceValueMinor = draft.faceValueMinor,
                fixedPriceMinor = draft.fixedPriceMinor,
                isActive = true,
                sortOrder = draft.sortOrder,
                validFromMillis = draft.validFromMillis,
                validUntilMillis = draft.validUntilMillis,
                revision = 1,
                createdAtMillis = now,
                updatedAtMillis = now,
            ),
        )
        return OfferResult.Saved(id)
    }

    /** تعديل عرض (بما فيه السعر). الطلبات القائمة تحتفظ بسعرها المعتمد وقت استلامها. */
    suspend fun updateOffer(id: String, draft: OfferDraft): OfferResult {
        OfferRules.validate(draft)?.let { return OfferResult.Failed(it) }
        return db.withTransaction<OfferResult> {
            val existing = offers.getById(id) ?: return@withTransaction OfferResult.Failed(OfferError.NOT_FOUND)
            offers.update(
                existing.copy(
                    provider = draft.provider,
                    serviceType = draft.serviceType,
                    name = OfferRules.cleanName(draft.name)!!,
                    description = draft.description?.trim()?.ifBlank { null },
                    pricingMode = draft.pricingMode,
                    faceValueMinor = draft.faceValueMinor,
                    fixedPriceMinor = draft.fixedPriceMinor,
                    sortOrder = draft.sortOrder,
                    validFromMillis = draft.validFromMillis,
                    validUntilMillis = draft.validUntilMillis,
                    revision = existing.revision + 1,
                    updatedAtMillis = nowMillis(),
                ),
            )
            OfferResult.Saved(id)
        }
    }

    suspend fun setOfferActive(id: String, active: Boolean): OfferResult =
        db.withTransaction<OfferResult> {
            val existing = offers.getById(id) ?: return@withTransaction OfferResult.Failed(OfferError.NOT_FOUND)
            if (existing.isActive != active) {
                offers.update(existing.copy(isActive = active, revision = existing.revision + 1, updatedAtMillis = nowMillis()))
            }
            OfferResult.Saved(id)
        }
}
