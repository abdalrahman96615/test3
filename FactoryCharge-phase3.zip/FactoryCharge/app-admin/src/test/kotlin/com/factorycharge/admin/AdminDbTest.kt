package com.factorycharge.admin

import androidx.room.Room
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.admin.data.CatalogRepository
import com.factorycharge.admin.data.ChargeRequestEntity
import com.factorycharge.admin.data.CustomerResult
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.IncomingRequest
import com.factorycharge.admin.data.IngestOutcome
import com.factorycharge.admin.data.LedgerTriggers
import com.factorycharge.admin.data.OfferResult
import com.factorycharge.admin.data.OperationOutcome
import com.factorycharge.admin.data.RequestRepository
import com.factorycharge.admin.data.StatusOutcome
import com.factorycharge.core.catalog.OfferDraft
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.robolectric.RuntimeEnvironment

/** أساس اختبارات المرحلة 3: قاعدة في الذاكرة بنفس Triggers الإنتاج، وبدون أي بيانات تجريبية دائمة. */
abstract class AdminDbTest {
    protected lateinit var db: AdminDatabase
    protected lateinit var finance: FinancialRepository
    protected lateinit var catalog: CatalogRepository
    protected lateinit var requests: RequestRepository
    protected var clock = 1_000L
    private var ids = 0
    private var phones = 0

    @Before
    fun setUpDb() {
        db = Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(), AdminDatabase::class.java)
            .allowMainThreadQueries()
            .addCallback(LedgerTriggers.callback)
            .build()
        finance = newFinance()
        catalog = CatalogRepository(db, nowMillis = { clock++ }, newId = { "id-${ids++}" })
        requests = RequestRepository(db, nowMillis = { clock++ }, newId = { "id-${ids++}" })
    }

    @After
    fun tearDownDb() {
        db.close()
    }

    protected fun newFinance(afterEntry: (Int) -> Unit = {}, beforeCommit: () -> Unit = {}) = FinancialRepository(
        db = db,
        nowMillis = { clock++ },
        newId = { "id-${ids++}" },
        afterEntryInserted = afterEntry,
        beforeCommit = beforeCommit,
    )

    protected fun inTest(block: suspend CoroutineScope.() -> Unit) {
        runBlocking(block = block)
    }

    protected suspend fun newCustomer(limitMinor: Long = 0): String {
        val phone = "0100000" + (phones++).toString().padStart(4, '0')
        return (finance.addCustomer("عميل اختبار", phone, limitMinor) as CustomerResult.Saved).customerId
    }

    protected suspend fun fund(customerId: String, amountMinor: Long) {
        check(finance.deposit(customerId, amountMinor, "fund-${ids++}") is OperationOutcome.Recorded)
    }

    protected fun draft(
        provider: NetworkProvider = NetworkProvider.VODAFONE,
        service: ServiceType = ServiceType.BALANCE_TOPUP,
        name: String = "شحن 100",
        mode: PricingMode = PricingMode.NET_MULTIPLIER,
        face: Long = 10_000,
        price: Long? = null,
        from: Long? = null,
        until: Long? = null,
    ) = OfferDraft(provider, service, name, null, mode, face, price, from, until, 0)

    /** عرض رصيد صافي 100 جنيه بمعامل 1.5 => سعر 150. */
    protected suspend fun netOffer(multiplierBp: Long? = 15_000L): String {
        if (multiplierBp != null) check(catalog.setMultiplierBp(multiplierBp) == null)
        return (catalog.addOffer(draft()) as OfferResult.Saved).offerId
    }

    protected suspend fun ingest(
        customerId: String,
        offerId: String,
        requestId: String = "req-${ids++}",
        phone: String = "01012345678",
        claimed: Long? = null,
    ): IngestOutcome = requests.ingest(
        IncomingRequest(requestId, customerId, offerId, NetworkProvider.VODAFONE, ServiceType.BALANCE_TOPUP, phone, null, claimed),
    )

    protected suspend fun createdRequest(customerId: String, offerId: String): ChargeRequestEntity =
        (ingest(customerId, offerId) as IngestOutcome.Created).request

    protected suspend fun approvedRequest(customerId: String, offerId: String): ChargeRequestEntity {
        val r = createdRequest(customerId, offerId)
        check(requests.changeStatus(r.id, RequestStatus.APPROVED) is StatusOutcome.Changed)
        return db.chargeRequestDao().getById(r.id)!!
    }

    protected suspend fun assertAccount(customerId: String, balance: Long, debt: Long) {
        val a = db.customerDao().observeWithBalancesById(customerId).first()!!
        assertEquals("balance", balance, a.balanceMinor)
        assertEquals("debt", debt, a.debtMinor)
    }
}
