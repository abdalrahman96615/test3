package com.factorycharge.admin

import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.core.model.RequestStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/**
 * 14) الحفاظ على البيانات عند Migration 1 -> 2: نُنشئ ملف قاعدة بمخطط المرحلة 2 (الإصدار 1) وفيه عميل وقيد
 * ودفتر وطلب قديم، ثم نفتحه بقاعدة المرحلة 3 عبر `AdminDatabase.build` الحقيقية. Room نفسه يتحقق بعد
 * الترحيل من أن المخطط مطابق تماماً لكيانات الإصدار 2 (وإلا يرمي استثناءً فيفشل الاختبار).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AdminMigrationTest {

    private val v1Schema = listOf(
        "CREATE TABLE `customers` (`id` TEXT NOT NULL, `displayName` TEXT NOT NULL, `phone` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, `isActive` INTEGER NOT NULL, `creditLimitMinor` INTEGER NOT NULL, PRIMARY KEY(`id`))",
        "CREATE UNIQUE INDEX `index_customers_phone` ON `customers` (`phone`)",
        "CREATE TABLE `charge_requests` (`id` TEXT NOT NULL, `customerId` TEXT NOT NULL, `provider` TEXT NOT NULL, `serviceType` TEXT NOT NULL, `targetPhone` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `status` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, `note` TEXT, PRIMARY KEY(`id`), FOREIGN KEY(`customerId`) REFERENCES `customers`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )",
        "CREATE INDEX `index_charge_requests_customerId` ON `charge_requests` (`customerId`)",
        "CREATE INDEX `index_charge_requests_status` ON `charge_requests` (`status`)",
        "CREATE TABLE `ledger_entries` (`id` TEXT NOT NULL, `operationId` TEXT NOT NULL, `lineNo` INTEGER NOT NULL, `customerId` TEXT NOT NULL, `type` TEXT NOT NULL, `operationKind` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `balanceDeltaMinor` INTEGER NOT NULL, `debtDeltaMinor` INTEGER NOT NULL, `balanceAfterMinor` INTEGER NOT NULL, `debtAfterMinor` INTEGER NOT NULL, `sequence` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL, `description` TEXT, `reversesEntryId` TEXT, PRIMARY KEY(`id`), FOREIGN KEY(`customerId`) REFERENCES `customers`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT , FOREIGN KEY(`reversesEntryId`) REFERENCES `ledger_entries`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )",
        "CREATE UNIQUE INDEX `index_ledger_entries_sequence` ON `ledger_entries` (`sequence`)",
        "CREATE UNIQUE INDEX `index_ledger_entries_operationId_lineNo` ON `ledger_entries` (`operationId`, `lineNo`)",
        "CREATE INDEX `index_ledger_entries_customerId_sequence` ON `ledger_entries` (`customerId`, `sequence`)",
        "CREATE UNIQUE INDEX `index_ledger_entries_reversesEntryId` ON `ledger_entries` (`reversesEntryId`)",
    )

    private fun createVersion1Database() {
        val ctx = RuntimeEnvironment.getApplication()
        val file = ctx.getDatabasePath(AdminDatabase.FILE_NAME)
        file.parentFile?.mkdirs()
        val raw = SQLiteDatabase.openOrCreateDatabase(file, null)
        try {
            v1Schema.forEach { raw.execSQL(it) }
            // بيانات حقيقية الشكل من المرحلة 2: عميل بحد ائتماني، إيداع في الدفتر، وطلب قديم بمبلغ واحد
            raw.execSQL("INSERT INTO customers VALUES('c1','أحمد','01011111111',1,1,50000)")
            raw.execSQL("INSERT INTO ledger_entries VALUES('e1','op1',0,'c1','WALLET_CREDIT','CASH_DEPOSIT',5000,5000,0,5000,0,1,1,NULL,NULL)")
            raw.execSQL("INSERT INTO charge_requests VALUES('r1','c1','VODAFONE','BALANCE_TOPUP','01012345678',10000,'SUBMITTED',5,6,'ملاحظة')")
            raw.version = 1
        } finally {
            raw.close()
        }
    }

    @Test
    fun migrationFrom1To2KeepsCustomersLedgerAndRequests() {
        createVersion1Database()
        val db = AdminDatabase.build(RuntimeEnvironment.getApplication())
        try {
            runBlocking {
                // العملاء والدفتر كما هي
                val customer = db.customerDao().getById("c1")!!
                assertEquals("أحمد", customer.displayName)
                assertEquals(50_000L, customer.creditLimitMinor)
                val entries = db.ledgerDao().listForCustomer("c1")
                assertEquals(1, entries.size)
                assertEquals(5_000L, entries.single().balanceAfterMinor)
                assertEquals(5_000L, db.ledgerDao().getTotals("c1").totalBalanceMinor)

                // الطلب القديم: المبلغ القديم صار القيمة الاسمية وسعر العميل، وبقية الحقول محفوظة
                val request = db.chargeRequestDao().getById("r1")!!
                assertEquals(10_000L, request.faceValueMinor)
                assertEquals(10_000L, request.customerPriceMinor)
                assertEquals(RequestStatus.SUBMITTED, request.status)
                assertEquals("01012345678", request.targetPhone)
                assertEquals("ملاحظة", request.note)
                assertNull(request.offerId)
                assertEquals(5L, request.createdAtMillis)
                assertEquals(6L, request.updatedAtMillis)

                // الجداول الجديدة موجودة وفارغة (لا بيانات تجريبية)
                assertEquals(0, db.serviceOfferDao().count())
                assertNull(db.settingsDao().get("net_multiplier_bp"))
                assertEquals(0, db.requestEventDao().listForRequest("r1").size)

                // الحماية بقيت: الدفتر وسجل الأحداث لا يُعدَّلان
                val sqlite = db.openHelper.writableDatabase
                assertThrows(SQLiteException::class.java) { sqlite.execSQL("UPDATE ledger_entries SET amountMinor = 1") }
                assertThrows(SQLiteException::class.java) { sqlite.execSQL("DELETE FROM ledger_entries") }
                val triggers = mutableListOf<String>()
                sqlite.query("SELECT name FROM sqlite_master WHERE type = 'trigger'").use { c ->
                    while (c.moveToNext()) triggers += c.getString(0)
                }
                assertTrue(triggers.toString(), triggers.containsAll(listOf("ledger_entries_no_update", "ledger_entries_no_delete", "request_events_no_update", "request_events_no_delete")))
            }
        } finally {
            db.close()
        }
    }

    @Test
    fun migratedDatabaseAcceptsNewPhase3Operations() {
        createVersion1Database()
        val db = AdminDatabase.build(RuntimeEnvironment.getApplication())
        try {
            runBlocking {
                val catalog = com.factorycharge.admin.data.CatalogRepository(db)
                val finance = com.factorycharge.admin.data.FinancialRepository(db)
                val requests = com.factorycharge.admin.data.RequestRepository(db)
                catalog.setMultiplierBp(15_000)
                val offer = (catalog.addOffer(
                    com.factorycharge.core.catalog.OfferDraft(
                        com.factorycharge.core.model.NetworkProvider.VODAFONE, com.factorycharge.core.model.ServiceType.BALANCE_TOPUP,
                        "شحن 100", null, com.factorycharge.core.model.PricingMode.NET_MULTIPLIER, 10_000, null, null, null, 0,
                    ),
                ) as com.factorycharge.admin.data.OfferResult.Saved).offerId
                val created = requests.ingest(
                    com.factorycharge.admin.data.IncomingRequest(
                        "new-req", "c1", offer, com.factorycharge.core.model.NetworkProvider.VODAFONE,
                        com.factorycharge.core.model.ServiceType.BALANCE_TOPUP, "01012345678",
                    ),
                )
                assertTrue(created is com.factorycharge.admin.data.IngestOutcome.Created)
                requests.changeStatus("new-req", RequestStatus.APPROVED)
                val out = finance.executeChargeRequest("new-req")
                assertTrue(out is com.factorycharge.admin.data.ExecutionOutcome.Executed)
                // الرصيد القديم 50 + خصم 150 => الفرق 100 دين (الحد 500)
                val account = db.customerDao().observeWithBalancesById("c1").let { it.first() }
                assertEquals(0L, account!!.balanceMinor)
                assertEquals(10_000L, account.debtMinor)
                // وطلب الإصدار 1 القديم ما زال كما هو
                assertEquals(RequestStatus.SUBMITTED, db.chargeRequestDao().getById("r1")!!.status)
            }
        } finally {
            db.close()
        }
    }
}
