package com.factorycharge.admin

import android.database.sqlite.SQLiteException
import com.factorycharge.admin.data.ExecutionOutcome
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.IngestOutcome
import com.factorycharge.admin.data.RequestFilter
import com.factorycharge.admin.data.StatusOutcome
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.ledger.OperationRejection
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestEventType
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.request.RequestRejection
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RequestFlowTest : AdminDbTest() {

    private fun rejected(o: IngestOutcome) = (o as IngestOutcome.Rejected).reason
    private fun executed(o: ExecutionOutcome) = o as ExecutionOutcome.Executed
    private fun execRejected(o: ExecutionOutcome) = (o as ExecutionOutcome.Rejected).reason
    private fun statusRejected(o: StatusOutcome) = (o as StatusOutcome.Rejected).reason

    // ---------------------------------------------------------------- الاستلام والتحقق

    // ---- 7) عدم خصم أي مبلغ عند إنشاء الطلب (ولا عند الموافقة)
    @Test
    fun creatingAndApprovingARequestNeverTouchesMoneyOrLedger() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        fund(c, 20_000)
        val ledgerBefore = db.ledgerDao().count()
        val offer = netOffer()

        val request = createdRequest(c, offer)
        assertEquals(RequestStatus.SUBMITTED, request.status)
        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertAccount(c, 20_000, 0)

        requests.changeStatus(request.id, RequestStatus.UNDER_REVIEW)
        requests.changeStatus(request.id, RequestStatus.APPROVED)
        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertAccount(c, 20_000, 0)
    }

    @Test
    fun ingestUsesTheAuthoritativeCatalogPriceNotTheClaimedOne() = inTest {
        val c = newCustomer()
        val offer = netOffer() // 100 × 1.5 = 150
        val r = (ingest(c, offer, claimed = 10_000) as IngestOutcome.Created).request // العميل ادّعى 100
        assertEquals(15_000L, r.customerPriceMinor)
        assertEquals(10_000L, r.faceValueMinor)
        assertEquals("شحن 100", r.offerName)
        assertEquals(offer, r.offerId)
        val types = db.requestEventDao().listForRequest(r.id).map { it.type }
        assertEquals(listOf(RequestEventType.INGESTED, RequestEventType.PRICE_MISMATCH), types)
    }

    @Test
    fun requestKeepsItsApprovedPriceWhenCatalogChangesLater() = inTest {
        val c = newCustomer()
        val offer = netOffer()
        val r = approvedRequest(c, offer)
        catalog.setMultiplierBp(30_000)
        assertEquals(15_000L, db.chargeRequestDao().getById(r.id)!!.customerPriceMinor)
    }

    // ---- 4) رفض طلب بعرض غير فعال
    @Test
    fun requestOnInactiveOrExpiredOrMissingOfferIsRejected() = inTest {
        val c = newCustomer()
        val offer = netOffer()
        catalog.setOfferActive(offer, false)
        assertEquals(RequestRejection.OFFER_INACTIVE, rejected(ingest(c, offer)))
        assertEquals(RequestRejection.OFFER_NOT_FOUND, rejected(ingest(c, "missing")))
        catalog.setOfferActive(offer, true)
        val expired = (catalog.addOffer(draft(name = "منتهٍ", until = 1)) as com.factorycharge.admin.data.OfferResult.Saved).offerId
        assertEquals(RequestRejection.OFFER_EXPIRED, rejected(ingest(c, expired)))
        assertEquals(0, db.chargeRequestDao().count())
    }

    // ---- 5) رفض رقم مستفيد غير صالح
    @Test
    fun invalidBeneficiaryIsRejected() = inTest {
        val c = newCustomer()
        val offer = netOffer()
        listOf("", "0101234567", "01312345678", "abc").forEach {
            assertEquals(RequestRejection.INVALID_BENEFICIARY, rejected(ingest(c, offer, phone = it)))
        }
        assertEquals(0, db.chargeRequestDao().count())
    }

    @Test
    fun netOfferWithoutMultiplierCannotBeRequested() = inTest {
        val c = newCustomer()
        val offer = netOffer(multiplierBp = null)
        assertEquals(RequestRejection.PRICE_UNAVAILABLE, rejected(ingest(c, offer)))
    }

    @Test
    fun duplicateRequestIdIsIdempotent() = inTest {
        val c = newCustomer()
        val offer = netOffer()
        val first = (ingest(c, offer, requestId = "same") as IngestOutcome.Created).request
        val again = ingest(c, offer, requestId = "same")
        assertTrue(again is IngestOutcome.Duplicate)
        assertEquals(first, (again as IngestOutcome.Duplicate).request)
        assertEquals(1, db.chargeRequestDao().count())
        assertEquals(1, db.requestEventDao().listForRequest("same").count { it.type == RequestEventType.INGESTED })
    }

    @Test
    fun unknownOrInactiveCustomerIsRejected() = inTest {
        val offer = netOffer()
        assertEquals(RequestRejection.CUSTOMER_NOT_FOUND, rejected(ingest("nobody", offer)))
        val c = newCustomer()
        finance.setCustomerActive(c, false)
        assertEquals(RequestRejection.CUSTOMER_INACTIVE, rejected(ingest(c, offer)))
    }

    // ---------------------------------------------------------------- الحالات

    @Test
    fun statusChangesFollowTransitionRulesAndRequireReasons() = inTest {
        val c = newCustomer()
        val r = createdRequest(c, netOffer())
        assertEquals(RequestRejection.USE_EXECUTE_ACTION, statusRejected(requests.changeStatus(r.id, RequestStatus.EXECUTED)))
        assertEquals(RequestRejection.REASON_REQUIRED, statusRejected(requests.changeStatus(r.id, RequestStatus.REJECTED, "  ")))
        assertEquals(RequestRejection.REQUEST_NOT_FOUND, statusRejected(requests.changeStatus("nope", RequestStatus.APPROVED)))
        assertTrue(requests.changeStatus(r.id, RequestStatus.UNDER_REVIEW) is StatusOutcome.Changed)
        val rej = (requests.changeStatus(r.id, RequestStatus.REJECTED, "العرض غير متاح") as StatusOutcome.Changed).request
        assertEquals(RequestStatus.REJECTED, rej.status)
        assertEquals("العرض غير متاح", rej.statusNote)
        assertEquals(RequestRejection.INVALID_TRANSITION, statusRejected(requests.changeStatus(r.id, RequestStatus.APPROVED)))
        val types = db.requestEventDao().listForRequest(r.id).map { it.type }
        assertEquals(listOf(RequestEventType.INGESTED, RequestEventType.STATUS_CHANGED, RequestEventType.STATUS_CHANGED), types)
    }

    // ---------------------------------------------------------------- التنفيذ المالي

    // ---- 8) رفض تنفيذ طلب غير معتمد
    @Test
    fun onlyApprovedRequestsCanBeExecuted() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        fund(c, 50_000)
        val offer = netOffer()
        val ledgerBefore = db.ledgerDao().count()

        val submitted = createdRequest(c, offer)
        assertEquals(OperationRejection.REQUEST_NOT_APPROVED, execRejected(finance.executeChargeRequest(submitted.id)))
        requests.changeStatus(submitted.id, RequestStatus.UNDER_REVIEW)
        assertEquals(OperationRejection.REQUEST_NOT_APPROVED, execRejected(finance.executeChargeRequest(submitted.id)))
        requests.changeStatus(submitted.id, RequestStatus.REJECTED, "سبب")
        assertEquals(OperationRejection.REQUEST_NOT_APPROVED, execRejected(finance.executeChargeRequest(submitted.id)))

        val cancelled = createdRequest(c, offer)
        requests.changeStatus(cancelled.id, RequestStatus.CANCELLED, "ألغاه العميل")
        assertEquals(OperationRejection.REQUEST_NOT_APPROVED, execRejected(finance.executeChargeRequest(cancelled.id)))

        assertEquals(OperationRejection.REQUEST_NOT_FOUND, execRejected(finance.executeChargeRequest("missing")))
        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertAccount(c, 50_000, 0)
    }

    // ---- 9) نجاح تنفيذ طلب مرة واحدة (يُخصم السعر المعتمد 150 لا القيمة الاسمية 100)
    @Test
    fun executionDeductsApprovedPriceFromWalletAndMarksExecuted() = inTest {
        val c = newCustomer()
        fund(c, 20_000)
        val r = approvedRequest(c, netOffer())

        val out = executed(finance.executeChargeRequest(r.id))
        assertEquals(RequestStatus.EXECUTED, out.request.status)
        assertNotNull(out.request.executedAtMillis)
        assertEquals(listOf(LedgerEntryType.WALLET_DEBIT), out.entries.map { it.type })
        assertEquals(15_000L, out.entries.single().amountMinor)
        assertEquals(OperationKind.CONSUMPTION, out.entries.single().operationKind)
        assertEquals(FinancialRepository.executionOperationId(r.id), out.entries.single().operationId)
        assertAccount(c, 5_000, 0)
        val types = db.requestEventDao().listForRequest(r.id).map { it.type }
        assertEquals(RequestEventType.EXECUTED, types.last())
    }

    // ---- 10) منع تنفيذ نفس الطلب مرتين
    @Test
    fun executingTwiceReturnsPreviousResultWithoutSecondDeduction() = inTest {
        val c = newCustomer()
        fund(c, 20_000)
        val r = approvedRequest(c, netOffer())
        val first = executed(finance.executeChargeRequest(r.id))
        val ledgerAfterFirst = db.ledgerDao().count()

        val second = finance.executeChargeRequest(r.id)
        assertTrue(second is ExecutionOutcome.AlreadyExecuted)
        assertEquals(first.entries, (second as ExecutionOutcome.AlreadyExecuted).entries)
        assertEquals(ledgerAfterFirst, db.ledgerDao().count())
        assertAccount(c, 5_000, 0)
        // ولا يمكن إعادة طلب منفذ إلى أي حالة
        assertEquals(RequestRejection.INVALID_TRANSITION, statusRejected(requests.changeStatus(r.id, RequestStatus.APPROVED)))
        assertEquals(RequestRejection.INVALID_TRANSITION, statusRejected(requests.changeStatus(r.id, RequestStatus.CANCELLED, "x")))
    }

    // ---- 12) توزيع الرصيد والمديونية (سياسة partial): الرصيد أولاً ثم الفرق دين
    @Test
    fun executionBeyondBalanceUsesBalanceFirstThenCreatesDebt() = inTest {
        val c = newCustomer(limitMinor = 10_000)
        fund(c, 10_000)
        val r = approvedRequest(c, netOffer()) // سعر 150 والرصيد 100
        val out = executed(finance.executeChargeRequest(r.id))
        assertEquals(listOf(LedgerEntryType.WALLET_DEBIT, LedgerEntryType.DEBT_CREATED), out.entries.map { it.type })
        assertEquals(listOf(10_000L, 5_000L), out.entries.map { it.amountMinor })
        assertEquals(0L, out.resulting.balanceMinor)
        assertEquals(5_000L, out.resulting.debtMinor)
        assertEquals(0L, out.entries.last().balanceAfterMinor)
        assertEquals(5_000L, out.entries.last().debtAfterMinor)
        assertAccount(c, 0, 5_000)
    }

    @Test
    fun executionWithNoBalanceCreatesFullDebtWithinLimit() = inTest {
        val c = newCustomer(limitMinor = 15_000)
        val r = approvedRequest(c, netOffer())
        val out = executed(finance.executeChargeRequest(r.id))
        assertEquals(listOf(LedgerEntryType.DEBT_CREATED), out.entries.map { it.type })
        assertAccount(c, 0, 15_000) // يساوي الحد تماماً: مسموح
    }

    // ---- 11) رفض التنفيذ عند تجاوز الحد الائتماني: لا خصم ولا تغيير حالة
    @Test
    fun executionBeyondCreditLimitIsRejectedWithNoDeduction() = inTest {
        val c = newCustomer(limitMinor = 4_000)
        fund(c, 10_000)
        val r = approvedRequest(c, netOffer()) // يتبقى 50 دين > الحد 40
        val ledgerBefore = db.ledgerDao().count()

        assertEquals(OperationRejection.CREDIT_LIMIT_EXCEEDED, execRejected(finance.executeChargeRequest(r.id)))

        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertAccount(c, 10_000, 0)
        val after = db.chargeRequestDao().getById(r.id)!!
        assertEquals(RequestStatus.APPROVED, after.status)
        assertNull(after.executedAtMillis)
        // بعد رفع الحد يمكن التنفيذ
        finance.setCreditLimit(c, 5_000)
        executed(finance.executeChargeRequest(r.id))
        assertAccount(c, 0, 5_000)
    }

    @Test
    fun inactiveCustomerRequestCannotBeExecuted() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        fund(c, 50_000)
        val r = approvedRequest(c, netOffer())
        finance.setCustomerActive(c, false)
        assertEquals(OperationRejection.CUSTOMER_INACTIVE, execRejected(finance.executeChargeRequest(r.id)))
        assertAccount(c, 50_000, 0)
    }

    // ---- 13) فشل التنفيذ دون تسجيل خصم، ويبقى الطلب قابلاً للإعادة أو الإلغاء
    @Test
    fun recordedExecutionFailureDeductsNothingAndKeepsRequestApproved() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        fund(c, 20_000)
        val r = approvedRequest(c, netOffer())
        val ledgerBefore = db.ledgerDao().count()

        assertEquals(RequestRejection.REASON_REQUIRED, statusRejected(requests.recordExecutionFailure(r.id, " ")))
        val failed = (requests.recordExecutionFailure(r.id, "رصيد الشبكة غير كافٍ") as StatusOutcome.Changed).request
        assertEquals(RequestStatus.APPROVED, failed.status)
        assertEquals("رصيد الشبكة غير كافٍ", failed.lastFailureReason)
        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertAccount(c, 20_000, 0)
        val events = db.requestEventDao().listForRequest(r.id)
        assertEquals(RequestEventType.EXECUTION_FAILED, events.last().type)
        assertEquals("رصيد الشبكة غير كافٍ", events.last().note)

        // إعادة المحاولة ثم النجاح
        executed(finance.executeChargeRequest(r.id))
        assertAccount(c, 5_000, 0)
        // تسجيل فشل بعد التنفيذ مرفوض
        assertEquals(RequestRejection.INVALID_TRANSITION, statusRejected(requests.recordExecutionFailure(r.id, "x")))
    }

    @Test
    fun failedRequestCanBeCancelledWithReason() = inTest {
        val c = newCustomer()
        fund(c, 20_000)
        val r = approvedRequest(c, netOffer())
        requests.recordExecutionFailure(r.id, "تعذّر")
        val cancelled = (requests.changeStatus(r.id, RequestStatus.CANCELLED, "تعذّر الشحن نهائياً") as StatusOutcome.Changed).request
        assertEquals(RequestStatus.CANCELLED, cancelled.status)
        assertEquals(OperationRejection.REQUEST_NOT_APPROVED, execRejected(finance.executeChargeRequest(r.id)))
        assertAccount(c, 20_000, 0)
    }

    // ---- الذرية: أي خطأ داخل معاملة التنفيذ يتراجع عن القيود وتغيير الحالة معاً
    @Test
    fun failureInsideExecutionTransactionRollsBackEntriesAndStatus() = inTest {
        val c = newCustomer(limitMinor = 10_000)
        fund(c, 10_000)
        val r = approvedRequest(c, netOffer()) // قيدان: WALLET_DEBIT ثم DEBT_CREATED
        val ledgerBefore = db.ledgerDao().count()
        val eventsBefore = db.requestEventDao().listForRequest(r.id).size

        // (أ) فشل بعد إدراج أول قيد
        val failFirst = newFinance(afterEntry = { if (it == 0) throw IllegalStateException("boom-entry") })
        assertThrows(IllegalStateException::class.java) { runBlocking { failFirst.executeChargeRequest(r.id) } }
        // (ب) فشل بعد إدراج كل القيود وتغيير الحالة، قبل الإتمام
        val failLate = newFinance(beforeCommit = { throw IllegalStateException("boom-commit") })
        assertThrows(IllegalStateException::class.java) { runBlocking { failLate.executeChargeRequest(r.id) } }

        assertEquals(ledgerBefore, db.ledgerDao().count())
        assertEquals(0, db.ledgerDao().countByOperation(FinancialRepository.executionOperationId(r.id)))
        assertEquals(eventsBefore, db.requestEventDao().listForRequest(r.id).size)
        val after = db.chargeRequestDao().getById(r.id)!!
        assertEquals(RequestStatus.APPROVED, after.status)
        assertNull(after.executedAtMillis)
        assertAccount(c, 10_000, 0)

        // لم يُستهلك المعرّف: التنفيذ السليم ينجح مرة واحدة
        executed(finance.executeChargeRequest(r.id))
        assertAccount(c, 0, 5_000)
    }

    // ---------------------------------------------------------------- حماية السجلات

    @Test
    fun requestEventsAreAppendOnly() = inTest {
        val c = newCustomer()
        val r = createdRequest(c, netOffer())
        val sqlite = db.openHelper.writableDatabase
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("UPDATE request_events SET note = 'x'") }
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("DELETE FROM request_events") }
        assertEquals(1, db.requestEventDao().listForRequest(r.id).size)
    }

    @Test
    fun executionEntriesRemainImmutable() = inTest {
        val c = newCustomer()
        fund(c, 20_000)
        val r = approvedRequest(c, netOffer())
        executed(finance.executeChargeRequest(r.id))
        val sqlite = db.openHelper.writableDatabase
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("UPDATE ledger_entries SET amountMinor = 1") }
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("DELETE FROM ledger_entries") }
    }

    // ---------------------------------------------------------------- الفلاتر

    @Test
    fun inboxFiltersByStatusProviderServiceCustomerAndDate() = inTest {
        val a = (finance.addCustomer("أحمد", "01011111111") as com.factorycharge.admin.data.CustomerResult.Saved).customerId
        val b = (finance.addCustomer("محمود", "01022222222") as com.factorycharge.admin.data.CustomerResult.Saved).customerId
        val vodafone = netOffer()
        val orange = (catalog.addOffer(draft(provider = NetworkProvider.ORANGE, service = ServiceType.DATA_PACKAGE, name = "باقة", mode = com.factorycharge.core.model.PricingMode.FIXED_PRICE, face = 0, price = 3_000)) as com.factorycharge.admin.data.OfferResult.Saved).offerId

        clock = 10_000
        val r1 = createdRequest(a, vodafone)
        clock = 20_000
        val r2 = (requests.ingest(
            com.factorycharge.admin.data.IncomingRequest("r2", b, orange, NetworkProvider.ORANGE, ServiceType.DATA_PACKAGE, "01212345678"),
        ) as IngestOutcome.Created).request
        requests.changeStatus(r2.id, RequestStatus.APPROVED)

        suspend fun ids(f: RequestFilter) = requests.observeRequests(f).first().map { it.request.id }
        assertEquals(listOf(r2.id, r1.id), ids(RequestFilter()))                                   // الأحدث أولاً
        assertEquals(listOf(r1.id), ids(RequestFilter(statuses = setOf(RequestStatus.SUBMITTED))))
        assertEquals(listOf(r2.id), ids(RequestFilter(statuses = setOf(RequestStatus.APPROVED, RequestStatus.EXECUTED))))
        assertEquals(listOf(r2.id), ids(RequestFilter(provider = NetworkProvider.ORANGE)))
        assertEquals(listOf(r1.id), ids(RequestFilter(serviceType = ServiceType.BALANCE_TOPUP)))
        assertEquals(listOf(r1.id), ids(RequestFilter(customerQuery = "أحمد")))
        assertEquals(listOf(r2.id), ids(RequestFilter(customerQuery = "0102222")))
        assertEquals(emptyList<String>(), ids(RequestFilter(customerQuery = "%")))
        assertEquals(listOf(r2.id), ids(RequestFilter(fromMillis = 15_000)))
        assertEquals(listOf(r1.id), ids(RequestFilter(toMillis = 15_000)))
        val row = requests.observeRequest(r1.id).first()!!
        assertEquals("أحمد", row.customerName)
        assertEquals("01011111111", row.customerPhone)
    }

    @Test
    fun reportsAggregateExecutedRequestsPerProvider() = inTest {
        val c = newCustomer(limitMinor = 100_000)
        val offer = netOffer()
        val r1 = approvedRequest(c, offer)
        val r2 = approvedRequest(c, offer)
        finance.executeChargeRequest(r1.id)
        finance.executeChargeRequest(r2.id)
        createdRequest(c, offer)
        val totals = requests.observeExecutedByProvider().first().single()
        assertEquals(NetworkProvider.VODAFONE.name, totals.provider)
        assertEquals(2, totals.count)
        assertEquals(20_000L, totals.faceTotalMinor)
        assertEquals(30_000L, totals.priceTotalMinor)
        val counts = requests.observeStatusCounts().first().associate { it.status to it.count }
        assertEquals(2, counts["EXECUTED"])
        assertEquals(1, counts["SUBMITTED"])
        assertEquals(1, requests.observeNewCount().first())
    }
}
