package com.factorycharge.admin

import com.factorycharge.admin.data.OfferResult
import com.factorycharge.admin.data.priceMinor
import com.factorycharge.core.catalog.OfferError
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.PricingMode
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.pricing.PriceCalculator
import kotlinx.coroutines.flow.first
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CatalogRepositoryTest : AdminDbTest() {

    // ---- 1) إضافة عرض جديد (القيمة الاسمية وسعر البيع حقلان منفصلان)
    @Test
    fun addOfferStoresFaceValueAndSellPriceSeparately() = inTest {
        val result = catalog.addOffer(draft(service = ServiceType.RECHARGE_CARD, name = "كارت 22", mode = PricingMode.FIXED_PRICE, face = 2_200, price = 2_500))
        val id = (result as OfferResult.Saved).offerId
        val offer = catalog.observeOffers().first().single()
        assertEquals(id, offer.id)
        assertEquals(2_200L, offer.faceValueMinor)
        assertEquals(2_500L, offer.fixedPriceMinor)
        assertEquals(2_500L, offer.priceMinor(null))
        assertTrue(offer.isActive)
        assertEquals(1L, offer.revision)
        assertEquals(NetworkProvider.VODAFONE, offer.provider)
    }

    @Test
    fun invalidOfferIsRejectedAndNotStored() = inTest {
        val r = catalog.addOffer(draft(service = ServiceType.DATA_PACKAGE, mode = PricingMode.FIXED_PRICE, face = 0, price = 0))
        assertEquals(OfferError.INVALID_PRICE, (r as OfferResult.Failed).error)
        assertEquals(0, db.serviceOfferDao().count())
    }

    // ---- 2) تعديل سعر العرض
    @Test
    fun editingPriceUpdatesOfferAndBumpsRevision() = inTest {
        val id = (catalog.addOffer(draft(service = ServiceType.DATA_PACKAGE, name = "10 جيجا", mode = PricingMode.FIXED_PRICE, face = 0, price = 5_000)) as OfferResult.Saved).offerId
        val before = catalog.getOffer(id)!!
        val r = catalog.updateOffer(id, draft(service = ServiceType.DATA_PACKAGE, name = "10 جيجا", mode = PricingMode.FIXED_PRICE, face = 0, price = 5_500))
        assertTrue(r is OfferResult.Saved)
        val after = catalog.getOffer(id)!!
        assertEquals(5_500L, after.priceMinor(null))
        assertEquals(before.revision + 1, after.revision)
        assertEquals(before.createdAtMillis, after.createdAtMillis)
        assertEquals(OfferError.NOT_FOUND, ((catalog.updateOffer("missing", draft())) as OfferResult.Failed).error)
    }

    // ---- 3) تعطيل عرض (وإعادة تفعيله)
    @Test
    fun disablingAnOfferKeepsItButMarksInactive() = inTest {
        val id = netOffer()
        assertTrue(catalog.setOfferActive(id, false) is OfferResult.Saved)
        assertFalse(catalog.getOffer(id)!!.isActive)
        assertEquals(1, db.serviceOfferDao().count()) // لا حذف
        catalog.setOfferActive(id, true)
        assertTrue(catalog.getOffer(id)!!.isActive)
    }

    // ---- 6) سعر الرصيد الصافي بالمعامل المخزَّن (قابل للتعديل بلا تحديث APK)
    @Test
    fun netBalancePriceFollowsStoredMultiplier() = inTest {
        val id = netOffer(multiplierBp = null)
        assertNull(catalog.getMultiplierBp())
        assertNull(catalog.getOffer(id)!!.priceMinor(catalog.getMultiplierBp())) // لا معامل = لا سعر، ولا قيمة مخترعة

        assertNull(catalog.setMultiplierBp(15_000))
        assertEquals(15_000L, catalog.getOffer(id)!!.priceMinor(catalog.getMultiplierBp())) // 100 × 1.5 = 150
        assertEquals(15_000L, catalog.observeMultiplierBp().first())

        assertNull(catalog.setMultiplierBp(12_000))
        assertEquals(12_000L, catalog.getOffer(id)!!.priceMinor(catalog.getMultiplierBp())) // 100 × 1.2 = 120
    }

    @Test
    fun invalidMultiplierIsRejectedAndKeepsPreviousValue() = inTest {
        catalog.setMultiplierBp(15_000)
        assertEquals(OfferError.INVALID_MULTIPLIER, catalog.setMultiplierBp(0))
        assertEquals(OfferError.INVALID_MULTIPLIER, catalog.setMultiplierBp(-5))
        assertEquals(OfferError.INVALID_MULTIPLIER, catalog.setMultiplierBp(PriceCalculator.MAX_MULTIPLIER_BP + 1))
        assertEquals(15_000L, catalog.getMultiplierBp())
    }

    @Test
    fun offerValidityWindowIsPersisted() = inTest {
        val id = (catalog.addOffer(draft(mode = PricingMode.FIXED_PRICE, service = ServiceType.OTHER, face = 0, price = 100, from = 10, until = 20)) as OfferResult.Saved).offerId
        val offer = catalog.getOffer(id)!!
        assertEquals(10L, offer.validFromMillis)
        assertEquals(20L, offer.validUntilMillis)
    }
}
